<?php

if (!file_exists('../../../wp-config.php')) die ('wp-config.php not found');
require_once('../../../wp-config.php');

  if( !class_exists( 'odst_easyjet' ) )
        include_once( 'odsteasyjet.php' );
		
function odst_easyjet_update_hotels() {
	global $wpdb;
    $start = time();
	$table_name = $wpdb->prefix . "odst_easyjet_properties";
	
    $last_updated = get_option('odst_easyjet_last_updated');
	
	
	$options = get_option('odst_options');			
	$odst_easyjet = new odst_easyjet($options);	

	$xml = $odst_easyjet->get_hotels_from_odst('',5000);
	echo('Updating..');
	
	$sql = "delete from " . $table_name ;
	$wpdb->query($sql);	
		
	foreach( $xml->property as $property ) {
		echo('.');
		$sql = "insert into " . $table_name . "(id,name,resort,resortid,region,country,rating,hoteltype,airportcode,image1url,image2url,image3url,description,address,postcode,propertyid,price,url) " .
				 "values ('" . $property->id . "','" . $property->name . "','" . $property->resort . "','" . $property->resortid . "','" . $property->region . "','" . $property->country . "','" . $property->rating . "','" . $property->hoteltype . "','" . $property->airportcode . "','" . $property->image1url . "','" . $property->image2url . "','" . $property->image3url . "','" . $property->description . "','" . $property->address . "','" . $property->postcode . "','" . $property->propertyid . "','" . $property->price . "','" . $property->url . "')" .
				 " ON DUPLICATE KEY update name='" . $property->name . "',resort='" . $property->resort . "',resortid='" . $property->resortid . "',region='" . $property->region . "',country='" . $property->country . "',rating='" . $property->rating . "',hoteltype='" . $property->hoteltype . "',airportcode='" . $property->airportcode . "',image1url='" . $property->image1url . "',image2url='" . $property->image2url . "',image3url='" . $property->image3url . "',description='" . $property->description . "',address='" . $property->address . "',postcode='" . $property->postcode . "',propertyid='" . $property->propertyid . "',price='" . $property->price . "',url='" . $property->url . "'";				
						
		$wpdb->query($sql);		
	}
	
	$regions=$wpdb->get_col( "select distinct region from " . $table_name);
	update_option('odst_easyjet_regions', $regions);
	
	$countries=$wpdb->get_col( "select distinct country from " . $table_name);
	update_option('odst_easyjet_countries', $countries);
	
	update_option('odst_easyjet_last_updated',$start);
	
	
   
	}		
		
	$username = mysql_real_escape_string($_GET["username"]);
	$password = mysql_real_escape_string($_GET["password"]);
	$options = get_option('odst_options');
	if ( $username ==  $options['odst_username'] && ($password ==  $options['odst_password']))
		{ 
		odst_easyjet_update_hotels();
		}
	else
		{
		echo('Please provide a valid username and password for this installation.');
		}
	
?>