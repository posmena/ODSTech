/**
 * Handle: wpODSTEasyjetAdmin
 * Version: 0.0.1
 * Deps: jquery
 * Enqueue: true
 */
 
 
var wpODSTEasyjetAdmin = function () {}
 
wpODSTEasyjetAdmin.prototype = {
    autoUpdateCountryRegionResort : true,
	$tabs	: null,
    options           : {},
	init : function()
	{
	
		//wpODSTEasyjet_country
		//load countries from AP
		jQuery("#wpODSTEasyjet_country").change(function () {		
				  wpODSTEasyjetAdminObj.showRegions(jQuery("#wpODSTEasyjet_country").val(),"#wpODSTEasyjet_region","#wpODSTEasyjet_resort");
				});
				
		wpODSTEasyjetAdminObj.showRegions(jQuery("#wpODSTEasyjet_country").val(),"#wpODSTEasyjet_region","#wpODSTEasyjet_resort");

		jQuery("#wpODSTEasyjet_region").change(function () {
				  wpODSTEasyjetAdminObj.showResorts(jQuery("#wpODSTEasyjet_region").val(),"#wpODSTEasyjet_resort");
				});
				
		jQuery("#wpODSTEasyjet_country2").change(function () {
				  wpODSTEasyjetAdminObj.showRegions(jQuery("#wpODSTEasyjet_country2").val(),"#wpODSTEasyjet_region2","#wpODSTEasyjet_resort2",true);
				});
		wpODSTEasyjetAdminObj.showRegions(jQuery("#wpODSTEasyjet_country2").val(),"#wpODSTEasyjet_region2","#wpODSTEasyjet_resort2",true);

		jQuery("#wpODSTEasyjet_region2").change(function () {
				  wpODSTEasyjetAdminObj.showResorts(jQuery("#wpODSTEasyjet_region2").val(),"#wpODSTEasyjet_resort2");
				});
				
		jQuery("#wpODSTEasyjet_country3").change(function () {
				  wpODSTEasyjetAdminObj.showRegions(jQuery("#wpODSTEasyjet_country3").val(),"#wpODSTEasyjet_region3","#wpODSTEasyjet_resort3",true);
				});
		wpODSTEasyjetAdminObj.showRegions(jQuery("#wpODSTEasyjet_country3").val(),"#wpODSTEasyjet_region3","#wpODSTEasyjet_resort3",true);

		jQuery("#wpODSTEasyjet_region3").change(function () {
				  wpODSTEasyjetAdminObj.showResorts(jQuery("#wpODSTEasyjet_region3").val(),"#wpODSTEasyjet_resort3");
				});
				
		jQuery("#wpODSTEasyjet_country4").change(function () {
				  wpODSTEasyjetAdminObj.showRegions(jQuery("#wpODSTEasyjet_country4").val(),"#wpODSTEasyjet_region4","#wpODSTEasyjet_resort4",true);
				});
		wpODSTEasyjetAdminObj.showRegions(jQuery("#wpODSTEasyjet_country4").val(),"#wpODSTEasyjet_region4","#wpODSTEasyjet_resort4",true);

		jQuery("#wpODSTEasyjet_region4").change(function () {
				  wpODSTEasyjetAdminObj.showResorts(jQuery("#wpODSTEasyjet_region4").val(),"#wpODSTEasyjet_resort4");
				});
				
		//wpODSTEasyjetAdminObj.showResorts(jQuery("#wpODSTEasyjet_region").val(),"#wpODSTEasyjet_resort");

		jQuery("#wpODSTEasyjet_format").change(function () {
		wpODSTEasyjetAdminObj.toggle_show_dropdowns(jQuery("#wpODSTEasyjet_fixed"),jQuery("#wpODSTEasyjet_format"));
		});
		
		wpODSTEasyjetAdminObj.toggle_show_dropdowns(jQuery("#wpODSTEasyjet_fixed"),jQuery("#wpODSTEasyjet_format"));

				wpODSTEasyjetAdminObj.$tabs = jQuery("#odst_insert_easyjet_content #odst-tabs-2").tabs();			
			
		
	},	
	bindCountryRegionResort3: function() {
		jQuery("#wpODSTEasyjet_country3").change(function () {
				  wpODSTEasyjetAdminObj.showRegions(jQuery("#wpODSTEasyjet_country3").val(),"#wpODSTEasyjet_region3","#wpODSTEasyjet_resort3",true);
				});
		wpODSTEasyjetAdminObj.showRegions(jQuery("#wpODSTEasyjet_country3").val(),"#wpODSTEasyjet_region3","#wpODSTEasyjet_resort3",true);

		jQuery("#wpODSTEasyjet_region3").change(function () {
				  wpODSTEasyjetAdminObj.showResorts(jQuery("#wpODSTEasyjet_region3").val(),"#wpODSTEasyjet_resort3");
				});
	},
	unbindCountryRegionResort3: function() {
		jQuery("#wpODSTEasyjet_country3").unbind("change");
		jQuery("#wpODSTEasyjet_region3").unbind("change");		
	},	
    generateShortCode : function() {
        var content = this['options']['content'];
        delete this['options']['content'];
 
        var attrs = '';
        jQuery.each(this['options'], function(name, value){
            if (value != '') {
                attrs += ' ' + name + '="' + value + '"';
            }
        });
        return attrs + 'The hotel needs be inserted here!';
    },
    sendToEditor      : function(f) {
        var collection = jQuery(f).find("input[id^=wpODSTEasyjet]:not(input:checkbox),input[id^=wpODSTEasyjet]:checkbox:checked,select[id^=wpODSTEasyjet]");
        var $this = this;
        collection.each(function () {
            var name = this.name;//this.name.substring(13, this.name.length-1);
            $this['options'][name] = this.value;
        });
        this.sendToEditorV2(this.generateShortCode());
        return false;
    },
	loadPage: function(url,div){
	jQuery('#hotelresults_loadimg').css('display','inline');	
	jQuery('#hotelresults').load(url, function() {	jQuery('#hotelresults_loadimg').css('display','none');} );
	jQuery('#hotelresults').scrollTop();
	},
	// send html to the post editor
    sendToEditorV2: function(h) {
	send_to_editor(h);
},
	showHotelSearch : function(f) {	
            var s = jQuery(f).find('#wpODSTEasyjet_hotelname');
			var c = jQuery(f).find('#wpODSTEasyjet_country3').val();			
			var rg = jQuery(f).find('#wpODSTEasyjet_region3').val();
			var r = jQuery(f).find('#wpODSTEasyjet_resort3').val();
				
			var url = odst_settings.findhotels_url + '?q=' + s.val() + '&country=' + c + '&rgion=' + encodeURIComponent(rg) + '&resort=' + encodeURIComponent(r) ;
			
			this.loadPage(url + ' #hotelsearch');
			

			//tb_show('Find Hotels','/wp-content/plugins/odsteasyjet/findhotels.php?q=' + s.val() + '&country=' + c + '&rgion=' + encodeURIComponent(rg) + '&resort=' + encodeURIComponent(r) + '&TB_iframe=true&height=400&width=600',null);
			return false;
	},
	showHotelSearchV1 : function(f) {	
			
			tb_show('Add eJH Content','#TB_inline?width=540&height=560&inlineId=odst_insert_easyjet_content',null);
			
			this.autoUpdateCountryRegionResort = false;
			
		    this.$tabs.tabs("select",1);			
		    var s = jQuery(f).find('#wpODSTEasyjet_hotelname');
		     
			jQuery('#hotels #wpODSTEasyjet_hotelname').val(jQuery('#hotels_mb #wpODSTEasyjet_hotelname').val());
			
			var c3 = jQuery('#hotels #wpODSTEasyjet_country3');			
			c3.empty();
			jQuery('#hotels_mb #wpODSTEasyjet_country2 option').each(function() { c3.append(jQuery('<option></option>').val(jQuery(this).val()).html(jQuery(this).text())); } )
			c3.val(jQuery('#hotels_mb #wpODSTEasyjet_country2').val());
			
			jQuery('#hotels #wpODSTEasyjet_country3').val(jQuery('#hotels_mb #wpODSTEasyjet_country2').val());
			
			var r3 = jQuery('#hotels #wpODSTEasyjet_region3');			
			r3.empty();
			jQuery('#hotels_mb #wpODSTEasyjet_region2 option').each(function() { r3.append(jQuery('<option></option>').val(jQuery(this).val()).html(jQuery(this).text())); } )
			r3.val(jQuery('#hotels_mb #wpODSTEasyjet_region2').val());
			
			jQuery('#hotels #wpODSTEasyjet_region3').val(jQuery('#hotels_mb #wpODSTEasyjet_region2').val());
			
			var rs3 = jQuery('#hotels #wpODSTEasyjet_resort3');			
			rs3.empty();
			jQuery('#hotels_mb #wpODSTEasyjet_resort2 option').each(function() { rs3.append(jQuery('<option></option>').val(jQuery(this).val()).html(jQuery(this).text())); } )
			rs3.val(jQuery('#hotels_mb #wpODSTEasyjet_resort2').val());
			
			jQuery('#hotels #wpODSTEasyjet_resort3').val(jQuery('#hotels_mb #wpODSTEasyjet_resort2').val());
			
			this.autoUpdateCountryRegionResort = true;
		   	//jQuery("#odst_insert_easyjet_content #wpODSTEasyjet_hotelname").val(s.val);
		//	this.bindCountryDropdowns();
					
			
				
			var url = odst_settings.findhotels_url + '?q=' + s.val() + '&country=' + c3.val() + '&rgion=' + encodeURIComponent(r3.val()) + '&resort=' + encodeURIComponent(rs3.val()) ;
			
			this.loadPage(url + ' #hotelsearch');
			

			//tb_show('Find Hotels','/wp-content/plugins/odsteasyjet/findhotels.php?q=' + s.val() + '&country=' + c + '&rgion=' + encodeURIComponent(rg) + '&resort=' + encodeURIComponent(r) + '&TB_iframe=true&height=400&width=600',null);
			return false;
	},
	addHotelAsProduct : function(name,url,desc,i,id) {	
	this.sendToEditorV2('<div class="odst_hotel"><span class="name"><a target="_blank" rel="nofollow" href="' + url + '">' + name + '</a></span>');
	this.sendToEditorV2('<a target="_blank" rel="nofollow" href="' + url + '"><img class="alignleft" src="' + i + '"/></a>');
	this.sendToEditorV2('<div class="description">' + desc + '</div>');	
	this.sendToEditorV2('<div class="prices">Price from [odst type="rates" propertyid="' + id + '"]</div>');
	this.sendToEditorV2('</div>');	
	
	return false;
	},
	addHotelImage : function(i) {	
	this.sendToEditorV2('<img src="' + i + '"/>');
	return false;
	},
	addHotelAsPost : function(f, name,url,desc,i,id,rating) {	
	if( confirm('This will overwrite existing your content and title, continue?') ) {
	jQuery(f).find('#title').val(name);
	jQuery(f).find('#content').val('');
	this.sendToEditorV2('<div class="odst_hotel even"><h2><a target="_blank" rel="nofollow" href="' + url + '"></h2></a>');
	this.sendToEditorV2('Price from <a target="_blank" rel="nofollow" href="' + url + '">[odst type="rates" propertyid="' + id + '"]</a>');
	this.sendToEditorV2('<span class="rating">');
	if( rating == 1) { this.sendToEditorV2('1 star') } else { this.sendToEditorV2(rating + ' stars') };
	this.sendToEditorV2('<a target="_blank" rel="nofollow" href="' + url + '"><img class="alignleft photo" src="' + i + '"/></a>');
	this.sendToEditorV2('<div class="description">' + desc + '</div>');
	this.sendToEditorV2('</div>');	
	}
	return false;
	},
	insertContentUnit : function(f,id) {
	var c,rg,r,l,s;
	if( jQuery(f).find("#wpODSTEasyjet_format" + id).val() == "contextual" )	{
		rg = "contextual"; c = ""; r = "";			
		}
		else{
			rg = jQuery(f).find("#wpODSTEasyjet_region" + id).val();
			c = jQuery(f).find("#wpODSTEasyjet_country" + id).val();
			r = jQuery(f).find("#wpODSTEasyjet_resort" + id).val();	
		}
		l = jQuery(f).find("#wpODSTEasyjet_maxproperties" + id).val();
		s = jQuery(f).find("#wpODSTEasyjet_style" + id).val();
		this.sendToEditorV2('[odst type="properties" display="' + jQuery(f).find("#wpODSTEasyjet_display" + id).val() +  '" width="' + jQuery(f).find("#wpODSTEasyjet_width" + id).val() + '" style="' + s + '" country="' + c + '" region="' + rg + '" resort="' + r + '" max="' + l + '"]');	
	},
	insertRegionCarousel : function(f) {	
	var r = jQuery(f).find("#wpODSTEasyjet_region").val();
	var c = jQuery(f).find("#wpODSTEasyjet_country").val();
	this.sendToEditorV2('[odst type="properties" display="carousel" country="' + c + '" region="' + r + '"]');
	return false;
	},
	insertRegionDirectory : function(f) {	
	var r = jQuery(f).find("#wpODSTEasyjet_region").val();
	var c = jQuery(f).find("#wpODSTEasyjet_country").val();
	this.sendToEditorV2('[odst type="properties" display="directory" country="' + c + '" region="' + r + '"]');
	return false;
	},
	insertContextualCarousel : function(f) {	
	this.sendToEditorV2('[odst type="properties" display="carousel" region="contextual"]');
	return false;
	},
	insertContextualDirectory : function(f) {	
	this.sendToEditorV2('[odst type="properties" display="directory" region="contextual"]');
	return false;
	},
	showRegions : function(c,regionddl,resortddl,addAll) {
	if ( this.autoUpdateCountryRegionResort == false ) { return; }
	
	jQuery(regionddl).empty();		
	jQuery(regionddl).attr('disabled', '');
	jQuery(regionddl).append(jQuery('<option></option>').val('loading').html('Loading regions...'));
	
	if( addAll == true || jQuery(regionddl).hasClass('all')) {
		jQuery(regionddl).append(jQuery('<option></option>').val('').html('Any'));
		}
	
	jQuery(resortddl).empty();	
	jQuery(resortddl).attr('disabled', '');
	jQuery.ajax({
		url: odst_settings.api_proxy + '?source=' + odst_settings.source + '&type=regions&country=' + c,
		dataType: "xml",
		context: {ddl:regionddl, resortddl:resortddl},
		success: function(data) {
			var regionddl = jQuery(this.ddl);
			jQuery(data).find('region').each(function() { var r = jQuery(this).find('name').text(); regionddl.append(jQuery('<option></option>').val(r).html(r)); });
			regionddl.removeAttr('disabled');
			regionddl.find("option[value='loading']").remove();		
		
			if(regionddl.find("option").size()==2 && regionddl.find("option[value='']").size() ==1)
							{
							regionddl.val(regionddl.find("option:last").val());
							}					

			wpODSTEasyjetAdminObj.showResorts(regionddl.val(),this.resortddl);
			}
	
		});
	return false;
	},
	showResorts : function(r,resortddl) {
	if ( this.autoUpdateCountryRegionResort == false ) { return; }
	
	jQuery(resortddl).empty();	
	jQuery(resortddl).append(jQuery('<option></option>').val('loading').html('Loading resorts...'));	
	jQuery(resortddl).append(jQuery('<option></option>').val('').html('Any'));
	jQuery(resortddl).attr('disabled', '');	
	jQuery.ajax({
		url: odst_settings.api_proxy + '?source=' + odst_settings.source + '&type=resorts&rgion=' + r,
		dataType: "xml",
		context: {ddl:resortddl},
		success: function(data) {
			var resortddl = jQuery(this.ddl);
			jQuery(data).find('resort').each(function() { var r = jQuery(this).find('name').text(); resortddl.append(jQuery('<option></option>').val(r).html(r)); });
			resortddl.find("option[value='loading']").remove();			
			if(resortddl.find("option").size()==2 && resortddl.find("option[value='']").size() ==1)
				{
				resortddl.val(resortddl.find("option:last").val());
				}
				
			resortddl.removeAttr('disabled');
			
			}		
		});
	return false;
	},
	toggle_show_dropdowns: function(div,ddl) {
	if( ddl.val() == 'contextual' ) {
		div.hide();
		}
	else{
		div.show();
		}
	}
}
 
var wpODSTEasyjetAdminObj = new wpODSTEasyjetAdmin();

			jQuery(document).ready(function() {
				wpODSTEasyjetAdminObj.init();
			});

			
			