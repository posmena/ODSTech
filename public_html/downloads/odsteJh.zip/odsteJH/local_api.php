<?php
/*
This file is a localised version of the ODST API used by the plugin to access the properties stored on a local database
*/

header('Content-type: text/xml');

if (!file_exists('../../../wp-config.php')) die ('wp-config.php not found');
require_once('../../../wp-config.php');


$source 		= mysql_real_escape_string($_GET['source']);
$type 			= mysql_real_escape_string($_GET['type']);
$region 		= mysql_real_escape_string($_GET['rgion']);$resort 		= mysql_real_escape_string($_GET['resort']);
$name 			= mysql_real_escape_string($_GET['name']);
$country 		= mysql_real_escape_string($_GET['country']);
$propertyid 	= mysql_real_escape_string($_GET['propertyid']);
$limit 			= mysql_real_escape_string($_GET['limit']);
$page 			= mysql_real_escape_string($_GET['page']);
if( !is_numeric($page) )
	{
	$page = 1;
	}
$page = $page -1;
	
global $wpdb;
$table_name = $wpdb->prefix . "odst_" . $source . "_properties";	
				
echo '<?xml version="1.0"?>';

switch ($type) {		
		case 'countries':{
			  $sql = "select distinct country from " . $table_name . " order by country asc " ;				
						
			  $result = $wpdb->get_results($sql);
			  echo('<countries>');
			  foreach ( $result as $country ) {
					echo '<country><name>' . $country->country . '</name></country>';
				}
			  echo('</countries>');
			  break;
		}	
		case 'regions':{
		  $sql = "select distinct region from " . $table_name . " where country='" . $country . "' order by region asc " ;				
					
		  $result = $wpdb->get_results($sql);
		  echo('<regions>');
		  foreach ( $result as $region ) {
				echo '<region><name>' . $region->region . '</name></region>';
			}
		  echo('</regions>');
		  break;
		}	
		case 'resorts':{
		  $sql = "select distinct resort,resortid from " . $table_name . " where region='" . $region . "' order by resort asc " ;				
					
		  $result = $wpdb->get_results($sql);
		  echo('<resorts>');
		  foreach ( $result as $resort ) {
				echo '<resort><name>' . $resort->resort . '</name><id>' . $resort->resortid . '</id></resort>';
			}
		  echo('</resorts>');
		  break;
		}	
		case 'properties':{
			 
			 $sql = " from " . $table_name . " where 1=1 ";
			 if ( $country != "null" && $country != "loading" && $country != "" && $country != "All" && $country != "Any") { $sql = $sql . " AND country='" . $country . "' " ;}				
			 if ( $region != "null" && $region != "loading" &&  $region != "" && $region != "All" && $region != "Any") { $sql = $sql . " AND region='" . $region . "' " ;}				
			 if ( $resort != "null" && $resort != "loading" &&  $resort != "" && $resort != "All" && $resort != "Any" ) { $sql = $sql . " AND resort='" . $resort . "' " ;}				
			 if ( $name != "" ) { $sql = $sql . " AND ( name like('%" . $name . "%') or country like('%" . $name . "%') or region like('%" . $name . "%') or resort like('%" . $name . "%') )" ; }	
			 
			 $count = $wpdb->get_var("select count(*) " . $sql );
			 
			 $sql = "select * " . $sql;
	
			 if ( is_numeric($limit) ) { $sql = $sql . " limit " . $page*$limit . "," . $limit; }
			 
			 $result = $wpdb->get_results($sql);
			  echo('<properties>');
			  echo('<count>' . $count . '</count>');
			  
			  foreach ( $result as $property ) {
					echo '<property>';
					echo '<id>' . $property->id . '</id>';
					echo '<name>' . htmlspecialchars($property->name) . '</name>';
					echo '<resort>' . $property->resort . '</resort>';
					echo '<resortid>' . $property->resortid . '</resortid>';
					echo '<region>' . $property->region . '</region>';
					echo '<country>' . $property->country . '</country>';
					echo '<rating>' . $property->rating . '</rating>';
					echo '<hoteltype>' . $property->hoteltype . '</hoteltype>';
					echo '<airportcode>' . $property->airportcode . '</airportcode>';
					echo '<image1url>' . $property->image1url . '</image1url>';
					echo '<image2url>' . $property->image2url . '</image2url>';
					echo '<image3url>' . $property->image3url . '</image3url>';
					echo '<description>' . htmlspecialchars($property->description) . '</description>';
					echo '<address>' . htmlspecialchars($property->address) . '</address>';
					echo '<postcode>' . $property->postcode . '</postcode>';
					echo '<propertyid>' . $property->propertyid . '</propertyid>';
					echo '<price>' . $property->price . '</price>';
					echo '<url>' . $property->url . '</url>';
					
					echo '</property>';
				}
			  echo('</properties>');	
			  break;
		}	
		case 'property':{
			$sql = "select * from " . $table_name . " where id='" . $propertyid . "'";				
					
			$result = $wpdb->get_results($sql);
			echo('<properties>');
			foreach ( $result as $property ) {
				echo '<property>';
					echo '<id>' . $property->id . '</id>';
					echo '<name>' . htmlspecialchars($property->name) . '</name>';
					echo '<resort>' . $property->resort . '</resort>';
					echo '<resortid>' . $property->resortid . '</resortid>';
					echo '<region>' . $property->region . '</region>';
					echo '<country>' . $property->country . '</country>';
					echo '<rating>' . $property->rating . '</rating>';
					echo '<hoteltype>' . $property->hoteltype . '</hoteltype>';
					echo '<airportcode>' . $property->airportcode . '</airportcode>';
					echo '<image1url>' . $property->image1url . '</image1url>';
					echo '<image2url>' . $property->image2url . '</image2url>';
					echo '<image3url>' . $property->image3url . '</image3url>';
					echo '<description>' . htmlspecialchars($property->description) . '</description>';
					echo '<address>' . htmlspecialchars($property->address) . '</address>';
					echo '<postcode>' . $property->postcode . '</postcode>';
					echo '<propertyid>' . $property->propertyid . '</propertyid>';
					echo '<price>' . $property->price . '</price>';
					echo '<url>' . $property->url . '</url>';
					
					echo '</property>';
			}
			echo('</properties>');
			break;			  
		}	
    }
		
		
?>