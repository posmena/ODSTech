<?php

if (!file_exists('../../../wp-config.php')) die ('wp-config.php not found');
require_once('../../../wp-config.php');

  if( !class_exists( 'odst_easyjet' ) )
        include_once( 'class.odst-easyjet.php' );

$searchTerm = mysql_real_escape_string($_GET["q"]);
$page = mysql_real_escape_string($_GET["p"]);
$region = mysql_real_escape_string($_GET["rgion"]);
$resort = mysql_real_escape_string($_GET["resort"]);
$country = mysql_real_escape_string($_GET["country"]);

if ( !is_numeric($page) ) { 
	$page = 1; 
	}

$options = get_option('odst_options');			
$obj = new odst_easyjet($options);	

$limit = 10;
$myxml = $obj->search_hotels($searchTerm,$country,$region,$resort,$limit,$page);

?>

<html>
<head>
<link type="text/css" rel="stylesheet" href="./css/odst_admin.css" />
</head>
<body>
<div id="hotelsearch">
<h1>Search results</h1>
<div id="hotelsearchresults">
<?php 
if( $myxml->count > 0 )
{
if ( $myxml->count == 1) { echo '1 property found' ; }
else { echo $myxml->count . ' properties found'; }

foreach ($myxml->property as $property) {		
		echo '<div class="title"><b>' . $property->name . '</b> | ' . $property->resort . ' | ' . $property->region . ' | ' . $property->country . '</div>';
		echo '<img class="photo" src="'. plugins_url( '/timthumb.php', __FILE__ ) . '?src=' . $property->image1url . '&w=80"/>';
		echo '<div class="description">' . $obj->myTruncate($property->description,80) . '</div>';
		
?>

<div class="actions">
<a href="#" onclick="wpODSTEasyjetAdminObj.addHotelImage('<?php echo $property->image1url;?>');alert('The image has been inserted into the post content');return false;">Insert image</a>
<a href="#" onclick="wpODSTEasyjetAdminObj.addHotelAsProduct('<?php echo $property->name?>','<?php echo $obj->deeplink . urlencode($property->url)?>','<?php echo str_replace("'","''",$obj->myTruncate($property->description,120));?>','<?php echo plugins_url('',__FILE__) . '/timthumb.php?src=' . $property->image1url . '&w=120';?>','<?php echo $property->id;?>','<?php echo $property->rating;?>');parent.tb_remove();alert('The hotel has been inserted into the post content');return false;">Add as product</a> | 
<a href="#" onclick="wpODSTEasyjetAdminObj.addHotelAsPost(document,'<?php echo $property->name?>','<?php echo $obj->deeplink . urlencode($property->url)?>','<?php echo str_replace("'","''",$property->description);?>','<?php echo plugins_url('',__FILE__) . '/timthumb.php?src=' . $property->image1url . '&w=120';?>','<?php echo $property->id;?>','<?php echo $property->rating;?>');parent.tb_remove();return false">Add as post</a>
</div>

<?php } ?>
</div>
<div class="paging">
Page: 
<?php 		
	$totalPages = ceil($myxml->count / $limit);
	for ( $i=1; $i<= $totalPages; $i += 1 )
		{
		echo '<a href="javascript:wpODSTEasyjetAdminObj.loadPage(\'' . plugins_url( '/findhotels.php', __FILE__ ) . '?q=' . $searchTerm . '&p=' . $i . ' #hotelsearch\')">' . $i . '</a> ';		
		}
?>
</div>
<?php
	}
	else {
	echo 'Sorry, no results were found for your search term';
	}
	
?>
</body>
</html>