/**
 * Handle: wpODSTEasyjet
 * Version: 0.0.1
 * Deps: jquery
 * Enqueue: true
 */
 
 
 function showRegions(c,regionddl,resortddl) {
	var defaultVal= '';
	
	regionddl.empty();	
	regionddl.attr('disabled', '');
	regionddl.append(jQuery('<option></option>').val('loading').html('Loading regions...'));
	
	if( regionddl.hasClass('all') ) {regionddl.append(jQuery('<option></option>').val('').html('Any'))};
	jQuery.ajax({
		url: odst_easyjet_settings.api_proxy + '?source=' + odst_easyjet_settings.source + '&type=regions&country=' + c,
		dataType: "xml",
		context: {ddl:regionddl, resddl:resortddl, defaultValue:defaultVal},
		success: function(data) {			
			var regionddl = this.ddl;
			jQuery(data).find('region').each(function() { var r = jQuery(this).find('name').text(); regionddl.append(jQuery('<option></option>').val(r).html(r)); });
			regionddl.removeAttr('disabled');
			if( this.defaultValue != '' ) { regionddl.val(defaultVal) }
		
			regionddl.find("option[value='loading']").remove();			
			if(regionddl.find("option").size()==2 && regionddl.find("option[value='']").size() ==1)
							{
							regionddl.val(regionddl.find("option:last").val());
							}
							
				showResorts(regionddl.val(),this.resddl);
			
			}		
		});		
	return false;
	}
	
function showResorts(rg,resortddl) {
    var defaultVal= '';
	if ( resortddl.find("option:selected").text() == 'loading...' )
		{
		defaultVal = resortddl.find("option:selected").val();
		}
	
	resortddl.empty();	
	resortddl.attr('disabled', '');
	resortddl.append(jQuery('<option></option>').val('loading').html('Loading resorts...'));
	resortddl.append(jQuery('<option></option>').val('').html('Any'));
	jQuery.ajax({
		url: odst_easyjet_settings.api_proxy + '?source=' + odst_easyjet_settings.source + '&type=resorts&rgion=' + rg,
		dataType: "xml",
		context: {ddl:resortddl, defaultValue:defaultVal},
		success: function(data) {			
			var resortddl = this.ddl;
			jQuery(data).find('resort').each(function() { var r = jQuery(this).find('name').text(); var id = jQuery(this).find('id').text(); resortddl.append(jQuery('<option></option>').val(r + ':' + id).html(r)); });
			resortddl.removeAttr('disabled');
			if( this.defaultValue != '' ) { resortddl.val(defaultVal) }
			resortddl.find("option[value='loading']").remove();	
			if(resortddl.find("option").size()==2 && resortddl.find("option[value='']").size() ==1)
				{
				resortddl.val(resortddl.find("option:last").val());
				}
			}		
		});
	return false;
	}	
	
function showChildAges(numChildren, divContainer)
{
c1 = divContainer.find("select.odst_child1_age");
c2 = divContainer.find("select.odst_child2_age");
c3 = divContainer.find("select.odst_child3_age");
c4 = divContainer.find("select.odst_child4_age");

if( numChildren > 0 ) {
divContainer.show();
c1.show();
if( numChildren > 1 )
	{
	c2.show();
	if( numChildren > 2 )
		{
		c3.show();
		if( numChildren > 3 )
			{
			c4.show();
			}
			else
			{
			c4.hide();
			}
		}
		else
		{
		c3.hide(); c4.hide();
		}
	}
	else
	{
	c2.hide(); c3.hide(); c4.hide();
	}
}
else
{
divContainer.hide();
}

}	

function toggle_show_dropdowns(div,ddl) {
	if( ddl.val() == 'contextual' ) {
		div.hide();
		}
	else{
		div.show();
		}
	}
	
jQuery(document).ready(function(){	

	jQuery(".slider").each(function() { 
		var slider = jQuery(this);
		if ( slider.hasClass('vertical') ) {
				slider.easySlider({
					vertical:true,
					auto: true,
					continuous: true ,
					overrideheight: false,
					controlsShow: true
				});
			}
		else{
			slider.easySlider({
					auto: true,
					continuous: true ,
					overridewidth: false,					
					controlsShow: true 
				});
		}
		
		});
		
	/*jQuery(".slider").easySlider({
		auto: true,
		continuous: true ,
		overridewidth: false,
		controlsShow: false
	});*/
	
});



function setup_country_region_resort_dropdowns(initialise)
{
jQuery(".odst_country_region").each(function(){
	
     var div = jQuery(this);
	
	 if( initialise )
		{
		//if it has initial values then select in dropdowns, otherwise fill by ajax
		var hasValues = false;
		if( div.find("input[type=hidden].odst_country_has_initial_values").length > 0)	
			{
			hasValues = div.find("input[type=hidden].odst_country_has_initial_values").val();
			}
		if ( hasValues == 'true' )
			{
			div.find('select.odst_country').val(div.find("input[type=hidden].odst_country_initial_val").val());
			div.find('select.odst_region').val(div.find("input[type=hidden].odst_region_initial_val").val());
			div.find('select.odst_resort').val(div.find("input[type=hidden].odst_resort_initial_val").val());			
			}
		else
			{
			showRegions(div.find("select.odst_country").val(),div.find("select.odst_region"),div.find("select.odst_resort"));
			}
	    }
	 
		// bind events
		div.find('select.odst_country').change(function(){	   
		showRegions(jQuery(this).val(),div.find("select.odst_region"),div.find("select.odst_resort"));
		})
		     
		div.find('select.odst_region').change(function(){	    
		showResorts(jQuery(this).val(),div.find("select.odst_resort"));
		})     	
		
	 })
}

function setup_show_dropdown()
{
jQuery(".odst_country_region").each(function(){
	
     var div = jQuery(this);
	 
	 div.find('select.odst_format_select').change(function(){	 
	    toggle_show_dropdowns(div.find('div.country_region_resort_group'),jQuery(this));
		})
		
	 toggle_show_dropdowns(div.find('div.country_region_resort_group'),div.find('select.odst_format_select'));
		
	 })
}
	 
	 
jQuery(document).ready(function() {

setup_country_region_resort_dropdowns(true);
setup_show_dropdown();
	 
	 jQuery("div.odst_ej_search").each(function(){
	    var div = jQuery(this);
	    jQuery(this).find('select.children').change(function(){	    
		showChildAges(jQuery(this).val(),div.find("div.odst_f_child_ages"));
		})

		showChildAges(div.find('select.children').val(),div.find("div.odst_f_child_ages"));
	
	 });
	 
	 

});

