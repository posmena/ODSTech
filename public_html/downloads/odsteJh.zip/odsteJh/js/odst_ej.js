/**
 * Handle: wpODSTEasyjet
 * Version: 0.0.1
 * Deps: jquery
 * Enqueue: true
 */
 
 
 function ODST_Search_Easyjet(e){
 var div = jQuery(e).closest("div.odst_ej_search");
 var dt = div.find("#odst_date_day").val() + '/' + div.find("#odst_date_month_year").val();
 var nights = div.find("#odst_duration").val();
 var adults = div.find("#odst_adults").val();
 var airport = div.find("#odst_ej_departure_aiport").val();
 var region = div.find("#odst_widget_ps_region").val();
 var resortStr = div.find("#odst_widget_ps_resort").val();
 var resortArr = resortStr.split(':');
 var resort = '';
if ( resortArr.length > 1 ) 
{
	resort = resortArr[1];
} 

 var children = div.find("#odst_children").val(); 
 var ages = '';
 if (children == 1) { ages = div.find("#odst_child1_age").val(); }
 if (children == 2) { ages = ages + ',' + div.find("#odst_child2_age").val(); }
 if (children == 3) { ages = ages + ',' + div.find("#odst_child3_age").val(); }
 if (children == 4) { ages = ages + ',' + div.find("#odst_child4_age").val(); }
 
 var infants = div.find("#odst_infants").val();
 
 var url;
 url = 'http://holidays.easyjet.com/dl.aspx?mode=FlightPlusHotel&depdate=' + dt + '&nights=' + nights + '&adults=' + adults + '&airport=' + airport + '&children=' + children + '&childages=' + ages + '&infants=' + infants;
 
 if ( resort != '' ) { url = url + '&resort=' + resort ; }
 else { url = url + '&region=' + region ; }

 url = odst_easyjet_settings.dl + encodeURI(url);
 window.open(url, '')
 }
 

jQuery(document).ajaxComplete(function(e, xhr, settings) {
var widget_id_base = 'odst_easyjet_content_unit';

if( settings != undefined ){
	if( settings.data != undefined ){
			if(settings.data.search('action=save-widget') != -1 && settings.data.search('id_base=odst_easyjet_content_unit') != -1) {
			setup_show_dropdown();
			setup_country_region_resort_dropdowns(false);
			}
			
			if(settings.data.search('action=save-widget') != -1 && settings.data.search('id_base=odst_easyjet_searchbox') != -1) {
			setup_show_dropdown();
			setup_country_region_resort_dropdowns(false);
			}

		}
	}
});
