<?php
/*
Plugin Name: ODST Octopus Tools
Plugin URI: http://www.odst.co.uk
Description: Add Octopus properties to your site.
Version: 1.2.06
Author: ODST
Author URI: http://www.odst.co.uk
*/

/*
Log entry: 18th July 2011
First bash
*/
include "class.odst-octopus.php";

class ODSTOctopusLoader
{
	private $property_remote = 'http://www.odst.co.uk/feeds/octopus.zip?propertylist=true';
	private $property_local = 'wp-content/plugins/odstoctopus/propertyfeed.csv.zip';
	
	protected $odst_octpus;

	
	function ODSTOctopusLoader()
	{		
		$filename = str_replace('\\', '/',__FILE__);
		$filename = preg_replace('/^.*wp-content[\\\\\/]plugins[\\\\\/]/', '', $filename);
	    
		$options = get_option('odst_options');		
		
		$this->odst_octopus = new odst_octopus($options);		
	
		$classname = "ODSTOctopusLoader";
		//add the admin action
		add_action('admin_menu', array(&$this, 'odst_menu'));
		
		add_action( 'add_meta_boxes', array(&$this, 'add_some_meta_box') );
		

		// check for products to add to post
		add_filter('odst_widget_searchbox_content', array('ODSTOctopusLoader', 'get_widget_searchbox_contents'), 11, 6);
		add_filter('odst_widget_holidays_content', array('ODSTOctopusLoader', 'get_widget_holidays_contents'), 11, 7);
		
		add_filter('media_buttons_context', array(&$this,'odst_add_media_button'));
		
	    wp_register_style('odst_admin_style', plugins_url( '/css/odst_admin.css', __FILE__ ));		
		wp_register_style('odst_octopus_style', plugins_url( '/css/octopus.css', __FILE__ ));		
		wp_register_style('odst_style', plugins_url( '/css/odst.css', __FILE__ ));
		wp_register_style('odst_carousel_style', plugins_url( '/css/odst_carousel.css', __FILE__ ));
		
		wp_enqueue_style('odst_style');
		wp_enqueue_style('odst_carousel_style');
		wp_enqueue_style('odst_admin_style');		
		wp_enqueue_style('odst_octopus_style');			   	  
																 
		wp_register_script('wpODSTOctopus', plugins_url( '/js/odst_octopus.js', __FILE__ ),array('jquery'), '1.0.0');
		wp_register_script('wpODST', plugins_url( '/js/odst.js', __FILE__ ),array('jquery'), '1.0.0');
		wp_enqueue_script('wpODST');
		wp_enqueue_script('wpODSTOctopus');
		wp_localize_script( 'wpODSTOctopus', 'odst_octopus_settings', array(
	  	                                                           'api_proxy' => plugins_url( '/api_proxy.php', __FILE__ ),
																   'source' => 'octopus',
																   'dl' => $this->odst_octopus->deeplink,
																   'findhotels_url' => plugins_url( '/findhotels.php', __FILE__ )
		                                                         ));		
		
		wp_register_script('easyslider', plugins_url( '/js/easySlider1.7.js', __FILE__ ),array('jquery'), '1.0.0');
		wp_enqueue_script('easyslider');
		
		add_action('odst_daily_update', array(&$this, 'odst_octopus_daily_update'));
		add_action('odst_hourly_update', array(&$this, 'odst_octopus_hourly_update'));
		register_activation_hook( __FILE__, array('ODSTOctopusLoader', 'odst_octopus_install') );
		register_deactivation_hook( __FILE__, array('ODSTOctopusLoader', 'odst_octopus_uninstall') );
			
		add_shortcode( 'odst', array('ODSTOctopusLoader', 'odst_short_code') );
		
		add_filter('admin_print_scripts', array('ODSTOctopusLoader', 'adminHead') );
		
		add_action('admin_footer', array(&$this,'odst_octopus_overlay_popup_form'));
	
		wp_enqueue_script( 'jquery-ui-core' );
		wp_enqueue_script( 'jquery-ui-tabs' );
		
		
		add_action( 'widgets_init', array(&$this,'odst_octopus_register_widgets') );
		
		add_action('admin_head', array(&$this,'update_settings_action_javascript'));
	    add_action('admin_head', array(&$this,'update_properties_action_javascript'));
	
		add_action('wp_ajax_my_action', array(&$this, 'wp_ajax_my_action_callback'));	

		add_action( 'wp_dashboard_setup', array(&$this,'odstnews_add_dashboard_widgets' ));
		add_action( 'wp_head', array(&$this,'add_ie9_meta' ), 5 );		
	}
	
function add_ie9_meta()
{
echo '<meta http-equiv="X-UA-Compatible" content="IE=edge" />';
}
	function update_settings_action_javascript()
	{
	?>
	<script type="text/javascript" >
	function update_odst_settings(){
			
			var username = jQuery('#odst_username').val();
			var password = jQuery('#odst_password').val();
			var webgainsid = jQuery('#odst_webgains_id').val();
			var background_colour = jQuery('#odst_background_colour').val();
			var border_colour = jQuery('#odst_border_colour').val();
			var hotel_bg_colour = jQuery('#odst_hotel_bg_colour').val();
			var hotel_colour = jQuery('#odst_hotel_colour').val();
			var price_colour = jQuery('#odst_price_colour').val();
			var location_colour = jQuery('#odst_location_colour').val();
			var even_row_colour = jQuery('#odst_even_row_colour').val();
			var odd_row_colour = jQuery('#odst_odd_row_colour').val();
			
			
			var data = {
			action: 'my_action',
			my_action: 'update_options',
			username: username,
			password: password,
			webgainsid: webgainsid,
			background_colour: background_colour,
			border_colour: border_colour,
			hotel_bg_colour: hotel_bg_colour,
			hotel_colour: hotel_colour,
			price_colour: price_colour,
			location_colour: location_colour,
			even_row_colour: even_row_colour,
			odd_row_colour: odd_row_colour
			
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(response) {	
						jQuery("#odst_options_updated").show();
		});
	}
	</script>
	<?php
	}
	
	function update_properties_action_javascript()
	{
	?>
	<script type="text/javascript" >
	function update_odst_properties(){
			
			jQuery('#odst_saving_img').css('display','inline');
			var username = jQuery('#odst_username').val();
			var password = jQuery('#odst_password').val();
			
			
			var data = {
			action: 'my_action',
			my_action: 'update_properties',
			username: username,
			password: password			
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(response) {
			jQuery('#odst_saving_img').css('display','none');
			if( response == 'true' )	{				
				jQuery("#odst_properties_updated").show();
				jQuery("#odst_properties_not_updated").hide();			
				}
			else{
				jQuery("#odst_properties_not_updated").html(response);
				jQuery("#odst_properties_not_updated").show();			
				jQuery("#odst_properties_updated").hide();
			}
		});
	}
	</script>
	<?php
	
	}
	
	function wp_ajax_my_action_callback()
	{
	
		switch($_POST['my_action']) {
				case "update_options":
					$this->update_odst_settings_callback();
				break;
				
				case "update_properties":
					$this->update_odst_properties_callback();
					break;
					}
	}

function update_odst_settings_callback() {
	global $wp_rewrite;
	
		$options['odst_username'] = $_POST['username'];
		$options['odst_password'] = $_POST['password'];
		$options['odst_webgains_id'] = $_POST['webgainsid'];
		$options['background_colour'] = $_POST['background_colour'];
		$options['border_colour'] = $_POST['border_colour'];
		$options['hotel_bg_colour'] = $_POST['hotel_bg_colour'];
		$options['hotel_colour'] = $_POST['hotel_colour'];
		$options['price_colour'] = $_POST['price_colour'];
		$options['location_colour'] = $_POST['location_colour'];
		$options['even_row_colour'] = $_POST['even_row_colour'];
		$options['odd_row_colour'] = $_POST['odd_row_colour'];
		
			
			update_option('odst_options', $options);
			$wp_rewrite->flush_rules();
														
        echo 'true';

	die(); // this is required to return a proper result
	}

	
function update_odst_properties_callback() {
	global $wpdb; // this is how you get access to the database

	$username = $_POST['username'] ;
	$password = $_POST['password'] ;
						
	$this->odst_octopus->username = $username;
	$this->odst_octopus->password = $password;
		
	$result = $this->odst_octopus_update_hotels();
	
	if ( is_wp_error( $result ) ) {
		   $error_string = $result->get_error_message();
		   echo 'Properties not updated ' . $error_string . '';		  
		}	
	else
		{
			echo('true');
		}
   			      

	die(); // this is required to return a proper result
	}
	
	function odst_octopus_register_widgets()
	{
		if ( $this->odst_octopus->count_properties() > 0 )
			{
			//register_widget( 'ODST_octopus_SearchBox' );
			register_widget( 'ODST_octopus_Content_Unit' );
			}
	}
	
	function odst_add_media_button($context) {
	
  $icon_url = WP_PLUGIN_URL . '/' . str_replace(basename( __FILE__),"",plugin_basename(__FILE__)) . '/img/icon-hotel.jpg';
    
    
  if( $this->odst_octopus->count_properties() == 0 )
{

    $result = '<img style="padding-left:7px" onclick="alert(\'Please configure ODST settings first\')"; src="'.$icon_url.'" alt="'. __('Please configure ODST settings first') .'" title="'. __('Please configure ODST settings first') .'" />';
    return $context . $result;
}


    //$result = '<a href="' . WP_PLUGIN_URL . '/' . str_replace(basename( __FILE__),"",plugin_basename(__FILE__)) . 'odst_ej_insert_content_unit.php?type=gimb_image&amp;TB_iframe=1" class="thickbox" title="' . __('Add Octopus content') . '"><img src="'.$icon_url.'" alt="'. __('Add Octopus Content Unit') .'" title="'. __('Add Octopus Content Unit') .'" /></a>';
    $result = '<a href="#TB_inline?width=540&height=560&inlineId=odst_insert_octopus_content" class="thickbox" title="' . __('Add Octopus content') . '"><img src="'.$icon_url.'" alt="'. __('Add Octopus Content Unit') .'" title="'. __('Add Octopus Content Unit') .'" /></a>';
      //  $output_link = '<a href="#TB_inline?width=450&inlineId=people_lists_select_list_form" class="thickbox" id="add-people-list-button" title="' . __("Add People List", 'people-lists') . '"><img src="'.$people_lists_overlay_image_button.'" alt="' . __("Add People List", 'people-lists') . '" /></a>';
    
    
    return $context . $result;
}

function odst_octopus_overlay_popup_form(){
	//$option_name = 'people-lists'; 
	//$people_list_option = get_option($option_name);
    
	if ($GLOBALS['editing']) {
	 echo '<div id="odst_insert_octopus_content" style="display:none">
	<div id="odst-tabs-octopus" class="odst-tabs">
        <ul> 
				<li><a href="#contentunits" tabindex="3">Content Units</a></li> 
				<li><a href="#hotels" tabindex="3">Find Hotel</a></li> 
				
			</ul> 			
			<div class="odst_country_region" id="contentunits">
				<label>Display:</label>
				<select name="wpODSTOctopus[display]" id="wpODSTOctopus_display4">
							<option selected="selected" value="directory">Directory</option>
							<option value="carousel">Carousel</option>
						</select>
				<div class="clear"></div>
				<label>Format:</label>
				<select class="odst_format_select" name="wpODSTOctopus[format]" id="wpODSTOctopus_format4">
							<option selected="selected" value="region">Specify City</option>
							<option value="contextual">Contextual</option>
						</select>
				<div class="clear"></div>
				<label>Style:</label>
				<select name="wpODSTOctopus[style]" id="wpODSTOctopus_style4">
							<option selected="selected" value="default">Default Style</option>
							<option value="octopus">Octopus Branded</option>
						</select>
				
				<div class="clear"></div>
				<label>Width:</label>
				<input id="wpODSTOctopus_width4" type="text" style="" name="wpODSTOctopus[contentWidth]"/>
				<div class="clear"></div>
				<div class="country_region_resort_group" id="wpODSTOctopus_fixed4">
				<div class="clear"></div>
				<label>Country:</label>
				<select name="wpODSTOctopus[country]" id="wpODSTOctopus_country4">
							' .  $this->odst_octopus->get_countries_ddl() 
							. '
						</select>
				<div class="clear"></div>
				<label>City:</label>
				<select class="all" name="wpODSTOctopus[region]" id="wpODSTOctopus_region4" disabled="true"></select>
				<div class="clear"></div>
				<div style="display:none">
				<label>Resort:</label>
				<select name="wpODSTOctopus[resort]" id="wpODSTOctopus_resort4" disabled="true"></select>				
				</div>
				</div>
				
				<div class="clear"></div>
				<label>Max Properties:</label>
				<input id="wpODSTOctopus_maxproperties4" type="text" value="10" style="" name="wpODSTOctopus[maxproperties]"/>
				
				
				<div class="actions">
				<input type="button"  class="button" onclick="return wpODSTOctopusAdminObj.insertContentUnit(jQuery(\'#odst-tabs-octopus #contentunits\'),\'4\');" value="Insert content unit"/>
				</div>	
			</div>		
			<div id="hotels">
				<label>Name:</label>
						<input id="wpODSTOctopus_hotelname" name="wpODSTOctopus[hotelname]" type="text" />				
				<div class="clear"></div>
					<label>Country:</label>
				<select name="wpODSTOctopus[country3]" id="wpODSTOctopus_country3"><option>Any</option>
							' .  $this->odst_octopus->get_countries_ddl() 
							. '
						</select>
				<div class="clear"></div>
				<label>City:</label>
				<select  class="all" name="wpODSTOctopus[region3]" id="wpODSTOctopus_region3" disabled="true"></select>
				<div class="clear"></div>
				<div style="display:none">
				<label>Resort:</label>
				<select name="wpODSTOctopus[resort3]" id="wpODSTOctopus_resort3" disabled="true"></select>
				</div>
				<input class="button" type="button" value="Search" onclick="return wpODSTOctopusAdminObj.showHotelSearch(jQuery(\'#hotels\'))"/>
				<img id="hotelresults_loadimg" src="' . plugins_url('/img/ajax-loader.gif',__FILE__) . '"/>
					
						
				<hr>
				<div id="hotelresults"></div>
				
			</div>
			
		</div></div>';
		}
	}


	function adminHead () {
		//if ($GLOBALS['editing']) {
			
			wp_enqueue_script('wpODSTOctopusAdmin', plugins_url( '/js/odst_admin.js', __FILE__ ), array('jquery'), '1.0.0');
			wp_localize_script( 'wpODSTOctopusAdmin', 'odst_octopus_settings', array(
																	   'api_proxy' => plugins_url( '/api_proxy.php', __FILE__ ),
																	   'source' => 'octopus',
																	   'findhotels_url' => plugins_url( '/findhotels.php', __FILE__ )
																	 ));
	   // }
	}
	 
	
function odst_octopus_uninstall() {
	wp_clear_scheduled_hook('odst_hourly_update');	
	wp_clear_scheduled_hook('odst_daily_update');
	
	global $wpdb;
    $table_name = $wpdb->prefix . "odst_octopus_properties";
	
	  $sql =  "DROP TABLE " . $table_name;
	
	  $wpdb->query($sql);		
	  
	  delete_option('odst_options');
}

/**
 * This function creates database table, schedules tasks for wp-cron and creates folder for download file and temporary files
 *
 */
function odst_octopus_install() {
    global $wpdb;
    $table_name = $wpdb->prefix . "odst_octopus_properties";
    
    if($wpdb->get_var("show tables like '$table_name'") != $table_name) {
        $sql =  "CREATE TABLE `$table_name` (
                `id` INT( 5 ) NOT NULL,
                `name` VARCHAR(50) NOT NULL,
                `resort` VARCHAR( 300 ) NOT NULL,
                `resortid` INT( 5 ) NOT NULL,
                `region` VARCHAR( 300 ) NOT NULL,
                `country` VARCHAR( 300 ) NOT NULL,
                `rating` VARCHAR( 300 ) NOT NULL,
                `hoteltype` VARCHAR( 300 ) NOT NULL,
                `airportcode` VARCHAR( 300 ) NOT NULL,
                `image1url` VARCHAR( 400 ) NOT NULL,
                `image2url` VARCHAR( 400 ) NOT NULL,
                `image3url` VARCHAR( 400 ) NOT NULL,
                `description` LONGTEXT NOT NULL,
                `address` VARCHAR( 300 ) NOT NULL,
                `postcode` VARCHAR( 300 ) NOT NULL,
				`bestseller` BOOLEAN NOT NULL,
                `propertyid` VARCHAR( 300 ) NOT NULL,
                `price` FLOAT NOT NULL,
                `url` VARCHAR( 300 ) NOT NULL,                
                `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,                                
                PRIMARY KEY  (id)
                )";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
				
		//$options["odst_username"] = '';		
		//update_option('odst_options', $options);
		
		$next_time_stamp = time() + 3600;
		wp_schedule_event($next_time_stamp, 'hourly', 'odst_hourly_update');
		
		wp_schedule_event(strtotime('today 03:00'), 'daily', 'odst_daily_update');
		
		$options['background_colour'] = '#EEEEEE';
		$options['border_colour'] = '#D9D9D9';
		$options['hotel_bg_colour'] = '#0F2A3C';
		$options['hotel_colour'] = '#FFFFFF';
		$options['price_colour'] = '#373737';
		$options['location_colour'] = '#373737';
		$options['even_row_colour'] = '#EEEEEE';
		$options['odd_row_colour'] = '#F4EDED';
		
		update_option('odst_options', $options);
		
		
    }
}
	function odst_octopus_daily_update()	{
		wp_clear_scheduled_hook('odst_daily_update');	
		$this->odst_octopus_update_hotels();
		wp_schedule_event(strtotime('tomorrow 03:00'), 'daily', 'odst_daily_update');
	}
	
	function odst_octopus_hourly_update() {
	
	wp_clear_scheduled_hook('odst_hourly_update');	

	$this->odst_octopus_update_prices();
	
	$next_time_stamp = time() + 3600;
	wp_schedule_event($next_time_stamp, 'hourly', 'odst_hourly_update');

	}
	
	
	function odst_octopus_update_hotels() {
	global $wpdb;
    $start = time();
	$table_name = $wpdb->prefix . "odst_octopus_properties";
	   
	
	$xmlFile = $this->odst_octopus->get_hotels_from_odst('',5000);
	
	if ( is_wp_error( $xmlFile ) ) {
		   return $xmlFile;
		}	
		
	//if is_error_oejct()
	// return xmlfile as error string
	
	
	if( $xmlFile ){
	
		$z = new XMLReader;
		$z->open($xmlFile);

		$doc = new DOMDocument;

			// move to the first <product /> node
		$i = 1;
			while ($z->read() && $z->name !== 'hol' && $i < 5)
			{
		$i += 1;
		}
			
		while ($z->name === 'hol')
		{
		 $property = simplexml_import_dom($doc->importNode($z->expand(), true));	
		
			$sql = "insert into " . $table_name . "(id,name,resort,resortid,region,country,rating,hoteltype,airportcode,image1url,image2url,image3url,description,address,postcode,bestseller,propertyid,price,url) " .
					 "values ('" . $property->productid . "','" . str_replace("'","''",$property->productname) . "','" . '' . "','" . '' . "','" . str_replace("'","''",$property->city) . "','" . str_replace("'","''",$property->country) . "','" . $property->rating . "','" . '' . "','" . '' . "','" . $property->image_link . "','" . '' . "','" . '' . "','" . str_replace("'","''",$property->description) . "','" . str_replace("'","''",$property->extra_info) . "','" . '' . "'," . "0" . ",'" . $property->productid . "','" . $property->price . "','" . $property->deeplink . "')" .
					 " ON DUPLICATE KEY update name='" . str_replace("'","''",$property->productname) . "',resort='" . '' . "',resortid='" . '' . "',region='" . str_replace("'","''",$property->city) . "',country='" . str_replace("'","''",$property->country) . "',rating='" . $property->rating . "',hoteltype='" . '' . "',airportcode='" . '' . "',image1url='" . $property->image_link . "',image2url='" . '' . "',image3url='" . '' . "',description='" . str_replace("'","''",$property->description) . "',address='" . str_replace("'","''",$property->extra_info) . "',postcode='" . '' . "',bestseller=0,propertyid='" . $property->productid . "',price='" . $property->price . "',url='" . $property->deeplink . "'";				
							
			$wpdb->query($sql);		
			$z->next('hol'); 
		}

		$z->close();

		$regions=$wpdb->get_col( "select distinct region from " . $table_name);
		update_option('odst_octopus_regions', $regions);
	
	$countries=$wpdb->get_col( "select distinct country from " . $table_name);
	update_option('odst_octopus_countries', $countries);
	
	
		update_option('odst_octopus_last_updated',$start);
		return true;
		}
	else
		{
		return false;
		}
	}
	
	function odst_octopus_update_prices() {
	global $wpdb;
    $start = time();
	$table_name = $wpdb->prefix . "odst_octopus_properties";
	
    $last_updated = get_option('odst_octopus_last_updated');
		
	$xml = $this->odst_octopus->get_hotel_prices_from_odst('',5000);
	
	foreach( $xml->property as $property ) {
		$sql = "update " . $table_name . " set price='" . $property->price . "' where id='" . $property->id . "'";									
		$wpdb->query($sql);		
	}
	
	update_option('odst_octopus_last_updated_prices',$start);    
	}
	
	function get_widget_searchbox_contents($content = "", $id, $default_destination, $country, $region, $resort)
	{
		
		$options = get_option('odst_options');				
		$odst_octopus = new odst_octopus($options);		
		$content =  $odst_octopus->get_searchbox_widget_content($id, $default_destination,$country,$region,$resort);
		return $content;
	}
	
	function get_widget_holidays_contents($content = "", $display = "", $format = "", $style ="", $width = "", $country = "", $region = "", $resort = "", $limit = "")
	{
		$options = get_option('odst_options');				
		$odst_octopus = new odst_octopus($options);	

		global $wp_query;  
	
		$temp_query = clone $wp_query;
		rewind_posts();
		
		$pageContent = '';
		
		while (have_posts()) : the_post();
				
		   $post = $wp_query->post; // the execution page  
			$pageContent .= $post->post_title . ' ' . strip_shortcodes( $post->post_content );
			
		endwhile;
		
		$wp_query = clone $temp_query;
				
		$content =  $odst_octopus->get_holidays_widget_content($display,$format,$style,$width,$country,$region,$resort,$limit,plugins_url('',__FILE__),$pageContent);
		return $content;
	}
	
	function products_display($content='')
	{
		global $post, $wp_query, $wpdb;
		
		return $content;
	}

	function odst_menu()
	{
		// Add a new top-level menu:
		add_menu_page(__('ODST Octopus Tools','odst-top-level'), __('ODST Octopus Tools','odst-top-level'),
			'manage_options', 'odst-pro-home-octopus', array(&$this, 'odst_options') );

		// Add submenus to the custom top-level menu:
		/*
		add_submenu_page('odst-pro-home', __('View Feeds','odst-top-level'), __('View Feeds','odst-top-level'),
			'manage_options', 'odst-display-feeds', array(&$this, 'display_feeds'));
		add_submenu_page('odst-pro-home', __('Add Feed','odst-top-level'), __('Add Feed','odst-top-level'),
			'manage_options', 'odst-add-feed', array(&$this, 'add_feed'));
		add_submenu_page('odst-pro-home', __('Process Mapping','odst-top-level'), __('Process Mapping','odst-top-level'),
			'manage_options', 'odst-process-mapping',  array(&$this, 'process_mapping'));
		add_submenu_page('odst-pro-home', __('Update','odst-top-level'), __('Update','odst-top-level'),
			'manage_options', 'odst-update',  array(&$this, 'update_odst'));
		*/
	}

	function odst_options()
	{
		global $wpdb, $wp_rewrite;
		$options = get_option('odst_options');

		echo '<div id="odst_options_updated" style="display:none" class="updated fade"><p><strong>ODST Octopus settings saved.</strong></p></div>';
		echo '<div id="odst_properties_updated" style="display:none" class="updated fade"><p><strong>Property list updated</strong></p></div>';
		echo '<div id="odst_properties_not_updated" style="display:none" class="error fade"><p><strong>Property list not updated, please check username and password</strong></p></div>';				
			
	
		echo '<div class="wrap"> ';
		echo '<h2>ODST Octopus Tools</h2>';
	
		echo "<h3>Settings</h3>";
		
		echo '<p>Enter your ODST login details below, or <a href="http://odst.co.uk/signup.html" target="_blank" class="button">sign up for an account here</a></p><br>';
		
		echo '<form method="post" action="?page=odst-pro-home-octopus">';
		wp_nonce_field('pm-update-settings');
		
		echo '<table><tr>';
		echo '<td width="130px">Username: </td><td><input type="text" size="33" id="odst_username" name="options[odst_username]" value="' . $options['odst_username'] . '"/></tr><tr><td>Password:</td><td><input type="password" id="odst_password" name="options[odst_password]" value="' . $options['odst_password'] . '"/></td></tr>';
		echo '<tr><td>Webgains Affiliate ID:</td><td><input id="odst_webgains_id" type="text" name="options[odst_webgains_id]" value="' . $options['odst_webgains_id'] . '"/></td></tr>';
		echo '</table>';
		
		
		echo "<h3>Default Style</h3>";
		echo '<table>';
		echo '<tr><td width="130px">Background colour: </td><td><input type="text" id="odst_background_colour" name="options[background_colour]" value="' . $options['background_colour'] . '"/></tr>';
		echo '<tr><td>Border colour:</td><td><input type="text" id="odst_border_colour" name="options[border_colour]" value="' . $options['border_colour'] . '"/></td></tr>';
		echo '<tr><td>Hotel background colour:</td><td><input type="text" id="odst_hotel_bg_colour" name="options[hotel_bg_colour]" value="' . $options['hotel_bg_colour'] . '"/></td></tr>';
		echo '<tr><td>Hotel link colour:</td><td><input type="text" id="odst_hotel_colour" name="options[hotel_colour]" value="' . $options['hotel_colour'] . '"/></td></tr>';
		echo '<tr><td>Price colour:</td><td><input type="text" id="odst_price_colour" name="options[price_colour]" value="' . $options['price_colour'] . '"/></td></tr>';
		echo '<tr><td>Location colour:</td><td><input type="text" id="odst_location_colour" name="options[location_colour]" value="' . $options['location_colour'] . '"/></td></tr>';
		echo '<tr><td>Even row background colour:</td><td><input type="text" id="odst_even_row_colour" name="options[even_row_colour]" value="' . $options['even_row_colour'] . '"/></td></tr>';
		echo '<tr><td>Odd row background colour:</td><td><input type="text" id="odst_odd_row_colour" name="options[odd_row_colour]" value="' . $options['odd_row_colour'] . '"/></td></tr>';
		echo '</table>';
		
		echo '<table>';		
		echo '<tr><td width="130px"></td><td><input type="submit" class="button" onclick="update_odst_settings();update_odst_properties();return false;" name="info_update" value="Save Changes and Update Property List"><img style="display:none" id="odst_saving_img" src="' . plugins_url('/img/ajax-loader.gif',__FILE__) . '"/></td></tr></table>';				
		echo '</table>';
		
		echo '</form>';
		echo '</div>';
		echo '<br><br>';
		
			echo('<div class="postbox halfwidth" id="dashboard_primary">
				<div title="Click to toggle" class="handlediv"><br></div>
				<h3><span>ODST Blog</span></h3>
				<div class="inside">');
				
		$this->odstnews_dashboard_output();
					
			echo('</div></div>');

				
	}

	/**
     * Adds the meta box container
     */
    public function add_some_meta_box()
    {
	    wp_enqueue_script( 'odst_tabs', plugins_url( '/js/odst_tabs.js', __FILE__ ), array( 'jquery-ui-tabs' ) );
   
        add_meta_box( 
             'odst_octopus_tools'
            ,__('ODST Octopus Tools', 'odst_octopus_tools')
            ,array(&$this, 'render_meta_box_content' )
            ,'post' 
            ,'side'
            ,'high'
        ); 
		
		 add_meta_box( 
             'odst_octopus_tools'
            ,__('ODST Octopus Tools', 'odst_octopus_tools')
            ,array(&$this, 'render_meta_box_content' )
            ,'page' 
            ,'side'
            ,'high'
        ); 
		
    }

    /**
     * Render Meta Box content
     */
    public function render_meta_box_content() 
    {
	
		if( $this->odst_octopus->count_properties() == 0 )
			{
			echo('Please configure ODST settings first.');
			}
		else
			{
        echo '<div id="odst_cu_meta"><div id="odst-tabs" class="categorydiv metabox odst-tabs">
        <ul class="category-tabs"> 
				<li class="tabs"><a href="#contentunits_mb" tabindex="3">Content Units</a></li> 
				<li class=""><a href="#hotels_mb" tabindex="3">Find Hotel</a></li> 
				
			</ul> 			
			<div class="tabs-panel odst_country_region" id="contentunits_mb">
				<label>Display:</label>
				<select name="wpODSTOctopus[display]" id="wpODSTOctopus_display">
							<option selected="selected" value="directory">Directory</option>
							<option value="carousel">Carousel</option>
						</select><div class="clear"></div>
				<label>Format:</label>
				<select class="odst_format_select" name="wpODSTOctopus[format]" id="wpODSTOctopus_format">
							<option selected="selected" value="region">Specify City</option>
							<option value="contextual">Contextual</option>
						</select><div class="clear"></div>
				<label>Style:</label>
				<select name="wpODSTOctopus[style]" id="wpODSTOctopus_style">
							<option selected="selected" value="default">Default Style</option>
							<option value="octopus">Octopus Branded</option>
						</select><div class="clear"></div>
				<label>Width:</label>
				<input id="wpODSTOctopus_width" type="text" style="" name="wpODSTOctopus[contentWidth]"/>
				<div class="clear"></div>
				<div class="country_region_resort_group" id="wpODSTOctopus_fixed">
				<div class="clear"></div>
				<label>Country:</label>
				<select name="wpODSTOctopus[country]" id="wpODSTOctopus_country">
							' .  $this->odst_octopus->get_countries_ddl() 
							. '
						</select><div class="clear"></div>
				<label>City:</label>
				<select class="all" name="wpODSTOctopus[region]" id="wpODSTOctopus_region" disabled="true"></select>
				<div class="clear"></div>
				<div style="display:none">
				<label>Resort:</label>
				<select name="wpODSTOctopus[resort]" id="wpODSTOctopus_resort" disabled="true"></select>
				</div>
				</div>
				
				<label>Max Properties:</label>
				<input id="wpODSTOctopus_maxproperties" type="text" value="10" style="" name="wpODSTOctopus[maxproperties]"/>
				
				
				<div class="actions">
				<input type="button"  class="button" onclick="return wpODSTOctopusAdminObj.insertContentUnit(jQuery(\'#odst_cu_meta #contentunits_mb\'),\'\');" value="Insert content unit"/>
				</div>	
			</div>		
			<div id="hotels_mb" class="tabs-panel" style="display:none">
				<label>Name:</label>
						<input id="wpODSTOctopus_hotelname" name="wpODSTOctopus[hotelname]" type="text" />				
					<div class="clear"></div><label>Country:</label>
				<select name="wpODSTOctopus[country2]" id="wpODSTOctopus_country2"><option>Any</option>
							' .  $this->odst_octopus->get_countries_ddl() 
							. '
						</select>
				<div class="clear"></div><label>City:</label>
				<select  class="all" name="wpODSTOctopus[region2]" id="wpODSTOctopus_region2" disabled="true"></select>
				<div class="clear"></div>
				<div style="display:none">
				<label>Resort:</label>
				<select name="wpODSTOctopus[resort2]" id="wpODSTOctopus_resort2" disabled="true"></select>
				</div>
						<div class="actions">
						<input class="button" type="button" value="Search" onclick="return wpODSTOctopusAdminObj.showHotelSearchV1(jQuery(\'#odst_cu_meta #hotels_mb\'))"/>
						</div>
				
			</div>
			
		</div></div>';
		}
			
    }
	
	function odst_short_code( $atts ) {
		extract( shortcode_atts( array(
			'type' => '',
			'display' => '',
			'resort' => '',
			'region' => '',
			'country' => '',
			'propertyid' => '0',
			'max' => '10',
			'style' => 'default',
			'width' => '',
			'source' => ''
		), $atts ) );

		
		global $wp_query;  
		
		$temp_query = clone $wp_query;
		rewind_posts();
		
		$pageContent = '';
		
		while (have_posts()) : the_post();
		   $post = $wp_query->post; // the execution page  
			$pageContent = $post->post_title . ' ' . strip_shortcodes( $post->post_content );
			break;
		endwhile;
		
		$wp_query = clone $temp_query;
			
		$options = get_option('odst_options');			
		$odst_octopus = new odst_octopus($options);	
		$content = $odst_octopus->get_post_content($source,$type,$display,$style,$width,$resort,$region,$country,$propertyid,$max,plugins_url('',__FILE__),$pageContent);
		return $content;
			
	}
	
function odstnews_add_dashboard_widgets() {
	
	wp_add_dashboard_widget( 'odstnews_dashboard_feed', __( 'ODST News Feed', 'odst-dashboard-news' ), array(&$this,'odstnews_dashboard_output'), array(&$this,'odstnews_dashboard_setup' ));

}

function odstnews_dashboard_options() {
	
	$defaults = array( 'posts_number' => 5 );  // Default number of feed items
	if ( ( !$options = get_option( 'odstnews_dashboard_feed' ) ) || !is_array($options) )
		$options = array();
	return array_merge( $defaults, $options );

}

function odstnews_dashboard_setup() {
 
	$options = $this->odstnews_dashboard_options();
 
	if ( 'post' == strtolower($_SERVER['REQUEST_METHOD']) && isset( $_POST['widget_id'] ) && 'odstnews_dashboard_feed' == $_POST['widget_id'] ) {
		foreach ( array( 'posts_number' ) as $key )
				$options[$key] = $_POST[$key];
		update_option( 'odstnews_dashboard_feed', $options );
	}
 
	?>
 
		<p>
			<label for="posts_number"><?php _e( 'How many items would you like to display?', 'odst-dashboard-news' ); ?>
				<select id="posts_number" name="posts_number">
					<?php for ( $i = 3; $i <= 20; $i = $i + 1 )
						echo "<option value='$i'" . ( $options['posts_number'] == $i ? " selected='selected'" : '' ) . ">$i</option>";
					?>
				</select>
			</label>
 		</p>
 
	<?php
}



	
function odstnews_dashboard_output() {
	
	    $widget_options = $this->odstnews_dashboard_options();

		echo('<div id="odstnews-rss-widget" class="rss-widget">');
				
		wp_widget_rss_output(array(
			'url' => 'http://jobon.info/category/afiliate-advice/feed?format=atom',  // Loading feed
			'title' => __( 'ODST News Feed', 'odst-dashboard-news' ),
			'meta' => array( 'target' => '_new' ),
			'items' => $widget_options['posts_number'],
            		'show_summary' => 1, // 0 = false and 1 = true
            		'show_author' => 0, // 0 = false and 1 = true
           		'show_date' => 1 // 0 = false and 1 = true
		));
	
	echo '</div>';
}
}

$odst = new ODSTOctopusLoader();


class ODST_octopus_Content_Unit extends WP_Widget {
		
function ODST_octopus_Content_Unit() {
   	
	parent::WP_Widget(false, $name='ODST Octopus Content Unit');
}


function widget($args, $instance) {
	global $post;
	$post_old = $post; // Save the post object.
	
	extract( $args );
	
	$title = $instance['title'];
    	
	echo $before_widget;
	if ( $title ) {
		echo $before_title . $title . $after_title; }
	
	$content = apply_filters('odst_widget_holidays_content','',$instance['display'],$instance['format'],$instance['style'],$instance['width'],$instance['country'],$instance['region'],$instance['resort'],$instance['max']);
		echo $content;
echo $after_widget;
		
	
	$post = $post_old; // Restore the post object.
}

function update($new_instance, $old_instance) {
		
	return $new_instance;
}


function form($instance) {
$country = '';
$region = '';
$resort = '';

if ( $instance ) {
$country = $instance['country'];
$region = $instance['region'];
$resort = $instance['resort'];
}
else {
$country = 'Belgium';
$region = 'Brussels';
$resort = '';
}

$options = get_option('odst_options');		
$odst_octopus = new odst_octopus($options);	
	
?><div id="contentunits" class="odst_country_region" >
				<label for="<?php echo $this->get_field_id("title"); ?>">
				<?php _e( 'Title' ); ?>:</label>
				<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />			
						
				<label>Display:</label>
				<select id="<?php echo $this->get_field_id("display"); ?>" name="<?php echo $this->get_field_name("display"); ?>" >
							<option <?php selected( $instance["display"], "directory" ); ?> value="directory">Directory</option>
							<option <?php selected( $instance["display"], "carousel" ); ?> value="carousel">Carousel</option>
							
						</select>
				<label>Format:</label>
				<select class="odst_format_select" id="<?php echo $this->get_field_id("format"); ?>" name="<?php echo $this->get_field_name("format"); ?>" >
							<option <?php selected( $instance["format"], "resort" ); ?> value="resort">Specify City</option>
							<option <?php selected( $instance["format"], "contextual" ); ?> value="contextual">Contextual</option>
						</select>
				<label>Style:</label>
				<select id="<?php echo $this->get_field_id("style"); ?>" name="<?php echo $this->get_field_name("style"); ?>" >
							<option <?php selected( $instance["style"], "default" ); ?> value="default">Default Style</option>
							<option <?php selected( $instance["style"], "octopus" ); ?> value="octopus">Octopus Branded</option>
						</select>
				<label>Width:</label>
				<input id="<?php echo $this->get_field_id("width"); ?>" name="<?php echo $this->get_field_name("width"); ?>" type="text" style="" value="<?php echo esc_attr($instance["width"]); ?>"/>
				
				<div class="div_search_fixed country_region_resort_group">
				<label>Country:</label>
				<select class="odst_country" id="<?php echo $this->get_field_id("country"); ?>" name="<?php echo $this->get_field_name("country"); ?>" >
							<?php echo $odst_octopus->get_countries_ddl($country); ?>
						</select>
						
				<label>City:</label>
				<select class="odst_region all"  id="<?php echo $this->get_field_id("region"); ?>" name="<?php echo $this->get_field_name("region"); ?>">							
														<option value="">Any</option>
														<?php echo $odst_octopus->get_regions_ddl($country,$region); ?>														
				</select>
				
				<div style="display:none">				
				<label>Resort:</label>
				<select class="odst_resort" id="<?php echo $this->get_field_id("resort"); ?>" name="<?php echo $this->get_field_name("resort"); ?>">
				
				<?php echo $odst_octopus->get_resorts_ddl($region,$resort);?>
				</select>
				</div>
				
				</div>
				<label>Max Properties:</label>				
				<input class="widefat" id="<?php echo $this->get_field_id("max"); ?>" name="<?php echo $this->get_field_name("max"); ?>" type="text" value="<?php echo esc_attr($instance["max"]); ?>" />
			
		</div><?php

}

}


class ODST_octopus_SearchBox extends WP_Widget {


function ODST_octopus_SearchBox() {
	
	parent::WP_Widget(false, $name='ODST Octopus Search box');
}

/**
 * Displays octopus holidays widget on blog.
 */
function widget($args, $instance) {
	global $post;
	$post_old = $post; // Save the post object.
	
	extract( $args );
	
	$title = $instance['title'];
    	
	echo $before_widget;
	if ( $title ) {
		echo $before_title . $title . $after_title; }
	
	$content = apply_filters('odst_widget_searchbox_content','',$args['widget_id'],$instance['default_destination'],$instance['country'],$instance['region'],$instance['resort']);
	echo $content;
	echo $after_widget;
		
	
	$post = $post_old; // Restore the post object.
}

/**
 * Form processing... Dead simple.
 */
function update($new_instance, $old_instance) {
	/**
	 * Save the thumbnail dimensions outside so we can
	 * register the sizes easily. We have to do this
	 * because the sizes must registered beforehand
	 * in order for WP to hard crop images (this in
	 * turn is because WP only hard crops on upload).
	 * The code inside the widget is executed only when
	 * the widget is shown so we register the sizes
	 * outside of the widget class.
	 */
	
	
	return $new_instance;
}

/**
 * The configuration form.
 */
function form($instance) {
$country = '';
$region = '';
$resort = '';

$hasValues = 'false';

if ( $instance ) {
$country = $instance['country'];
$region = $instance['region'];
$resort = $instance['resort'];
}

if( $country != '' ) { $hasValues = 'true'; };


$options = get_option('odst_options');		
$odst_octopus = new odst_octopus($options);	
	
	
?><div id="contentunits" class="odst_country_region" >
				<label for="<?php echo $this->get_field_id("title"); ?>">
				<?php _e( 'Title' ); ?>:</label>
				<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />			
						
		<div class="clear"></div>
			<label for="<?php echo $this->get_field_id("default_destination"); ?>"></label>
				<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("default_destination"); ?>" name="<?php echo $this->get_field_name("default_destination"); ?>"<?php checked( (bool) $instance["default_destination"], true ); ?> />
				<?php _e( 'Specify a default destination' ); ?>
			
		
				<div class="div_search_fixed country_region_resort_group">
				<input type="hidden" class="odst_country_has_initial_values" value="<?php echo $hasValues?>">
				<input type="hidden" class="odst_country_initial_val" value="<?php echo $country?>">
				<input type="hidden" class="odst_region_initial_val" value="<?php echo $region?>">
				<input type="hidden" class="odst_resort_initial_val" value="<?php echo $resort?>">
		
				<label>Country:</label>
				<select class="odst_country" id="<?php echo $this->get_field_id("country"); ?>" name="<?php echo $this->get_field_name("country"); ?>" >
							<?php echo $odst_octopus->get_countries_ddl($country); ?>
						</select>
				<label>City:</label>
				<select class="odst_region all" id="<?php echo $this->get_field_id("region"); ?>" name="<?php echo $this->get_field_name("region"); ?>">							
							<option value="">Any</option>
							<?php echo $odst_octopus->get_regions_ddl($country,$region); ?>														
				</select>
				<div style="display:none">								
				<label>Resort:</label>
				<select class="odst_resort" id="<?php echo $this->get_field_id("resort"); ?>" name="<?php echo $this->get_field_name("resort"); ?>">
				<option value="">Any</option>
				<?php echo $odst_octopus->get_resorts_ddl($region,$resort);?>
				</select>
				</div>
				</div>
		
		
		</div><?php

}

}

?>