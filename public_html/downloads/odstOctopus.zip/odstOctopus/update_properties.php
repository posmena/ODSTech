<?php
if (!file_exists('../../../wp-config.php')) die ('wp-config.php not found');
require_once('../../../wp-config.php');

  if( !class_exists( 'odst_octopus' ) )
        include_once( 'odstoctopus.php' );
		
function odst_octopus_update_hotels() {
	global $wpdb;
    $start = time();
	@ini_set( 'memory_limit', apply_filters( 'admin_memory_limit', WP_MAX_MEMORY_LIMIT ) );
	
	$table_name = $wpdb->prefix . "odst_octopus_properties";
	
    $last_updated = get_option('odst_octopus_last_updated');
	
	
	$options = get_option('odst_options');			
	$odst_octopus = new odst_octopus($options);	
	echo('Getting properties..<br/>');
	$xmlFile = $odst_octopus->get_hotels_from_odst('',500);
	
	if ( is_wp_error( $xmlFile ) ) {
		   $error_string = $xmlFile->get_error_message();
		   echo '<br><br>ERROR: ' . $error_string . '<br><br>';
		   return;
		}		
		
	echo('Updating..');
	
	$sql = "delete from " . $table_name ;
	$wpdb->query($sql);	
	
	$z = new XMLReader;
	$z->open($xmlFile);

	$doc = new DOMDocument;

	// move to the first <product /> node
$i = 1;
	while ($z->read() && $z->name !== 'hol' && $i < 5)
	{
$i += 1;
}
	
while ($z->name === 'hol')
{
echo(".");
    // either one should work
    //$node = new SimpleXMLElement($z->readOuterXML());
    $property = simplexml_import_dom($doc->importNode($z->expand(), true));	
	
		$sql = "insert into " . $table_name . "(id,name,resort,resortid,region,country,rating,hoteltype,airportcode,image1url,image2url,image3url,description,address,postcode,bestseller,propertyid,price,url) " .
					 "values ('" . $property->productid . "','" . str_replace("'","''",$property->productname) . "','" . '' . "','" . '' . "','" . str_replace("'","''",$property->city) . "','" . str_replace("'","''",$property->country) . "','" . $property->rating . "','" . '' . "','" . '' . "','" . $property->image_link . "','" . '' . "','" . '' . "','" . str_replace("'","''",$property->description) . "','" . str_replace("'","''",$property->extra_info) . "','" . '' . "'," . "0" . ",'" . $property->productid . "','" . $property->price . "','" . $property->deeplink . "')" .
					 " ON DUPLICATE KEY update name='" . str_replace("'","''",$property->productname) . "',resort='" . '' . "',resortid='" . '' . "',region='" . str_replace("'","''",$property->city) . "',country='" . str_replace("'","''",$property->country) . "',rating='" . $property->rating . "',hoteltype='" . '' . "',airportcode='" . '' . "',image1url='" . $property->image_link . "',image2url='" . '' . "',image3url='" . '' . "',description='" . str_replace("'","''",$property->description) . "',address='" . str_replace("'","''",$property->extra_info) . "',postcode='" . '' . "',bestseller=0,propertyid='" . $property->productid . "',price='" . $property->price . "',url='" . $property->deeplink . "'";				
		
		$wpdb->query($sql);		
		$z->next('hol');
		}
	
	echo("<br/>Properties updated");
	
	$regions=$wpdb->get_col( "select distinct region from " . $table_name);
	update_option('odst_octopus_regions', $regions);
	
	$countries=$wpdb->get_col( "select distinct country from " . $table_name);
	update_option('odst_octopus_countries', $countries);
	
	update_option('odst_octopus_last_updated',$start);
	
	
   
	}		
		
	$username = mysql_real_escape_string($_GET["username"]);
	$password = mysql_real_escape_string($_GET["password"]);
	$options = get_option('odst_options');
	if ( $username ==  $options['odst_username'] && ($password ==  $options['odst_password']))
		{ 
		odst_octopus_update_hotels();
		}
	else
		{
		echo('Please provide a valid username and password for this installation.');
		}
	
?>