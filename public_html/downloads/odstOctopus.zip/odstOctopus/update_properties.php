<?php

if (!file_exists('../../../wp-config.php')) die ('wp-config.php not found');
require_once('../../../wp-config.php');

  if( !class_exists( 'odst_octopus' ) )
        include_once( 'odstoctopus.php' );
		
function odst_octopus_update_hotels() {
	global $wpdb;
    $start = time();
	$table_name = $wpdb->prefix . "odst_octopus_properties";
	
    $last_updated = get_option('odst_octopus_last_updated');
	
	
	$options = get_option('odst_options');			
	$odst_octopus = new odst_octopus($options);	
	echo('Getting properties..<br/>');
	$xml = $odst_octopus->get_hotels_from_odst('',500);
	echo('Updating..');
	
	$sql = "delete from " . $table_name ;
	$wpdb->query($sql);	
			
	foreach( $xml->hol as $property ) {
		echo('.');
		
		$sql = "insert into " . $table_name . "(id,name,resort,resortid,region,country,rating,hoteltype,airportcode,image1url,image2url,image3url,description,address,postcode,bestseller,propertyid,price,url) " .
					 "values ('" . $property->productid . "','" . $property->productname . "','" . '' . "','" . '' . "','" . $property->city . "','" . $property->country . "','" . $property->rating . "','" . '' . "','" . '' . "','" . $property->image_link . "','" . '' . "','" . '' . "','" . $property->description . "','" . $property->extra_info . "','" . '' . "'," . "0" . ",'" . $property->productid . "','" . $property->price . "','" . $property->deeplink . "')" .
					 " ON DUPLICATE KEY update name='" . $property->productname . "',resort='" . '' . "',resortid='" . '' . "',region='" . $property->city . "',country='" . $property->country . "',rating='" . $property->rating . "',hoteltype='" . '' . "',airportcode='" . '' . "',image1url='" . $property->image_link . "',image2url='" . '' . "',image3url='" . '' . "',description='" . $property->description . "',address='" . $property->extra_info . "',postcode='" . '' . "',bestseller=0,propertyid='" . $property->productid . "',price='" . $property->price . "',url='" . $property->deeplink . "'";				
		
		$wpdb->query($sql);		
	}
	
	echo("<br/>Properties updated");
	
	$regions=$wpdb->get_col( "select distinct region from " . $table_name);
	update_option('odst_octopus_regions', $regions);
	
	$countries=$wpdb->get_col( "select distinct country from " . $table_name);
	update_option('odst_octopus_countries', $countries);
	
	update_option('odst_octopus_last_updated',$start);
	
	
   
	}		
		
	$username = mysql_real_escape_string($_GET["username"]);
	$password = mysql_real_escape_string($_GET["password"]);
	$options = get_option('odst_options');
	if ( $username ==  $options['odst_username'] && ($password ==  $options['odst_password']))
		{ 
		odst_octopus_update_hotels();
		}
	else
		{
		echo('Please provide a valid username and password for this installation.');
		}
	
?>