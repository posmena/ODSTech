<?php
/*
This file is used in AJAX requests from the plugin to forward the request to the ODST API to get around cross site browser security
*/

if (!file_exists('../../../wp-config.php')) die ('wp-config.php not found');
require_once('../../../wp-config.php');

    if( !class_exists( 'WP_Http' ) )
        include_once( ABSPATH . WPINC. '/class-http.php' );
		
$api_base = plugins_url( '/local_api.php?', __FILE__ );

$type 		= mysql_real_escape_string($_GET['type']);
$source     = mysql_real_escape_string($_GET['source']);
$region 	= mysql_real_escape_string($_GET['rgion']);
$country 	= mysql_real_escape_string($_GET['country']);
$hotelID 	= mysql_real_escape_string($_GET['hotelID']);
$limit 	= mysql_real_escape_string($_GET['limit']);
$request = new WP_Http;
			
switch ($type) {		
		case 'regions':{
			$url = $api_base . 'source=' . $source. '&type=regions&format=xml&country=' . rawurlencode($country);		
			break;
		}	
		case 'resorts':{
			$url = $api_base . 'source=' . $source. '&type=resorts&format=xml&rgion=' . rawurlencode($region);		
			break;
		}	
		case 'properties':{
			$url = $api_base . 'source=' . $source. '&type=properties&format=xml&rgion=' . rawurlencode($region) . '&limit=' . $limit;		
			break;
		}	
    }
	 
	
if ( $url != "" ) {
	$result = $request->request( $url );					
	$contents = $result['body'];		
	echo $contents;
}


?>