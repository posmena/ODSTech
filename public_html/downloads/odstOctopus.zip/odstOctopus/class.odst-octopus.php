<?
    if( !class_exists( 'WP_Http' ) )
        include_once( ABSPATH . WPINC. '/class-http.php' );


class odst_octopus
{
	//static private $api_base = 'http://odst.co.uk/api/index.php?';
	private $source = 'octopus';
	private $api_base;
	public $username;
	public $password;
	private $programmeid = '4813';
	public $webgainsID;
	public $deeplink = '';
	public $options;
	
	
	function myTruncate($string, $limit, $break=" ", $pad="...") { 
// return with no change if string is shorter than $limit 

if(strlen($string) <= $limit) return $string; 

// is $break present between $limit and the end of the string?
 if(false !== ($breakpoint = strpos($string, $break, $limit))) { 
		if($breakpoint < strlen($string) - 1) { 
				$string = substr($string, 0, $breakpoint) . $pad; } 				
				} return $string; 
 }
 
 
 
 function make_deeplink($url)
 {
 return str_replace('click.html?','click.html?clickref=ODST&', $url);
 }
 
	 function format_price($price) { 
	// return with no change if string is shorter than $limit 

	if( number_format($price,0) == number_format($price,2) )
		{
			return $price;
		}
		
		return number_format($price,2);
	 
	 }
	 
	public function count_properties()
	{
	 global $wpdb;
	 $count = $wpdb->get_var("select count(*) from " . $wpdb->prefix . "odst_octopus_properties");
	 return $count;
	}
 
	public function odst_octopus($options)
	{
	$this->options = $options;
	$this->username = $options['odst_username'];
	$this->password = $options['odst_password'];
	$this->webgainsID = $options['odst_webgains_id'];
	$this->deeplink = ''; //'http://track.webgains.com/click.html?wgprogramid=' . $this->programmeid  . '&wgcampaignid=' . $this->webgainsID. '&wgtarget=';
	
	$this->api_base = plugins_url( 'local_api.php', __FILE__ ) .'?user=' . $username . '&pass=' . $password . '&';
	}
	
	
	public function __construct($options)
	{
	$this->options = $options;
	$this->username = $options['odst_username'];
	$this->password = $options['odst_password'];
	$this->webgainsID = $options['odst_webgains_id'];
	
	$this->deeplink = '';//'http://track.webgains.com/click.html?wgprogramid=' . $this->programmeid  . '&wgcampaignid=' . $this->webgainsID. '&wgtarget=';
		
	$this->api_base = plugins_url( 'local_api.php', __FILE__ ) .'?user=' . $username . '&pass=' . $password . '&';
	}
	
	function get_first_match($text, $words)
{
        /*** loop of the array of words ***/
        foreach ($words as $word)
        {
                /*** quote the text for regex ***/
                $word = preg_quote($word);
                /*** highlight the words ***/
                //$text = preg_replace("/\b($word)\b/i", '<span class="highlight_word">\1</span>', $text);
				if ( preg_match("/\b($word)\b/i", $text, $matches, PREG_OFFSET_CAPTURE) > 0 )
				{
				return $word;
				break;
				}
        }
        /*** return the text ***/
        return "";
}

	public function get_region_from_context($content)
	{
		// find which region in the post content and return region
		$regions = get_option('odst_octopus_regions');
		$match = $this->get_first_match($content, $regions);			
		
		if ( $match == "" )
		{
			return $regions[array_rand($regions)];
		}
		
		return $match;
				
	}
	
	public function format_style($style)
	{
	if( $style == '')
		{
			return '';
		}
	return ' style="' . $style . '"';
	}
	
	public function format_width($width)
	{
		if ($width == '' ) { return $width; }
		
		$width = strtolower($width);
		if( strpos($width,"px") || strpos($width,"%") ) { return $width ; }
		
		return $width . "px";		
	
	}
	
	public function apply_style($stylesheet,$element)
	{
	
	$style = '';
	
			switch ( $stylesheet )	{
				case 'default':
					
					if( $this->options[$element] != '' ){
						switch ( $element ){
							case 'background_colour':
							
							$style='background-color:' . $this->options[$element] .';';
							break;
							
							case 'border_colour':
							$style='border-color:' . $this->options[$element] .';';
							break;
							
							case 'hotel_bg_colour':
							$style='background-color:' . $this->options[$element] .';';
							break;
							
							case 'hotel_colour':
							$style='color:' . $this->options[$element] .';';
							break;
							
							case 'price_colour':
							$style='color:' . $this->options[$element] .';';
							break;
							
							case 'location_colour':
							$style='color:' . $this->options[$element] .';';
							break;
							
							case 'even_row_colour':
							$style='background-color:' . $this->options[$element] .';';
							break;
							
							case 'odd_row_colour':
							$style='background-color:' . $this->options[$element] .';';
							break;
							}
						break;
					}
				}			
			return $style;
	}
	
	public function get_post_content($type,$display,$style,$width,$resort,$region,$country,$propertyid,$limit,$plugin,$pageContent)
	{	
	
	switch ($type) {		
		case 'properties':{
		    if( $region == 'contextual' ){
				$region = $this->get_region_from_context($pageContent);
				}
			
			$limit = intval($limit);
			if ($limit==0) $limit=10;
			
			$xml = $this->search_hotels('',$country,$region,$resort,$limit,1,10);
			
			if ( $display == 'directory' ){
					$hotel = '<div ';
					
					if( $width != '')
						{
						$hotel .= ' style="width:' . $this->format_width($width) . '"';
						}
						
					$hotel .= ' class="odst_hotel_table odst_hotels odst_reset ';
					if( $style != 'default' and $style != "")
					{
					$hotel .= ' ' . strtolower($style);
					}
					
					$hotel .= '"><!--div class="odst_hol_logo"></div-->';					
					$i = 1;
					foreach ($xml->property as $property) {
					$hotel = $hotel . '<div class="row ';
					if ( $i%2 == false ) { $hotel = $hotel. ' even'; }
					$hotel = $hotel . '"';
					
					if ( $i%2 == false ) {	$hotel .= $this->format_style($this->apply_style($style,'odd_row_colour')); }
							else { $hotel .= $this->format_style($this->apply_style($style,'even_row_colour')); } 
						
					$hotel .= '>';
					$hotel .= '<div class="photo"><a target="_blank" rel="nofollow" href="' . $this->make_deeplink($property->url) . '"><img class="photo" src="' . $plugin . '/timthumb.php?src=' . $property->image1url . '&w=80"/></a></div>';
					$hotel .= '<div class="name"><a ' . $this->format_style($this->apply_style($style,'hotel_colour') . $this->apply_style($style,'hotel_bg_colour')) . ' class="name" target="_blank" rel="nofollow" href="' . $this->make_deeplink($property->url) . '">' . $property->name . '</a>';
				
					$hotel .= '<span class="thumb_star stars_' . $property->rating . '"></span></div>';
				
					$hotel .= '<div class="location" ' . $this->format_style($this->apply_style($style,'location_colour')) . '>' . $property->region . ',<br> ' . $property->country . '</span></div>';	
					$hotel .= '<div class="price"><a ' . $this->format_style($this->apply_style($style,'price_colour')) . ' target="_blank" rel="nofollow" href="' . $this->make_deeplink($property->url) . '"><span class="from">from </span>&pound;' . $this->format_price($property->price) . '</a></div>';
					$hotel .= '</div>';
									
					$i+=1;
					}
					$hotel = $hotel . '</div>';
					return $hotel;
					
				}
			else{
				if( $width != '')
						{
						$widthstyle = 'width:' . $this->format_width($width) . ';';
						}
						
				$hotel = '<div ' . $this->format_style($widthstyle . $this->apply_style($style,'background_colour') . $this->apply_style($style,'border_colour'));
				
						
				$hotel .= ' class="container odst_hol_logo odst_reset ';
				if( $style != 'default' and $style != "")
					{
					$hotel .= ' ' . strtolower($style);
					}
				$hotel .= '"><div class="odst_scontainer">';
				
				
				$hotel .= '<div class="slider" name="' . $country . '_' . $region . '_' . $resort . '">';
				$hotel .= '<ul class="slidingparts">';
					foreach ($xml->property as $property) {
						$hotel .= '<li>';
						$hotel .='<table class="thumb_content">
			<tbody><tr>									
						<td class="thumb_heading">
						<a ' . $this->format_style($this->apply_style($style,'hotel_colour') . $this->apply_style($style,'hotel_bg_colour')) . ' target="_blank" rel="nofollow" class="name" href="' .  $this->make_deeplink($property->url) . '">' . $property->name . '</a>
						</td>
						</tr>
							<tr>
						<td class="thumb_city" ' . $this->format_style($this->apply_style($style,'location_colour')) . '>'
						. $property->region .
						'</td>
						</tr>

							<tr>
						<td>
							<span class="thumb_star stars_' . $property->rating . '"></span>
						</td>
						</tr>

						<tr>
						<td class="thumb_img_container">  <a target="_blank" rel="nofollow" href="' . $this->make_deeplink($property->url) . '"><img class="thumb_image" src="' . $plugin . '/timthumb.php?src=' . $property->image1url . '&w=120"/></a>
						</td>
						</tr>
								<tr><td class="thumb_price"' . $this->format_style($this->apply_style($style,'price_colour')) . '>
				from &pound;' . $this->format_price($property->price) .'
					</td></tr>								
					</tbody></table>';
																			
						 }
					
					$hotel .= '</ul></div></div><div class="odst_hol_logo_padding"></div></div>';
					return $hotel;
					
							
				}
			break;
		}	
		
		case 'hotel':{
			$xml = $this->get_hotel($propertyid);
			$hotel = $xml->property[0]->name . '<br>';
			$hotel = $hotel . '<a target="_blank" rel="nofollow" href="' . $this->make_deeplink($property->url) . '"><img class="photo" src="' . $xml->property[0]->image1url . '"/></a>';
			$hotel = $hotel . $xml->property[0]->description . '<br>';	
			return $hotel;
			break;
		}	
		
		case 'rates':{			
			$xml = $this->get_hotel($propertyid);
			$price = "&pound;" . $this->format_price($xml->property[0]->price) ;			
			return $price;
			break;
		}	
    }
		
	}
	
	public function get_holidays_widget_content($display,$format,$style,$width,$country,$region,$resort,$limit,$plugin,$pageContent)
	{	
		
		$limit = intval($limit);
		if ($limit==0) $limit=5;
			
		  if( $format == 'contextual' ){
				$region = $this->get_region_from_context($pageContent);
				$country = '';
				$resort  = '';
				}
		
		$xml = $this->search_hotels('',$country,$region,$resort,$limit,1,10);
					
		
		if( $display == 'directory' ) {
		
			if( $width != '')
						{
						$widthstyle = 'width:' . $this->format_width($width) . ';';
						}
				
			$hotel = '<div ' . $this->format_style($widthstyle . $this->apply_style($style,'border_colour') . $this->apply_style($style,'background_colour'));
			
			
			$hotel .= ' class="odst_hotels vertical odst_reset ';
			if( $style != 'default' and $style != "")
					{
					$hotel .= ' ' . strtolower($style);
					}
					
			$hotel .= '">';
			$hotel .= '<!--div class="odst_hol_logo"></div-->';
				
			foreach ($xml->property as $property) {
			
				$hotel .= '<div class="name"><a ' . $this->format_style($this->apply_style($style,'hotel_colour') . $this->apply_style($style,'hotel_bg_colour')) . ' class="name" target="_blank" rel="nofollow" href="' . $this->make_deeplink($property->url) . '">' . $property->name . '</a></div>';
				$hotel .= '<div class="photo"><a target="_blank" rel="nofollow" href="' . $this->make_deeplink($property->url) . '"><img class="thumb_image" src="' . $plugin . '/timthumb.php?src=' . $property->image1url . '&w=80"/></a></div>';
						
				$hotel .= '<div class="location" ' . $this->format_style($this->apply_style($style,'location_colour')) . '>' . $property->region . '</div>';
				$hotel .= '<span class="thumb_star stars_' . $property->rating . '"></span>';
							
				$hotel .= '<div class="price" ' . $this->format_style($this->apply_style($style,'price_colour')) . '>from &pound;' . $this->format_price($property->price) . '</div>';
				}
			
			$hotel = $hotel . '</div>';
					
			return $hotel;				
			}
			else {
			
			$hotel = '<div ';
			
			if( $width != '')
				{
				$hotel .= ' style="width:' . $this->format_width($width) . '"';
				}
				
					
			$hotel .= ' class="odst_reset ';
				if( $style != 'default' and $style != "")
					{
					$hotel .= ' ' . strtolower($style);
					}
				$hotel .= '"><div class="odst_scontainer vertical odst_hol_logo" ' . $this->format_style($this->apply_style($style,'background_colour') . $this->apply_style($style,'border_colour')) . '>';
				$hotel .= '<div class="slider vertical" name="' . $country . '_' . $region . '_' . $resort . '">';			
			$hotel .= '<ul  class="slidingparts">';
			foreach ($xml->property as $property) {
			$hotel .= '<li>';
						$hotel .='<table width="130" class="thumb_content">
						<tbody><tr>									
						<td class="thumb_heading">
						<a ' . $this->format_style($this->apply_style($style,'hotel_colour') . $this->apply_style($style,'hotel_bg_colour')) . ' target="_blank" rel="nofollow" class="name" href="' .  $this->make_deeplink($property->url) . '">' . $property->name . '</a>
						</td>
						</tr>
							<tr>
						<td class="thumb_city" ' . $this->format_style($this->apply_style($style,'location_colour')) . '>'
						. $property->region .
						'</td>
						</tr>

							<tr>
						<td>
													<span class="thumb_star stars_' . $property->rating . '"></span>

						</td>
						</tr>

						<tr>
						<td><a target="_blank" rel="nofollow" href="' . $this->make_deeplink($property->url) . '"><img class="thumb_image" src="' . $plugin . '/timthumb.php?src=' . $property->image1url . '&w=120"/></a>
						</td>
						</tr>
								<tr><td  class="thumb_price" ' . $this->format_style($this->apply_style($style,'price_colour')) . '>from &pound;' . $this->format_price($property->price) .'
					</td></tr>								
					</tbody></table></li>';
				}
			
			$hotel .= '</ul></div></div></div>';
						
			return $hotel;
			}					
		
	}
	
	public function get_month_year_ddl()
	{
	for ( $i=1; $i<=10; $i += 1)
		{
		$date = mktime(0, 0, 0, date("m")+$i, date("d"),   date("Y"));
		$s .= '<option value="' . date('m/Y',$date) . '">' . date('M \'y',$date) . '</option>';
		}
		return $s;
	}
	
	public function get_days_ddl($ym)
	{	
	for ($i=1; $i<=31; $i=$i+1){
		$s .= '<option value="' . $i . '">' .$i . '</option>';		
		}
	return $s;
	}
	
	/*public function get_day_ddl($ym)
	{
	$dtStart = date_create_from_format('j/m/Y','1/' . $ym);
	$month = date_format($dtStart,'m');
	for ($i=0; $i<32; $i=$i+1){
		$s .= '<option value="' . date_format($dtStart, 'j') . '">' . date_format($dtStart, 'j (D)') . '</option>';
		$dtStart = $dtStart -> modify('+1 day');
		if( date_format($dtStart,'m') != $month)
			break;
		}

	return $s;
	}
	*/
	
	public function get_searchbox_widget_content($widgetid, $default_destination,$country,$region,$resort)
	{		
		$selectedCountry = "";
	    $selectedRegion = "";
	    $selectedResort = "";
		$hasvalues = "false";
		
	    if( $default_destination == "on" )
		{
		 $selectedCountry = $country;
		 $selectedRegion = $region;
		 $selectedResort = $resort;
		 $hasvalues = "true";
		}
		
		$html = '<div class="odst_ej_search">';
		
		
		$html .= '<div class="odst_f_airport"><label for="odst_ej_departure_airport">Departure Airport</label><select name="odst_ej_departure_aiport" id="odst_ej_departure_aiport"><option value="0">Please select...</option><option value="LON">All London</option><option value="BRS">Bristol</option><option value="EDI">Edinburgh</option><option selected="selected" value="LGW">London Gatwick</option><option value="MAN">Manchester</option></select></div>';
		
		
		$html .= '<div class="odst_country_region">';
		$html .= '<input type="hidden" class="odst_country_has_initial_values" value="' . $hasvalues . '">';
		$html .= '<input type="hidden" class="odst_country_initial_val" value="' . $selectedCountry . '">';
		$html .= '<input type="hidden" class="odst_region_initial_val" value="' . $selectedRegion . '">';
		$html .= '<input type="hidden" class="odst_resort_initial_val" value="' . $selectedResort . '">';
		
		$html .= '<div class="odst_f_country"><label for="odst_widget_ps_country">Country</label><select class="odst_country" id="odst_widget_ps_country"><option vlaue="">Select country</option>' . $this->get_countries_ddl($selectedCountry) . '</select></div>';
		$html .= '<div class="odst_f_region"><label for="odst_widget_ps_region">Region</label><select class="odst_region" id="odst_widget_ps_region">' . $this->get_regions_ddl($selectedCountry,$selectedRegion) . '</select></div>';
		$html .= '<div style="display:none" class="odst_f_resort"><label for="odst_widget_ps_resort">Resort</label><select class="odst_resort" id="odst_widget_ps_resort">' . $this->get_resorts_ddl($selectedRegion,$selectedResort) . '</select></div></div>';
		$html .= '<div class="odst_f_date"><label for="odst_date_month_year">Date</label><select class="small" name="odst_date_day" id="odst_date_day">' . $this->get_days_ddl(date('m/Y')) . '</select><select class="medium" name="odst_date_month_year" id="odst_date_month_year">' . $this->get_month_year_ddl() . '</select></div>';
		$html .= '<div class="odst_f_duration"><label for="odst_duration">Duration</label><label for="odst_adults">Adults</label><div style="clear:both"/><select class="small odst_duration" name="odst_duration" id="odst_duration"><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option><option>21</option><option>22</option><option>23</option><option>24</option><option>25</option><option>26</option><option>27</option><option>28</option><option>29</option></select>';
		$html .= '<select class="dropdown odst_adults" name="odst_adults" id="odst_adults"><option selected="selected">1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option></select></div>';
		$html .= '<div class="odst_f_child"><label for="odst_children">Children</label><label for="odst_infants">Infants</label><div style="clear:both"/><select class="dropdown children small" name="odst_children" id="odst_children"><option  selected="selected">0</option><option>1</option><option>2</option><option>3</option><option>4</option></select>';
		$html .= '<select class="dropdown small odst_infants" name="odst_infants" id="odst_infants"><option  selected="selected">0</option><option>1</option><option>2</option><option>3</option><option>4</option></select></div>';
		$html .= '<div class="odst_f_child_ages"><label for="odst_child">Child Ages</label><select class="dropdown odst_child1_age small" name="odst_child1_age" id="odst_child1_age"><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option></select><select class="dropdown odst_child2_age small" name="odst_child2_age" id="odst_child2_age"><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option></select><select class="dropdown odst_child3_age small" name="odst_child3_age" id="odst_child3_age"><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option></select><select class="dropdown odst_child4_age small" name="odst_child4_age" id="odst_child4_age"><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option></select></div>';
		$html .= '<div class="odst_f_search"><input type=submit class="odst_submit" value="Search" onclick="ODST_Search_Octopus(this);return false;"/></div>';
		$html .= '</div>';
		
		//$xml = $this->get_hotels('Halkidiki',5);
		//foreach ($xml->property as $property) {
		//$html = $html . $property->name . '<br>';
		//}
		return $html;						
	}
	
	public function get_hotels_from_odst($region,$limit='')
	{
    ini_set("memory_limit","128M");

	$old_base = $this->api_base;
	$this->api_base = 'http://odst.co.uk/api/index.php?user=' . $this->username . '&pass=' . $this->password . '&';
	
	$request = new WP_Http;
		$url = $this->api_base . 'source=' . urlencode($this->source) . '&type=properties&format=xml';
		if ($region != ''){
			$url = $url . '&rgion=' . urlencode($region);
			}
		else{
			$url = $url . '&propertylist=1';
			}
		
		$limit = intval($limit);
		if ($limit==0) $limit=10;
			
		$url = $url . '&limit=' . $limit;			
					
		$result = $request->request( $url , array( 'timeout' => '3000000' ));
				
		$contents = $result['body'];

		
$myFile = wp_tempnam ( "hotels.txt", '' );

//$myFile = "hotels.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
fwrite($fh, $contents);
fclose($fh);
	
$contents = "";
		
	$this->api_base = $old_base;
	
	
	return $myFile;
	
	
	}	
	
	public function get_hotels($region,$limit='')
	{
	    $request = new WP_Http;
		$url = $this->api_base . 'source=' . urlencode($this->source) . '&type=properties&format=xml';
		if ($region != ''){
			$url = $url . '&rgion=' . urlencode($region);
			}
		else{
			$url = $url . '&propertylist=1';
			}
		
		$limit = intval($limit);
		if ($limit==0) $limit=10;
			
		$url = $url . '&limit=' . $limit;			
					
		$result = $request->request( $url , array( 'timeout' => '3000000' ));
				
		$contents = $result['body'];

		libxml_use_internal_errors(true); 
		
		$myxml=simplexml_load_string($contents);
		
		libxml_use_internal_errors(false);
		
		return $myxml;
		
	}
	
	public function get_hotels_by_name($name,$limit='',$page=1)
	{
	    $request = new WP_Http;
		$url = $this->api_base . 'source=' . urlencode($this->source) . '&type=properties&name=' . urlencode($name) . '&format=xml';
				
		$limit = intval($limit);
		if ($limit==0) $limit=10;
		
		$url = $url . '&limit=' . $limit;			
		
		
		$url = $url . '&page=' . $page;
		
		$result = $request->request( $url );
				
		$contents = $result['body'];
		
		if (!$myxml=simplexml_load_string($contents))
		{
            return "Error reading the XML file";
        }
		
		return $myxml;
		
	}
	
	public function search_hotels($name,$country,$region,$resort,$limit='',$page=1,$fill=0)
	{
	    $request = new WP_Http;
		$url = $this->api_base . 'source=' . urlencode($this->source) . '&type=properties&name=' . urlencode($name) . '&country=' . urlencode($country) . '&rgion=' . urlencode($region) . '&resort=' . urlencode($resort) . '&format=xml&fill='. $fill;
		
		$limit = intval($limit);
		if ($limit==0) $limit=10;
					
		$url = $url . '&limit=' . $limit;					
		
		$url = $url . '&page=' . $page;
		
		$result = $request->request( $url );
				
		$contents = $result['body'];
		
		if (!$myxml=simplexml_load_string($contents))
		{
            return "Error reading the XML file";
        }
		
		return $myxml;
		
	}
	

	public function get_countries()
	{
	    $request = new WP_Http;
		$url = $this->api_base . 'source=' . urlencode($this->source) . '&type=countries&format=xml';
		$result = $request->request( $url );
		$contents = $result['body'];
			
		$myxml=simplexml_load_string($contents);
		
		return $myxml;
	}
	
	public function get_countries_ddl($selected ="")
	{
	    $xml = $this->get_countries();
		
		if( $xml ){
			foreach ($xml->country as $country) {		
				$countries_ddl = $countries_ddl . '<option';
				if ($selected == $country->name ) { $countries_ddl = $countries_ddl . ' selected="true" ';}
				$countries_ddl = $countries_ddl . ' value="'. $country->name . '">' . $country->name . '</option>';
				}
			return $countries_ddl;
			}
	}
	
	public function get_regions($country)
	{
	    $request = new WP_Http;
		$url = $this->api_base . 'source=' . urlencode($this->source) . '&type=regions&format=xml&country=' . urlencode($country) . '&limit=1';
		$result = $request->request( $url );
		$contents = $result['body'];
		
		if (!$myxml=simplexml_load_string($contents))
		{
            return "Error reading the XML file";
        }
		
		return $myxml;
	}
	
	public function get_regions_ddl($country,$selected)
	{	
		if( $country == "" )
		{
			return;
		}
		
	    $xml = $this->get_regions($country);
		
		foreach ($xml->region as $region) {
		
		$regions_ddl = $regions_ddl . '<option';
		if ($selected == $region->name ) { $regions_ddl = $regions_ddl . ' selected="true" ';}
		$regions_ddl = $regions_ddl . ' value="'. $region->name . '">' . $region->name . '</option>';
		}
		return $regions_ddl;
	}
	
	public function get_resorts($region)
	{
	    $request = new WP_Http;
		$url = $this->api_base . 'source=' . urlencode($this->source) . '&type=resorts&format=xml&rgion=' . urlencode($region) . '&limit=1';
		$result = $request->request( $url );
		$contents = $result['body'];

		if (!$myxml=simplexml_load_string($contents))
		{
            return "Error reading the XML file";
        }
		
		return $myxml;
	}
	
	public function get_resorts_ddl($region,$selected)
	{	
		if( $region == "" )
		{
			return;
		}
		
	    $xml = $this->get_resorts($region);
		
		foreach ($xml->resort as $resort) {
		
		$resorts_ddl = $resorts_ddl . '<option';
		if ($selected == $resort->name || $selected == $resort->name . ':' . $resort->id ) { $resorts_ddl = $resorts_ddl . ' selected="true" ';}
		$resorts_ddl = $resorts_ddl . ' value="'. $resort->name . ':' . $resort->id .'">' . $resort->name . '</option>';
		}
		return $resorts_ddl;
	}
	
	public function get_hotel($propertyid)
	{
	    $request = new WP_Http;
		$url = $this->api_base . 'source=' . urlencode($this->source) . '&type=property&format=xml&propertyid=' . $propertyid . '&limit=1';
		$result = $request->request( $url );
		$contents = $result['body'];
		
		if (!$myxml=simplexml_load_string($contents))
		{
            return "Error reading the XML file";
        }
		
		return $myxml;
	}
	
}
?>