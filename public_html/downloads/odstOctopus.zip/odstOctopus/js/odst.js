/**
 * Handle: wpODSTOctopus
 * Version: 0.0.1
 * Deps: jquery
 * Enqueue: true
 */
 
 function toggle_show_dropdowns(div,ddl) {
	if( ddl.val() == 'contextual' ) {
		div.hide();
		}
	else{
		div.show();
		}
	}
	
jQuery(document).ready(function(){	

	jQuery(".slider").each(function() { 
		var slider = jQuery(this);
		if ( slider.hasClass('vertical') ) {
				slider.easySlider({
					vertical:true,
					auto: true,
					continuous: true ,
					overrideheight: false,
					controlsShow: true
				});
			}
		else{
			slider.easySlider({
					auto: true,
					continuous: true ,
					overridewidth: false,					
					controlsShow: true 
				});
		}
	
		});
		
	/*jQuery(".slider").easySlider({
		auto: true,
		continuous: true ,
		overridewidth: false,
		controlsShow: false
	});*/
	
});



function setup_country_region_resort_dropdowns(initialise)
{
jQuery(".odst_country_region").each(function(){
	
     var div = jQuery(this);
	
	 if( initialise )
		{
		//if it has initial values then select in dropdowns, otherwise fill by ajax
		var hasValues = false;
		if( div.find("input[type=hidden].odst_country_has_initial_values").length > 0)	
			{
			hasValues = div.find("input[type=hidden].odst_country_has_initial_values").val();
			}
		if ( hasValues == 'true' )
			{
			div.find('select.odst_country').val(div.find("input[type=hidden].odst_country_initial_val").val());
			div.find('select.odst_region').val(div.find("input[type=hidden].odst_region_initial_val").val());
			div.find('select.odst_resort').val(div.find("input[type=hidden].odst_resort_initial_val").val());			
			}
		else
			{
			showRegions(div.find("select.odst_country").val(),div.find("select.odst_region"),div.find("select.odst_resort"));
			}
	    }
	 
		// bind events
		div.find('select.odst_country').change(function(){	   
		showRegions(jQuery(this).val(),div.find("select.odst_region"),div.find("select.odst_resort"));
		})
		     
		div.find('select.odst_region').change(function(){	    
		showResorts(jQuery(this).val(),div.find("select.odst_resort"));
		})     	
		
	 })
}

function setup_show_dropdown()
{
jQuery(".odst_country_region").each(function(){
	
     var div = jQuery(this);
	 
	 div.find('select.odst_format_select').change(function(){	 
	    toggle_show_dropdowns(div.find('div.country_region_resort_group'),jQuery(this));
		})
		
	 toggle_show_dropdowns(div.find('div.country_region_resort_group'),div.find('select.odst_format_select'));
		
	 })
}
	 	 