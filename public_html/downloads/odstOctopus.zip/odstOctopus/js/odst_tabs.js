jQuery(document).ready(function($) {
    //$("#odst_tabs .hidden").removeClass('hidden');
   // $("#odst_tabs").tabs();
	
	
	// category tabs
	$('#odst_cu_meta #odst-tabs a').click(function(){
		var t = $(this).attr('href');
		$(this).parent().addClass('tabs').siblings('li').removeClass('tabs');
		$('.tabs-panel').hide();
		$(t).show();
				
		return false;
	});
	
});
