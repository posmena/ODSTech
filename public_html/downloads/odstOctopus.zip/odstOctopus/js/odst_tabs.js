jQuery(document).ready(function($) {
    //$("#odst_tabs .hidden").removeClass('hidden');
   // $("#odst_tabs").tabs();
	
	
	// category tabs
	$('#odst_cu_meta #odst-tabs a').click(function(){
		var t = $(this).attr('href');
		$(this).parent().addClass('tabs').siblings('li').removeClass('tabs');
		$(this).parent().parent().parent().find('.tabs-panel').hide();		$(this).parent().parent().parent().find($(this).attr('href')).show();
		//$(t).show();
				
		return false;
	});
	
});
