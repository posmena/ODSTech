<?php

class icon_network_base implements icon_network
{
	function __construct()
	{
	}
	
	function getFields()
	{
	}
	
	function getName()
	{
	}
	
	function getPrefix()
	{
	}
	
	function updateFeedList($network_id, $options, $wpdb)
	{
	}
	
	function addFeed($feed, $options, $wpdb)
	{
	}
	
	function parse_xml($file, $feed_id)
	{
	}
	
	function update_master()
	{
	global $wpdb;
		$sql = 'insert into `pm_product_ids` 

			(`feed_id`,`ProductID`)
			SELECT distinct P.feed_id, P.ProductID FROM `pm_products` P
			left outer join `pm_product_ids` ID on ID.feed_id = P.feed_id AND 

			ID.ProductID=P.ProductID
			where ID.uid is null';
			
			$wpdb->query($sql);
			
			$sql = 'update pm_product_ids set uid=id where uid=0';
			$wpdb->query($sql);			
			
			$sql = 'update pm_products,pm_product_ids set pm_products.uid=pm_product_ids.uid 
			where pm_product_ids.feed_id=pm_products.feed_id and  pm_product_ids.ProductID= pm_products.ProductID';
			$wpdb->query($sql);	

			$sql = 'insert into `pm_master_products` 

			(`ProductName`,`ProductDescription`,`SummaryDescription`,`BrandName`,`RRP`

			,`ImageURL`,`SmallImageURL`,`LargeImageURL`,`uid`)
			
			SELECT 

			P.ProductName,P.ProductDescription,P.SummaryDescription,P.BrandName,P.RRP,
			P.ImageURL,P.SmallImageURL,P.LargeImageURL,ID.uid FROM `pm_products` P
			inner join `pm_product_ids` ID ON P.feed_id=ID.feed_id AND P.ProductID=ID.ProductID
			left outer join  `pm_master_products` MP on MP.uid = ID.uid
			where MP.uid is null';
			
			$wpdb->query($sql);
			
	}
	
	function insert_products($products)
	{
		if( $products == "" )
			{
			return true;
			}
			
		global $wpdb;
		$query = 'INSERT INTO pm_products (id,feed_id,ProductName,ProductPrice,ProductDescription,SummaryDescription, Gender,BrandName,RRP,ProductID,AffiliateURL,ImageURL,Category,SmallImageURL,LargeImageURL) VALUES ';
		$sql = $query.$products;
		$sql = substr_replace($sql,";",-1);
		if($wpdb->query($sql))
		{
			
			return true;
			//print $product['product_name']."<br />";
		}
		else
		{
			print 'Sorry. There was an error. Please try again';
			//print "<textarea>$sql</textarea>";
			return false;
		}
	}
}