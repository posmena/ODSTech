<?php

class icon_webgains extends icon_network_base
{
	private static $name = 'Webgains';
	private static $fields = array();
	private static $prefix;
	
	public function __construct()
	{
		self::$fields = array(0 => array(
									'id'   => 'id',
									'name' => 'Webgains ID',
									'type' => 'text'),
							  1 => array(
							  		'id'   => 'username',
							  		'name' => 'Webgains Username',
									'type' => 'text'),							  		
							  2 => array(
							  		'id'   => 'password',
							  		'name' => 'Webgains Password',
									'type' => 'password'),							  		
							);
		self::$prefix = 'wg';
	}
	
	public function getName()
	{
		return self::$name;
	}
	
	public function getFields()
	{
		return self::$fields;
	}
	
	public function getPrefix()
	{
		return self::$prefix;
	}
	
	function updateFeedList($network_id, $options, $wpdb)
	{
		global $wpdb;

		$url       = 'http://ws.webgains.com/aws.php';
		$user      = $options['icon_global_' . self::$prefix. '_username'];
		$pass      = $options['icon_global_' . self::$prefix. '_password'];
		$campaign  = $options['icon_global_' . self::$prefix. '_id'];
	
		$client    = new SoapClient($url);
	
		try {
		$merchants = $client->getProgramsWithMembershipStatus($user, $pass, $campaign);
			} 
		catch (Exception $e) {
				$error = $e->getMessage();
				return '<div class="error fade">Unable to download feed, this could be due to limited memory on your server.</div>';			
		}
		
		foreach($merchants as $merchant)
		{
			if ($merchant->programMembershipStatusCode == 10) {
				switch($merchant->programNetworkID) {
					case 1:
					{
						$country_id = 1;
						break;
					}
					case 2:
					{
						//FRANCE
						$country_id = 4;
						break;
					}
					case 3:
					{
						//Germany
						$country_id = 2;
						break;
					}
					case 4:
					{
						//netherland
						$country_id = 5;
						break;	
					}
					case 7:
					{
						//spain
						$country_id = 6;
						break;
					}
					case 8:
					{
						//usa
						$country_id = 3;
						break;
					}
					case 9:
					{
						//ireland
						$country_id = 7;
						break;
					}
					case 5:
					{
						$country_id = 8;
						break;
					}
					case 6:
					{
						$country_id = 9;
						break;
					}
	
				}
				
				$current_merchant = array();
				$current_merchant['network_id'] = $network_id;
				$current_merchant['country_id'] = $country_id;;
				$current_merchant['id'] = $merchant->programID;
				$current_merchant['displayurl'] = $merchant->programURL;
				$current_merchant['name'] = $merchant->programName;
				$current_merchant['description'] = $merchant->programDescription;
				$current_merchant['strapline'] = $merchant->programShortDescription;
				$current_merchant['logo'] = 'http://www.webgains.com/logos/showlogo.html?program_id='.$merchant->programID;
				$merchant_list[] = $current_merchant;
			}
		}

		$i=0;
		//echo count($merchant_list);
		$sql = "INSERT INTO pm_programs (id, network_id, country_id, name, merchant_ref, logo) VALUES ";
		foreach($merchant_list as $key => $merchant)
		{
			$values = sprintf("('', %d, %d, '%s', '%s', '%s'),",
					$merchant['network_id'],
					$merchant['country_id'],
					str_replace("'", "\'", $merchant['name']),
					$merchant['id'],
					$merchant['logo']
				);
			//print $values."\n";
			$sql .= $values;
			$i++;
		}
		$sql = substr_replace($sql,";",-1);
		$delete = "DELETE FROM pm_programs WHERE network_id=".$network_id;
		$wpdb->query($delete);
		$wpdb->query($sql);

		$sql = "UPDATE pm_networks SET last_update=".time()." WHERE class_name='".get_class($this)."'";
		$wpdb->query($sql);

		$output .= '<div class="updated fade">';
		$output .= $i." Webgains merchants inserted.</div>";
		return $output;
	}

	public function addFeed($feed, $options, $wpdb)
	{
		$feed_url = 'http://content.webgains.com/affiliates/datafeed.html?action=download&campaign='.$options['icon_global_' . self::$prefix . '_id'].'&username='.$options['icon_global_' . self::$prefix . '_username'].'&password='.$options['icon_global_' . self::$prefix .'_password'].'&format=xml&zipformat=none&fields=extended&programs='.$feed->merchant_ref.'&allowedtags=&categories=all';
		$sql = "INSERT INTO pm_feeds (id, name, url, network_id, merchant_ref)
				VALUES ('','".mysql_real_escape_string($feed->name)."','".$feed_url."',".$feed->network_id.",'".$feed->merchant_ref."')";
		$wpdb->query($sql);
		
		return $feed->name.' added!';
		
	}
	
	function parse_xml($file, $feed_id)
	{
		global $wpdb;

		$reader = new XMLReader();
		$reader->open($file);

		$sql = "DELETE FROM pm_products WHERE feed_id =".$feed_id;
		$wpdb->query($sql);

		// Read each line of the XML
		$i=0;
		$query ='';
		while ($reader->read())
		{
			switch ($reader->nodeType)
			{
				// Check that this line is an element, rather than a declartion or a comment.
				case (XMLREADER::ELEMENT):
				{
					// We only care if the element is a product
					if ($reader->localName == 'product')
					{
						$node = $reader->expand();
						$dom = new DomDocument();
						$domNode = $dom->importNode($node,true);
						$dom->appendChild($domNode);
						$product = simplexml_import_dom($domNode);

						$product['feed_id'] =			$feed_id;
						$product['product_id'] =           $wpdb->escape($product->product_id);
						$product['product_name'] =         $wpdb->escape($product->product_name);
						$product['product_price'] =        $wpdb->escape($product->price);
						$product['product_description'] =  $wpdb->escape($product->description);
						$product['gender'] =               $wpdb->escape($product->gender);
						$product['brand'] =                $wpdb->escape($product->brand);
						$product['rrp'] =                  $wpdb->escape($product->recommended_retail_price);
						$product['deeplink'] =             $wpdb->escape($product->deeplink);
						$product['image_url'] =            $wpdb->escape($product->image_url);
						$product['image_thumbnail'] =      (false !== strpos($product->image_thumbnail_url, 'http')) ? $wpdb->escape($product->image_thumbnail_url) : $product['image_url'];
						$product['category'] =             $wpdb->escape($product->merchant_category);

						$query = "('','".$product['feed_id']."','".$product['product_name']."','".$product['product_price']."','".$product['product_description']."','".$product['short_description']."','".$product['gender']."','".$product['brand']."','".$product['rrp']."','".$product['product_id']."','".$product['deeplink']."','".$product['image_url']."','".$product['category']."','".$product['image_thumbnail']."','".$product['image_url']."'),";
						$this->insert_products($query);
						
						$i++;

					}
				}
			}
		}
		$this->update_master();
			
		return $i;
	}
}