<?php

class icon_feed_processor
{
	function process_feed($feed_id)
	{
		global $wpdb;
		
		$sql="SELECT f.id, f.name, f.url, n.class_name
				FROM pm_feeds f
				INNER JOIN pm_networks n ON n.id=f.network_id
			  	WHERE f.id=".$feed_id." ORDER BY f.name ASC";
		$feeds=$wpdb->get_results($sql, OBJECT);
		$path4feed = ABSPATH.'wp-content/plugins/ODSTP20/feeds/';
		foreach($feeds as $feed)
		{
			print "<h2>Processing feed ". $feed->name."</h2>";
			$file = $path4feed.'feed'.$feed->id;
			
			set_error_handler(array($this,'handleError'));
			
			register_shutdown_function(array($this,'handleShutdown'));
	
			try{
			$data = $this->curl_write_url_to_file($feed->url, $file);
			}
			catch( Exception $ex)
				{
				restore_error_handler();
				echo('<div class="error fade">Error downloading feed.  This could be caused by limited server resources.</div>');
				}
			restore_error_handler();
		
			//fwrite($fp, $data);
			

			// determine network
			if (true === class_exists($feed->class_name)) {
				$network = new $feed->class_name;
				$products = $network->parse_xml($file, $feed_id);

				// categorise
				// this doesn't look right, but i've been drinking beer...
				//$this->categorise();
	
				$sql = 'UPDATE pm_feeds af SET af.products=(SELECT count(ap.id) FROM pm_products ap WHERE ap.feed_id=af.id) WHERE af.id='.$feed_id;
				$wpdb->query($sql);
				print $products." products inserted.<br />Done.<br /><br />";
			}
		}
	}

	function categorise()
	{
		global $wpdb;

		$sql = 'SELECT DISTINCT feed_id, Category FROM pm_products';
		$categories = $wpdb->get_results($sql, OBJECT);
		foreach ($categories as $category)
		{
			$sql = "INSERT INTO pm_categories (id, feed_id, name) VALUES ('','".$category->feed_id."','".$wpdb->escape($category->Category)."');";
			$wpdb->query($sql);
		}
	}
	
	

	function handleShutdown() {
			$error = error_get_last();
			if($error !== NULL){
				//$info = "[SHUTDOWN] file:".$error['file']." | ln:".$error['line']." | msg:".$error['message'] .PHP_EOL;
				echo('<div class="error fade">Error downloading feed.  This could be caused by limited server resources.</div>');
			}
			else{
				
			}
		}


	function handleError($errno, $errstr, $errfile, $errline, array $errcontext)
{
    // error was suppressed with the @-operator
    if (0 === error_reporting()) {
        return false;
    }

    //echo('<div class="error fade">Error downloading feed.  This could be caused by limited server resources.</div>');
}

	// Function to download a file.
	function curl_get_file_contents($url)
	{
		// Output something so we know it's working.
		//print "Downloading...<br />";//'".$url."'\n";
		
		flush();

		$c = curl_init();
		curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($c, CURLOPT_URL, $url);
		curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 5000);
		curl_setopt($c, CURLOPT_TIMEOUT, 10000);
		$contents = curl_exec($c);
		curl_close($c);

		return $contents;
	}
	
	function __writeFunction($ch, $chunk) { 
					
					global $thefile;
					$fp = fopen($thefile, 'a');
					fwrite($fp, $chunk);
					fclose($fp);	
					
					return strlen($chunk);					
					}
					
	function curl_write_url_to_file($url,$file)
	{
		// Output something so we know it's working.
		//print "Downloading...<br />";//'".$url."'\n";
		
		$thefp = fopen($file, 'w');
		fclose($thefp);
				
		global $thefile;
		
		$thefile = $file;
		
		$c = curl_init();
		curl_setopt($c, CURLOPT_WRITEFUNCTION, array($this,'__writeFunction'));
		curl_setopt($c, CURLOPT_URL, $url);
		curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 600);
		curl_setopt($c, CURLOPT_TIMEOUT, 1200);		
		curl_exec($c);
		
	}

}