<?php
class Product_Category_Walker extends Walker_Category {
 
	private $term_ids = array();
 
	function __construct( )  {
				
	}
 
	function start_el(&$output, $category, $depth, $args) {
		extract($args);

		$cat_name = esc_attr( $category->name);
		
		$link = '<a href="#" onclick="odst_map_products_search(\'\', \'\', \'\', \'\', \'\', \'\', \'\', ' . $category->term_id . ',\'' . $category->name . '\', \'\', \'\', false, false);return false;">';
						
		$link .= $cat_name . '</a>';
			

		if ( isset($current_category) && $current_category )
			$_current_category = get_category( $current_category );

		if ( 'list' == $args['style'] ) {
			$output .= "\t<li rel='" . $category->term_id . "' ";
			$class = 'cat-item cat-item-'.$category->term_id;
			if ( isset($current_category) && $current_category && ($category->term_id == $current_category) )
				$class .=  ' current-cat';
			elseif ( isset($_current_category) && $_current_category && ($category->term_id == $_current_category->parent) )
				$class .=  ' current-cat-parent';
			$output .=  ' class="'.$class.'"';
			$output .= ">$link\n";
		} else {
			$output .= "\t$link<br />\n";
		}
	}

	
}
?>