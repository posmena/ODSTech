<?php

class icon_module_feedmanager
{
	function __construct()
	{
		add_action('admin_menu', array(&$this, 'add_menu'));
		add_action( 'init', array(&$this, 'feedmanager_init') );
	}
	
	function feedmanager_init() {
	// create a new taxonomy
	register_taxonomy(
		'odst_products',
		null,
		array(
			'label' => __( 'ODST Product Categories' ),
			'sort' => true,
			'args' => array( 'orderby' => 'term_order' ),
			'rewrite' => array( 'slug' => 'product_category' ),
			'hierarchical' => true
		)
	);
}

	function add_menu()
	{
		
		//add_submenu_page('pm-pro-home', 'Edit Categories', 'Edit Categories', 'manage_options', 'edit-tags.php?taxonomy=odst_products');
		
					
		add_submenu_page('pm-pro-home', __('Manage Feeds','pm-top-level'), __('Manage Feeds','pm-top-level'),
						'manage_options', 'pm-add-feeds', array(&$this, 'add_feeds'));
						
		//add_submenu_page('pm-pro-home', __('Product Mapping','pm-top-level'), __('Product Mapping','pm-top-level'),
		//				'manage_options', 'pm-map-products', array(&$this, 'process_mapping'));
		
		//add_submenu_page('pm-pro-home', __('Sitemap','pm-top-level'), __('Sitemap','pm-top-level'),
			//			'manage_options', 'pm-sitemap', array(&$this, 'sitemap'));
	}
	
	/**
	 * Called on activation of parent (pricematcher::activation)
	 */
	function activate()
	{
		global $wpdb;
		
			$sql = "CREATE TABLE `pm_categories` (
					  `id` int(11) NOT NULL AUTO_INCREMENT,
					  `feed_id` int(11) NOT NULL,
					  `name` varchar(50) NOT NULL,
					  PRIMARY KEY (`id`),
					  UNIQUE KEY `feed_id` (`feed_id`,`name`)
					);";
			require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
			dbDelta($sql);
		
			$sql = "CREATE TABLE pm_feeds (
					`id` int(10) unsigned NOT NULL AUTO_INCREMENT,
					  `name` text NOT NULL,
					  `url` text NOT NULL,
					  `products` int(11) NOT NULL,
					  `network_id` int(11) NOT NULL,
					  `merchant_ref` varchar(10) NOT NULL,
					PRIMARY KEY id (`id`),
					UNIQUE KEY `network_id` (`network_id`,`merchant_ref`)
				);";

			require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
			dbDelta($sql);
		
			$sql = "CREATE TABLE `pm_networks` (
					  `id` int(11) NOT NULL auto_increment,
					  `name` varchar(50) NOT NULL,
					  `last_update` int(11) NOT NULL,
					  `class_name` varchar(50) NOT NULL,
					  PRIMARY KEY (`id`),
					  UNIQUE KEY `class_name` (`class_name`)
					);";
			require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
			dbDelta($sql);
		
			$sql = "CREATE TABLE `pm_products` (
				  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `feed_id` int(11) NOT NULL,
				  `ProductName` varchar(255) NOT NULL,
				  `ProductPrice` decimal(9,2) NOT NULL,
				  `ProductDescription` text NOT NULL,
				  `SummaryDescription` varchar(255) NOT NULL,
				  `Gender` varchar(255) NOT NULL,
				  `BrandName` varchar(255) NOT NULL,
				  `RRP` varchar(255) NOT NULL,
				  `ProductID` varchar(255) NOT NULL,
				  `AffiliateURL` text NOT NULL,
				  `ImageURL` varchar(255) NOT NULL,
				  `Category` varchar(255) NOT NULL,
				  `SmallImageURL` varchar(255) NOT NULL,
				  `LargeImageURL` varchar(255) NOT NULL,
				  `deleted` boolean DEFAULT false NOT NULL,
				  `uid` int(11) NOT NULL,
				  PRIMARY KEY (`id`),
				  KEY `feed_id` (`feed_id`,`ProductID`),
				  KEY `feed_id_2` (`feed_id`),
				  FULLTEXT KEY `BrandName` (`BrandName`),
				  FULLTEXT KEY `IDX_PMP_Category` (`Category`),
				  FULLTEXT KEY `ProductName` (`ProductName`,`ProductDescription`,`BrandName`,`ProductID`,`Category`),
				  FULLTEXT KEY `ProductID` (`ProductID`),
				  FULLTEXT KEY `ProductName_2` (`ProductName`,`ProductDescription`,`SummaryDescription`,
				  				`BrandName`,`ProductID`,`AffiliateURL`,`Category`,`SmallImageURL`,`LargeImageURL`)
				);";

			require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
			 dbDelta($sql);
		
					$sql = "CREATE TABLE `pm_product_ids` (
				  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `feed_id` int(11) NOT NULL,
				  `ProductID` varchar(255) NOT NULL,
				  `uid` int(11) NOT NULL,
				  KEY `IDX_pids_feed_id_productid` (`feed_id`,`ProductID`),
				  PRIMARY KEY (`id`)			 
				);";

			require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
			dbDelta($sql);
			
					$sql = "CREATE TABLE `pm_master_products` (
				  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `ProductName` varchar(255) NOT NULL,
				  `ProductDescription` text NOT NULL,
				  `SummaryDescription` varchar(255) NOT NULL,
				  `BrandName` varchar(255) NOT NULL,
				  `RRP` varchar(255) NOT NULL,
				  `ImageURL` varchar(255) NOT NULL,
				  `SmallImageURL` varchar(255) NOT NULL,
				  `LargeImageURL` varchar(255) NOT NULL,
				  `deleted` boolean DEFAULT false NOT NULL,
				  `uid` int(11), 
				   PRIMARY KEY (`id`),	
				   KEY `IDX_pmm_uid` (`uid`),				  
				   FULLTEXT KEY `master_BrandName` (`BrandName`),
				   FULLTEXT KEY `master_ProductName` (`ProductName`,`ProductDescription`,`BrandName`)				 
				);";

			require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
			dbDelta($sql);
			
			$sql = "CREATE TABLE `pm_programs` (
					  `id` int(11) NOT NULL AUTO_INCREMENT,
					  `network_id` int(11) NOT NULL,
					  `country_id` int(11) NOT NULL,
					  `name` varchar(50) NOT NULL,
					  `merchant_ref` varchar(10) NOT NULL,
					  `logo` varchar(255) NOT NULL,
					  PRIMARY KEY (`id`)
					);";
			require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
			dbDelta($sql);
		
		
			$sql = "CREATE TABLE  `pm_products_terms_lnk` (
				  `uid` int(11) NOT NULL,
				  `term_id` int(11) NOT NULL,
				  KEY `IDX_terms_uid` (`term_id`),
				  PRIMARY KEY  (`uid`)
				);";
		require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
			dbDelta($sql);		
		

			$sql = "CREATE TABLE `pm_terms2categories` (
					  `term_id` int(11) NOT NULL,
					  `category_id` int(11) NOT NULL,
					  UNIQUE KEY `term_id` (`term_id`,`category_id`)
					);";
			require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
			dbDelta($sql);
		
		$options = get_option('pm_options');
		$options['icon_global_shop_cat'] = icon_module_feedmanager::ginsert_new_category('Shop');
		update_option('pm_options', $options);
	}
	
	function main_settings()
	{
	}
	
	/**
	 * Displays the feeds added as well as the total number of possible feeds available.
	 */
	function display_feeds()
	{
		global $wpdb;
		
		$options = get_option('pm_options');

		if($_GET['update_network'])
		{
			$class_name = $_GET['update_network'];
			$network_id = $_GET['id'];
			if (true === class_exists($class_name)) {
				$network = new $class_name;
				print $network->updateFeedList($network_id, $options, $wpdb);
			}
			
			 
		}
		
		
			// load the feeds from database
			$feeds    = PriceMatcherLoader::getDbNetworks();
			$networks = PriceMatcherLoader::getNetworks();
			if (count($networks) !== count($feeds)) {
				PriceMatcherLoader::updateDbNetworks();
				$feeds = PriceMatcherLoader::getDbNetworks();
			}
			
			$output = '<h3>Feed Summary</h3><table><thead><tr><th align="left" width="150">Network</th><th align="left" width="170">Available Programs</th><th align="left" width="75">In Use</th><th align="left">Last Updated</th></tr></thead><tbody>';
			
			// only display ones where network file exists, regardlress of entries in database
			foreach($networks as $network)
			{
				$date_updated = ($feeds[get_class($network)]->last_update > 0) ? date(get_option('date_format'), $feeds[get_class($network)]->last_update) : 'Not yet';
				$output .= '<tr><td>'.$network->getName().'</td><td>' . $feeds[get_class($network)]->programs . '</td><td>' . $feeds[get_class($network)]->in_use . '</td><td>' . $date_updated . '</td><td><a href="?page=pm-add-feeds&id=' . $feeds[get_class($network)]->network_id .'&update_network='.get_class($network).'">refresh feed list for ' .$network->getName().'</a></td></tr>';
			}
			$output .= '</table>';
			
			
			
			$sql         = 'SELECT id, name, url, products FROM pm_feeds ORDER BY name ASC';
			$feeds       = $wpdb->get_results($sql, OBJECT);
			$feed_output = '<div><h3>Current Feeds</h3>';

			if (count($feeds) > 0) {
				$feed_output .= '<table><thead><tr>
													<th width="200" align="left">Name</th><th width="75" align="left">Products</th>
													<th align="left">Action</th></tr></thead><tbody>';
				if ($feeds && (count($feeds)>0)) {
					foreach ($feeds as $feed) {
						$feed_output .= '<tr><td>'.$feed->name.'</td><td>'.$feed->products.'</td>
										<td><a href="?page=pm-add-feeds&update='.$feed->id.'">Update</a></td>
										<td><a href="?page=pm-add-feeds&remove='.$feed->id.'">Remove</a></td></tr>';
					}
				}
				
				$feed_output .= '</tbody></table></div>';
			} else {
				$feed_output .= 'You do not currently have any feeds.';
			}
			
			print $output;
			print $feed_output;
		
	}

	/**
	 * Used for adding feeds 
	 */
	function add_feeds()
	{
		
		global $wpdb;
	
		$options = get_option('pm_options');
		
		if( !PriceMatcherLoader::check_odst_login($options['odst_username'],$options['odst_password']))
			{
			echo "<div class='error fade'><p><strong>Incorrect username or password. Please check your <a href='admin.php?page=pm-pro-home'>settings</a></strong></p></div>";				
			return;
			}
		
		if ($_GET['insert']) {
			$sql = "SELECT p.name, p.network_id, p.merchant_ref, n.class_name
					FROM pm_programs p
					INNER JOIN pm_networks n ON n.id=p.network_id
					WHERE p.id=".$_GET['insert'];
			$result = $wpdb->get_results($sql);
			//$output = '';
			foreach($result as $feed) {
				if (true === class_exists($feed->class_name)) {
					$network = new $feed->class_name;
					$network->addFeed($feed, $options, $wpdb);
				}
			}
		} 
		
		if ($_GET['update']) {
			$feed_id = $_GET['update'];
			$fp = new icon_feed_processor;
			try{
				$fp->process_feed($feed_id);
				}
			catch(Exception $ex)
				{
				$output .= '<div class="error fade">Unable to download feed.  This could be caused by limited server resources.</div>';
				}
		}
		
		else if ($_GET['remove']) {
			$feed_id = $_GET['remove'];
			$sql = "DELETE FROM pm_products WHERE feed_id=".$feed_id;
			$sql2 = "DELETE FROM pm_feeds WHERE id=".$feed_id;
			$wpdb->query($sql);
			$wpdb->query($sql2);
		}

		// check see which feeds have not been added yet
		$sql = "SELECT f.id as feed_id, p.id as program_id, p.name, n.name as network_name, p.country_id
				FROM pm_programs p
				INNER JOIN pm_networks n ON n.id=p.network_id
				LEFT OUTER JOIN pm_feeds f ON (f.merchant_ref=p.merchant_ref AND f.network_id=p.network_id)
				ORDER BY f.id DESC,network_name,p.name";
		$available = $wpdb->get_results($sql);
		
		$output = '<h3>All Available Feeds</h3>';
		if(count($available) > 0)
		{
			$output .= '<table><thead><tr><th align="left">Name</th><th align="left" width="150">Network</th><th>Country</th></tr></thead>';
			foreach($available as $program)
		
			{
				if( !$program->feed_id )
				{
				$output .= '<tr><td>'.$program->name.'</td><td>'.$program->network_name.'</td><td>'.$program->country_id.'</td><td>';
				if($program->feed_id){
					$output .= 'already added (<a href="?page=pm-add-feeds&update='.$program->feed_id.'" target="_blank">process feed</a> :: <a href="?page=pm-add-feeds&remove='.$program->feed_id.'">remove feed</a>)';
				}
				else{
					$output .= '<a href="?page=pm-add-feeds&insert='.$program->program_id.'">add this feed</a>';
				}
				
				$output .= '</td></tr>';
				}
			}
			$output .= '</table>';
		}
		else
		{
			$output .= 'There are currently no programs available. Try pressing update on one of the above networks.';
		}
		
		$this->display_feeds();
		print $output;
		
		
	}
	
	/**
	 * Mapping list, shows the relationship between wp_terms and merchant categories
	 */
	function list_mappings($cat_list, $options, $edit = false)
	{
		$save_button = '<input type="submit" value="Save Mapping" name="save_mapping" />';
		$form_field = '<form method="post" action="?page=pm-map-products">';
		$mapping = '<span><strong>There are '.count($cat_list).' unmapped categories.</strong></span> (<a href="?page=pm-map-products&view-mapping=1">view/edit mapped categories</a>)<br /><table>';
		if($edit)
		{
			$save_button = '<input type="submit" value="Update Mapping" name="update_mapping" />';
			$form_field = '<form method="post" action="?page=pm-map-products&view-mapping=1">';
			$mapping = '<span><strong>There are '.count($cat_list).' mapped categories.</strong>
			</span> (<a href="?page=pm-map-products&clear-mapping=1">CLEAR ALL MAPPING</a>)<table><br />';
		}
		$wp_cats = get_categories(array('hide_empty' => 0, 'child_of' => $options['icon_global_shop_cat']));


		$output = $mapping;
		$output .= $form_field;
		$output .= wp_nonce_field('icon-map-products');
		$output .= $save_button;
		$last_feed = 0;
		foreach ($cat_list as $cat)
		{
			if($cat->feed_id != $last_feed)
			{
				$output .= '<tr><td>&nbsp;</td></tr><tr><td colspan=3><strong>'.$cat->program_name.'</strong></td></tr>';
				$last_feed = $cat->feed_id;
			}
			$output .= '<tr><td>'.$cat->name.'</td><td><select name="category['.$cat->id.']">';
			$cat_html = '<option value="">new (enter in box to right)</option>';;
			foreach($wp_cats as $wp_category)
			{
				if($cat->term_id == $wp_category->term_id)
				{
					$cat_html .= '<option value="'.$wp_category->term_id.'" selected="selected">'.$wp_category->name.'</option>';
				}
				else
				{
					$cat_html .= '<option value="'.$wp_category->term_id.'">'.$wp_category->name.'</option>';
				}
			}

			$output .= $cat_html;
			$output .= '</select></td><td><input type="text" name="new_cat['.$cat->id.']" /></td></tr>';
		}
		$output .= "</table>";
		$output .= $save_button;
		$output .= '</form>';
		return $output;
	}

	function process_mapping()
	{
		global $wpdb;
		/*** If the user has pressed save_mapping ***/
		if (isset($_POST['save_mapping']))
		{
			$categories = $_POST['category'];
			$new_cats = $_POST['new_cat'];
			foreach($categories as $cat_id => $term_id)
			{
				if(!$term_id && $new_cats[$cat_id])
				{
					$term_id = icon_module_feedmanager::ginsert_new_category($new_cats[$cat_id]);
				}

				if($term_id)
				{
					$sql = 'INSERT INTO pm_terms2categories (category_id, term_id) VALUES ('.$cat_id.','.$term_id.')';
					if(!$wpdb->query($sql))
					{
						$sql = 'UPDATE pm_terms2categories SET term_id='.$term_id.' WHERE category_id='.$cat_id;
						$wpdb->query($sql);
					}
				}
			}

			echo "<div class='updated fade'><p><strong>AffiliateFeedPro settings saved.</strong></p></div>";
		}
		/*** end of save_mapping ***/

		/*** If the user has pressed update_mapping ***/
		if (isset($_POST['update_mapping']))
		{
			$categories = $_POST['category'];
			$new_cats = $_POST['new_cat'];
			foreach($categories as $cat_id => $term_id)
			{
				if(!$term_id && $new_cats[$cat_id])
				{
					$term_id = icon_module_feedmanager::ginsert_new_category($new_cats[$cat_id]);
				}

				if($term_id)
				{
					$sql = 'UPDATE pm_terms2categories SET term_id='.$term_id.' WHERE category_id='.$cat_id;
					$wpdb->query($sql);
				}

			}
			echo "<div class='updated fade'><p><strong>PriceMatcher settings saved.</strong></p></div>";
		}
		/*** end of update_mapping ***/

		$options = get_option('pm_options');

		if($_GET['clear-mapping'])
		{
			$sql = "DELETE FROM pm_terms2categories";
			$wpdb->query($sql);
			$output .= "All Category mapping deleted<br />";
		}

		if($_GET['view-mapping'])
		{
			PriceMatcherLoader::is_unmapped_cats();
			$output .= '<h2>View/Edit Mapping</h2>';
			$categorised = PriceMatcherLoader::get_mapped_cats();
			$output .= icon_module_feedmanager::list_mappings($categorised, $options, true);
		}
		else
		{
			/*** Load the categories that require mapping ***/
			$need2cat = PriceMatcherLoader::get_unmapped_cats();
			$nr2cat = count($need2cat);
			if($nr2cat > 0 && $options['icon_global_shop_cat'])
			{
				$output .= icon_module_feedmanager::list_mappings($need2cat, $options);
			}
			elseif(!$options['icon_global_shop_cat'])
			{
				$output = 'You cannot map categories until you have specified a shop category.';
			}
			else
			{
				$output = 'You do not have any categories to map at this time.';
			}
			/*** end of loading categories that require mapping ***/

			/*** output ***/
			print '<h2>Process Mapping</h2>';
		}

		print $output;

		/*** end of output ***/
	}

	function ginsert_new_category($category_name, $root=false)
	{
		global $wpdb;
		$options = get_option('pm_options');
		$term_id = false;
		// search in text field, see if this cat already exists.
		$new_cat_slug = pathauto_cleanstring($category_name);
		$cats = get_categories(array('hide_empty' => 0));
		foreach($cats as $category){
			if($category->slug == $new_cat_slug){
				$term_id = $category->term_id;
			}
		}
		if(!$term_id)
		{
			// still not found the category, so create it.
			if($root)
			{
				$term_id = wp_create_category($category_name);
			}
			else
			{
				$term_id = wp_create_category($category_name, $options['icon_global_shop_cat']);
			}
		}
		return $term_id;
	}

	function sitemap()
	{
		global $wpdb;
		$options = get_option('pm_options');
		$productxml = ABSPATH.'/products.xml';
		
		$output = '<h3>Product Sitemap</h3>';
		$output .= '<p>You may create a addiional sitemap which simply has a list of all the product pages.</p>';
		$output .= '<a href="?page=pm-sitemap&generate=yes">Generate</a>';
		
		if (array_key_exists('generate', $_GET) && $_GET['generate'] == 'yes') {
			$sql = "SELECT * FROM pm_products LIMIT 0,3000";
			$results = $wpdb->get_results($sql);
			$sitemap = new icon_sitemap;
			foreach ($results as $prod)
			{
				$url = get_bloginfo('url').'/'.$options['icon_productdisplay_mainpage'].'/'.$prod->feed_id."/".$prod->ProductID."/".pathauto_cleanstring($prod->ProductName).".html";
				$sitemap->addItem($url);
			}
			$hn = fopen($productxml, 'w+');
			fwrite($hn, $sitemap->getSitemap());
			fclose($hn);
			$output .= '<br /><br />Your new xml file ('.count($results).' products) is here: <a href="'.get_bloginfo('url').'/products.xml">'.get_bloginfo('url').'/products.xml</a>';
		}
		
		echo $output;
	}

	
}


