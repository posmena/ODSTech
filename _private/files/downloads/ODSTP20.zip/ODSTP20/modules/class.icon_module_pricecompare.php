<?php

class icon_module_pricecompare
{
	function __construct()
	{
		add_action('admin_menu', array(&$this, 'add_menu'));
	}
	
	function activate()
	{
	global $wpdb;
	
	if($wpdb->get_var("show tables like 'pm_custom_product_groups'") != 'pm_custom_product_groups') {
			$sql = "CREATE TABLE IF NOT EXISTS `pm_custom_product_groups` (
					  `id` int(11) NOT NULL auto_increment,
					  `name` varchar(50) NOT NULL,
					  PRIMARY KEY (`id`)
					);";
			require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
			dbDelta($sql);
			
			$sql = "CREATE TABLE IF NOT EXISTS `pm_custom_product_group_products` (
					  `productID` varcghar(50) NOT NULL,
					  `product_group_id` int(11) NOT NULL,
					  `feed_id` int(11) NOT NULL,
					  PRIMARY KEY (`productID`,`product_group_id`,`feed_id`)
					);";
			require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
			dbDelta($sql);
		}
	}
	
	function main_settings()
	{
	}
	
	function add_menu()
	{
		//add_submenu_page('pm-pro-home', __('Price Compare','pm-top-level'), __('Price Compare','pm-top-level'),
		//				'manage_options', 'pm-pricecompare', array(&$this, 'edit_product_grouping'));
		
	}
	
	function edit_product_grouping()
	{
		global $wpdb;
		
		
		if (array_key_exists('create', $_POST)) {
			$sql = sprintf("INSERT INTO pm_custom_product_groups SET name='%s'", $wpdb->escape($_POST['new_custom_product']));
			$wpdb->query($sql);
		}
		
		if (array_key_exists('update', $_POST)) {
			$sql = sprintf("UPDATE pm_custom_product_groups SET name='%s' WHERE id=%d", $wpdb->escape($_POST['product_name']), $_POST['update']);
			$wpdb->query($sql);
		}
		
		if ((int)$_POST['remove_product']) {
			foreach ($_POST['remove_product'] as $product_id => $checked) {
				
				$query = 'DELETE FROM pm_custom_product_group_products WHERE
							ProductID=\'' . $product_id . '\' AND product_group_id=\'' . $_POST['update'] . '\' AND feed_id=\'' . $checked . '\';';
				$wpdb->query($query);
				}
			}
			
		if ((int)$_GET['edit']) {
			
			$sql = sprintf("SELECT cp.id, cp.name FROM pm_custom_product_groups cp WHERE cp.id=%d", $_GET['edit']);
			$c_product = $wpdb->get_row($sql);
			
			$sql = sprintf("SELECT p.ProductName, cp.ProductID, p.feed_id
							FROM pm_products p
							INNER JOIN pm_custom_product_group_products cp ON (cp.feed_id=p.feed_id AND cp.ProductID = p.ProductID)
							WHERE cp.product_group_id = %d", $_GET['edit']);
			$products = $wpdb->get_results($sql);
					
			
			
			$header = '<div class="wrap">';
			$header .= '<h2>Editing '.$c_product->name.'</h2>';
			$header .= '<p><em>Here you can view the products in a custom product group</em></p>';
			$header .= '<form method="post" action="?page=pm-pricecompare&edit=' . $_GET['edit'] . '">';
			$header .= wp_nonce_field('pm-update-pricecompare-groups');
			$header .= '<input type="hidden" name="update" value="'.$_GET['edit'].'" />';
			$output .= 'Product Name <input type="text" name="product_name" value="'.$c_product->name.'" style="width: 250px" />&nbsp; <input type="submit" name="save" value="Update" /><br />';
			
			if (count($products) > 0) {
				$output .= '<br><h3>Existing Products</h3>';
				$output .= '<table>';
				
				foreach ($products as $product) {					
					$output .= '<tr><td>' . $product->ProductName.'</td>';
					$output .= '<td><input type="checkbox" name="remove_product['.$product->ProductID.']" value="'.$product->feed_id.'" /></td>';
					$output .= '</tr>';
										
				}
				
				$output .= '<tr><td></td><td><input type="submit" value="Remove selected products from Product Group" name="remove_from_product_group" /></td></table>';
				
			} else {
				$output .= 'You have not added any products to this group, head over to search and add them from there.';
			}
			$footer .= '<br />';
			$footer .= '</form></div>';
			
		} else {
			$header = '<div class="wrap">';
			$header .= '<h2>Custom Product Group List</h2>';
			$header .= '<p><em>Here you can add custom product groups to allow price comparison</em></p>';
			$header .= '<form method="post" action="?page=pm-pricecompare">';
			$header .= wp_nonce_field('pm-update-pricecompare');
			$header .= '<input type="hidden" name="create" value="update" />';
			$header .= '<table><tr><th align="left">Name</th></tr>';
			$output = '';
			
			
			// get custom products
			$sql      = 'SELECT cp.id, cp.name FROM pm_custom_product_groups cp';
			$products = $wpdb->get_results($sql);
			if(count($products) > 0) {
				foreach ($products as $product) {
					$output .= '<tr><td><a href="?page=pm-pricecompare&edit='.$product->id.'">'.$product->name.'</a></td></tr>';
				}
			}
			$output .= '<tr><td><input type="text" name="new_custom_product" value="Custom Product Name" style="width: 250px;"/></td></tr></table>';
			$footer .= '<input type="submit" name="save" value="Save" />';
			$footer .= '</form></div>';
		}
		print $header.$output.$footer;
	}
}