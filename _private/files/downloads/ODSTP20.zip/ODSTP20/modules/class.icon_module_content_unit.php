<?
class icon_module_content_unit
{		
	public function __construct()
	{			
    add_filter('admin_print_scripts', array(&$this, 'adminHead') );
	
 	wp_register_style('odst_admin_style', plugins_url( 'css/odst_admin.css', dirname(__FILE__) ));		
	wp_register_style('odst_style', plugins_url( 'css/odst.css', dirname(__FILE__) ));
	wp_register_style('odst_carousel_style', plugins_url( 'css/odst_carousel.css', dirname(__FILE__) ));
	
	wp_register_style('colorpicker', plugins_url( 'css/jquery.miniColors.css', dirname(__FILE__) ));	
	wp_register_style('tooltip', plugins_url( 'css/jquery.tooltip.css', dirname(__FILE__) ));	
	
	add_filter('media_buttons_context', array(&$this,'odst_add_media_button'));		
	
	wp_enqueue_style('odst_style');
	wp_enqueue_style('odst_carousel_style');
	wp_enqueue_style('odst_admin_style');		
	wp_enqueue_style('odst_easyjet_style');			
	wp_enqueue_style('thickbox');
	
	wp_enqueue_style('colorpicker');
	wp_enqueue_style('tooltip');
	
	wp_enqueue_script('thickbox',null,array('jquery'));
	wp_enqueue_script( 'jquery-ui-core' );
	wp_enqueue_script( 'jquery-ui-tabs' );
		
	wp_register_script('tooltip', plugins_url( 'js/jquery.tooltip.js', dirname(__FILE__) ),array('jquery'), '1.0.0');
	wp_enqueue_script('tooltip');	

	wp_register_script('easyslider', plugins_url( 'js/easySlider1.7.js', dirname(__FILE__) ),array('jquery'), '1.0.0');
	wp_enqueue_script('easyslider');	
		
	add_action( 'add_meta_boxes', array(&$this, 'add_meta_boxes') );
	add_shortcode( 'odst_content_unit', array(&$this, 'odst_short_code') );
	add_action( 'widgets_init', array(&$this,'odst_register_widgets') );
	add_action('admin_footer', array(&$this,'odst_product_overlay_popup_form'));
	add_action('admin_footer', array(&$this,'odst_shortcode_overlay_popup_form'));

	add_action('admin_head', array(&$this,'update_product_action_javascript'));
	add_action('wp_ajax_my_action', array(&$this, 'wp_ajax_my_action_callback'));	
	
	add_filter('odst_widget_content', array(&$this, 'get_widget_contents'), 8, 7);
		
	}

	function odst_add_media_button($context) {

//    $result = '<a href="javascript:show_odst_product(\'8717842014103\',1)">Edit Product</a>';
	$icon_url = plugins_url( '/img/icon-p20.png', dirname(__FILE__) );

	$result = '<a href="#TB_inline?width=540&height=560&inlineId=odst_add_product_content" class="thickbox" title="Insert Product"><img src="' . $icon_url . '"/></a>';

    return $context . $result;
}


	function activate()
 {
		$options = get_option('pm_options');
		$options['background_colour'] = '#EEEEEE';
		$options['border_colour'] = '#D9D9D9';
		$options['product_name_bg_colour'] = '#0F2A3C';
		$options['product_name_colour'] = '#FFFFFF';
		$options['price_colour'] = '#373737';
		$options['even_row_colour'] = '#EEEEEE';
		$options['odd_row_colour'] = '#F4EDED';

		update_option('pm_options', $options);

 }
 
 function odst_shortcode_overlay_popup_form()
 {
  echo '<div id="odst_shortcode_content" style="display:none">
		<div id="odst_shortcode_in">
		To show the product on your page / post add the following to the post content:
		<br/><br/>
		<div id="odst_shortcode"></div>
	</div></div>';
	
 }
 
 function odst_product_overlay_popup_form()
 {
 //if ($GLOBALS['editing']) {


	 //echo '<a href="#TB_inline?width=540&height=560&inlineId=odst_edit_product_content" class="thickbox" title="Edit Product">Edit Product</a>';

	 echo '<div id="odst_edit_product_content" style="display:none">
		<div id="odst_edit_product_content_in">
			<input type="hidden" id="product_id"/>
			<input type="hidden" id="feed_id"/>
			<input type="hidden" id="product_ref"/>
            <input type="hidden" id="product_image_hid"/>
            
			<label>Product Name</label>
			<input type="text" id="product_name"/>
			<div class="clear"></div>
			
			<label>Brand Name</label>
			<input type="text" id="product_brand"/>
			<div class="clear"></div>
			
			<label>Description</label>
			<textarea id="description"></textarea>
			<div class="clear"></div>
			
			<label>Image</label>
			<img src="" id="product_image"></img>			
			<input id="upload_image_button" type="button" value="Change Image" onclick="show_image_window()"/>

			<div class="clear"></div>
			
			<input type="button" class="button" onclick="update_odst_product();" value="Save Changes"/>
			
			<div id="lnk_tabs"><div>
			
			</div>
			
			
		</div>
					   

					   <div id="odst_add_product_content" style="display:none">
							<div id="product_search">
								<div id="search_form">
									<label for="search_product_name">Product Name</label><input type="text" id="search_product_name"/>
									<label for="search_product_category">Category</label>
									<select name="search_product[product_category]" id="search_product_category">
																<optgroup label="Categories">
																' .  PriceMatcherLoader::get_categories_ddl() 
																  .  '</optgroup><optgroup label="Merchant Categories">'
																  .  PriceMatcherLoader::get_merchant_categories_ddl() 							
															.'</optgroup></select>	
									<div class="actions">
										<input type="button" class="button" onclick="odst_search_products(jQuery(\'#product_search\'));" value="Search"/>
									</div>							
								</div>		   

								<div id="product_search_results">
									<ul id="odst_products"></ul>
								</div>	
							</div>
						</div>';				
	//}
 }
 
 	function update_product_action_javascript()
	{
	?>
	<script type="text/javascript" >
	var old_send_to_editor;
	var old_tb_remove;
	
	function my_tb_remove()
	{
		jQuery("#TB_window #TB_title").first().show();
	    jQuery("#TB_window #TB_ajaxContent").first().show();
	
		jQuery("#TB_window #TB_title").last().hide();
		jQuery("#TB_window #TB_iframeContent").last().hide();
	
		jQuery("#TB_imageOff").unbind("click");
    	jQuery("#TB_closeWindowButton").unbind("click");
    	jQuery("#TB_overlay").unbind("click");
		jQuery("#TB_closeAjaxWindow").unbind("click");
		
		jQuery("#TB_overlay").click(tb_remove);
		jQuery("#TB_closeWindowButton").click(tb_remove);
		jQuery("#TB_imageOff").click(tb_remove);
	}
	
	function show_image_window()
	{
	
	jQuery("#TB_window #TB_title").first().hide();
	jQuery("#TB_window #TB_ajaxContent").first().hide();
				
			
		window.send_to_editor = function(html) {
			 var imgurl = jQuery('img',html).attr('src');
			 var img = odst_content_tools_settings.tim_thumb + encodeURI(imgurl) + '&w=80'
			 jQuery('#odst_edit_product_content_in #product_image').attr('src', img);
			 jQuery('#odst_edit_product_content_in #product_image_hid').val(imgurl);
			 my_tb_remove();
			}	

		formfield = jQuery('#upload_image').attr('name');
		tb_show('Change Image', 'media-upload.php?type=image&amp;TB_iframe=true');
		
	
		jQuery("#TB_imageOff").unbind("click");
    	jQuery("#TB_closeWindowButton").unbind("click");
    	jQuery("#TB_overlay").unbind("click");
		jQuery("#TB_closeAjaxx").unbind("click");
		
		jQuery("#TB_overlay").click(my_tb_remove);
		jQuery("#TB_closeWindowButton").last().click(my_tb_remove);	
		jQuery("#TB_imageOff").click(my_tb_remove);
		//jQuery("#TB_closeAjaxWindow").click(my_tb_remove);
		
	}
	
	function get_product_group_and_categories(selectId){
			var data = {
			action: 'my_action',
			my_action: 'get_product_group_and_categories',			
		};
		
		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(response) {							
						s = jQuery(selectId);
						s.html(response);
						
		});
	}
	
	function update_odst_product(){
		
			var product_id = jQuery("#TB_ajaxContent #product_id").val();
			var feed_id = jQuery("#TB_ajaxContent #feed_id").val();
			var new_name = jQuery("#TB_ajaxContent #product_name").val();
			var new_desc = jQuery("#TB_ajaxContent #description").val();
			var new_img = jQuery("#TB_ajaxContent #product_image_hid").val();
			var new_brand = jQuery("#TB_ajaxContent #product_brand").val();
			currentNameSpan = jQuery("#TB_ajaxContent #product_ref").val();
			
			alert(new_img);
			
			var data = {
			action: 'my_action',
			my_action: 'update_product',
			product_id: product_id,			
			product_name: new_name,
			description: new_desc,
			brand_name: new_brand,
			image: new_img						
		};
		
		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(response) {	
						alert(response);
						tb_remove();							
						if( currentNameSpan != '' )
							  jQuery(currentNameSpan + ' span.product_name').html(new_name);
							  jQuery(currentNameSpan + ' span.product_brand').html(new_brand);							  
							  jQuery(currentNameSpan + ' img.product_image').attr('src',odst_content_tools_settings.tim_thumb + encodeURI(new_img) + '&w=80');
							  
		});
	}
	
	function dump(arr,level) {
	var dumped_text = "";
	if(!level) level = 0;
	
	//The padding given at the beginning of the line.
	var level_padding = "";
	for(var j=0;j<level+1;j++) level_padding += "    ";
	
	if(typeof(arr) == 'object') { //Array/Hashes/Objects 
		for(var item in arr) {
			var value = arr[item];
			
			if(typeof(value) == 'object') { //If it is an array,
				dumped_text += level_padding + "'" + item + "' ...\n";
				dumped_text += dump(value,level+1);
			} else {
				dumped_text += level_padding + "'" + item + "' => \"" + value + "\"\n";
			}
		}
	} else { //Stings/Chars/Numbers etc.
		dumped_text = "===>"+arr+"<===("+typeof(arr)+")";
	}
	return dumped_text;
}
	function CopyUp(el,tabid)
	{
	v = jQuery("div#lnkd_" + tabid + " span." + el ).html();
	jQuery("#TB_ajaxContent #" + el).val(v);	
	}
	
	function UnLink(uid,feed_id,product_id,el,tabid)
	{
		var data = {
			action: 'my_action',
			my_action: 'unlink_product',
			uid: uid,
			feed_id: feed_id,
			product_id: product_id			
		};
		
		if(jQuery(".lnk_product_tabs ul li").length == 1 )
			{
			alert("You cannot unlink when there's is only one product!");
			return;
			}
			
		if( confirm("Are you sure you want to unlink this product?") )
			{
				jQuery.post(ajaxurl, data, function(response) {	
					
						jQuery(el).parent().remove();
						jQuery("div#lnkd_" + tabid).remove();
						jQuery("#odst_edit_product_content #lnk_tabs #the_tabs").tabs('option', 'selected', 0);
				});
		
			}
		
	}
	
	function CopyUpImage(tabid)
	{
	var image = jQuery("div#lnkd_" + tabid + " #lnk_" + tabid + "product_image_hid").val();
	var src = jQuery("div#lnkd_" + tabid + " img.product_image").attr('src');
	
	jQuery("#TB_ajaxContent #product_image").attr('src',src);
	jQuery("#TB_ajaxContent #product_image_hid").val(image);
	}

	function show_odst_product(product_id,productRef){
				
			var data = {
			action: 'my_action',
			my_action: 'get_product',
			product_id: product_id	
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(response) {	
		
						var name;
						var brand;
						var description;
						var image;
												
						name = response.product_name;											
						description = response.description;											
						image = response.image;
						brand = response.BrandName;
																											
						jQuery("#odst_edit_product_content #product_id").val(response.uid);
						jQuery("#odst_edit_product_content #product_name").val(name);
						jQuery("#odst_edit_product_content #product_ref").val(productRef);
					
						jQuery("#odst_edit_product_content #product_brand").val(brand);
						jQuery("#odst_edit_product_content #product_image").attr('src',odst_content_tools_settings.tim_thumb + encodeURI(image) + '&w=80');
						jQuery("#odst_edit_product_content #product_image_hid").val(image);
						jQuery("#odst_edit_product_content #description").val(description);
						
						jQuery("#odst_edit_product_content #lnk_tabs #the_tabs").remove();
						jQuery("#odst_edit_product_content #lnk_tabs").append('<div id="the_tabs"></div>');
						var str = '<div class="lnk_product_tabs">';
						str += '<ul>';
						var str_tab = "";
						var str_div = "";
						var i =0;
						response.products.forEach(function(e)
							{
							i = i + 1;
							str_tab += '<li><a tabindex="3" href="#lnkd_' + i + '">'+ e.MerchantName + '</a><img onclick="UnLink(\'' + response.uid + '\',\'' + e.feed_id + '\',\'' + e.ProductID + '\',this,\'' + i + '\')" class="copy" src="' + odst_content_tools_settings.plugins_url + 'images/unlink.jpg"/></li>';
							str_div += '<div id="lnkd_' + i + '">';
							
							str_div += '<div class="img"><input type="hidden" id="lnk_' + i + 'product_image_hid" value="' + e.ImageURL + '"/><img class="product_image" src="' + odst_content_tools_settings.tim_thumb + encodeURI(e.ImageURL) + '&w=80"/><img onclick="CopyUpImage(\'' + i + '\')" class="copy" src="' + odst_content_tools_settings.plugins_url + 'images/copy-up.jpg"/></div>';							
							str_div += '<div class="name"><a target="_blank" href="' + e.AffiliateURL + '"><span class="product_name">' + e.ProductName + '</span></a><img onclick="CopyUp(\'product_name\',\'' + i + '\')" class="copy" src="' + odst_content_tools_settings.plugins_url + 'images/copy-up.jpg"/></div>';
							str_div += '<div class="price">' + e.ProductPrice + '</div>';
							str_div += '<div class="brand"><span class="product_brand">' + e.BrandName + '</span><img onclick="CopyUp(\'product_brand\',\'' + i + '\')" class="copy" src="' + odst_content_tools_settings.plugins_url + 'images/copy-up.jpg"/></div>';
							str_div += '<div class="desc"><span class="description">' + e.ProductDescription + '</span><img onclick="CopyUp(\'description\',\'' + i + '\')" class="copy" src="' + odst_content_tools_settings.plugins_url + 'images/copy-up.jpg"/></div>';
							str_div += '</div>';
							});
							
						str += str_tab;
						str += '</ul>';
						str += str_div;
						str += '</div>';						
						
						jQuery("#odst_edit_product_content #lnk_tabs #the_tabs").html(str);
						jQuery("#odst_edit_product_content #lnk_tabs #the_tabs").tabs();
						
						// retreive data and show popup
						tb_show('Edit Product', '#TB_inline?height=530&width=546&inlineId=odst_edit_product_content', null);						
		},"json");
	}
	
		function showShortCode(product_id,productRef)
		{
		jQuery("#odst_shortcode").html('[odst_content_unit type="product" productid="P_' + product_id + '" cheapestonly="false" display="directory"]');
		
		tb_show('Get Shortcode', '#TB_inline?height=330&width=500&inlineId=odst_shortcode_content', null);						
		}		
		
		function odst_search_products(search_div){
			
			
			var product_name = search_div.find("#search_product_name").val();
			var category = '';
			var product_group = '';
			
			if( jQuery("option:selected",search_div.find("#search_product_category")).parent().attr('label') == "Product Groups")
				{
				product_group = search_div.find("#search_product_category").val();					
				}
			else
				{
				category = search_div.find("#search_product_category").val();					
				}
				
								
			var data = {
			action: 'my_action',
			my_action: 'search_product',
			product_name: product_name,
			category: category,
			product_group: product_group
		};
	
		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(json) {	
				var products_ul = search_div.find("ul");					
						 products_ul.empty();
						if( json.length == 0)					
											{
											 products_ul.append('<li>No products found</li>');
											}
					
						 jQuery(json).each(function() {
						 products_ul.append('<li><span class="product_name">' + this.ProductName + '</span><div class="image"><img src="' + odst_content_tools_settings.tim_thumb + encodeURI(this.ImageURL) + '?w=80"/></div><div class="description" title="' + this.ProductDescription + '">' + this.ProductDescription.substring(0,30) + '</div><div class="merchant">' + this.MerchantName + '</div><div class="price">&pound;' + this.ProductPrice + '&nbsp;<a href="#" onclick="wpODSTModuleContentUnitScriptsObj.addPriceCode(\'' + this.ProductID + '\',' + this.feed_id + ');return false;">Insert price code</a></div><div class="actions" style="margin-top:10px">' +
								 '<a href="#" onclick="wpODSTModuleContentUnitScriptsObj.addImage(\'' + this.ImageURL + '\');return false;">Insert image</a> | ' +
								 '<a href="#" onclick="wpODSTModuleContentUnitScriptsObj.addAsProduct(\'' + this.ProductName + '\',\'' + this.ImageURL + + '\',\'' + this.ProductDescription + '\',\'' + this.AffiliateURL + '\',\'' + this.MerchantName + '\',\'' + this.ProductID + '\',' + this.feed_id + ');parent.tb_remove();return false;">Add as product</a> | ' + 
								 '<a href="#" onclick="wpODSTModuleContentUnitScriptsObj.addAsPost(document,\'' + this.ProductName + '\',\'' + this.ImageURL + '\',\'' + this.ProductDescription + '\',\'' + this.AffiliateURL + '\',\'' + this.MerchantName + '\',\'' + this.ProductID + '\',' + this.feed_id + ');parent.tb_remove();return false">Add as post</a></div></li>');						
				});
						
		},"json");
	}
	</script>
	<?php
	}

function wp_ajax_my_action_callback()
	{	
		
		switch($_POST['my_action']) {
				case "update_product":
					$this->update_odst_product_callback($_POST['product_id']);
					break;
										
				case "get_product":					
					$this->get_product_callback($_POST['product_id']);
					break;
								
				case "search_product":						
					$this->search_product_callback($_POST['product_name'], $_POST['brand_name'], $_POST['price_from'], $_POST['price_to'], $_POST['category'], $_POST['product_group'],$_POST['merchant'],$_POST['merchant_category'],$_POST['unmapped_only'], $_POST['deleted'] );					
					break;
				case "create_product_group":
					$this->create_product_group_callback($_POST['product_group']);
					break;
				case "add_product_to_product_group":
					$this->add_products_to_product_group_callback($_POST['products'],$_POST['product_group']);
					break;
				case "add_product_to_category":
					$this->add_products_to_category_callback($_POST['products'],$_POST['category']);
					break;
				case "link_products":
					$this->link_products_callback($_POST['products']);
					break;
				case "unlink_product":
					$this->unlink_product_callback($_POST['uid'],$_POST['feed_id'],$_POST['product_id']);
					break;
				case "refresh_categories":
					$this->refresh_categories_callback();
					break;
				case "remove_product_from_product_group":
					$this->remove_products_from_product_group_callback($_POST['products'],$_POST['product_group']);
					break;
				case "delete_products":
					$this->delete_products_callback($_POST['products']);
					break;
				case "undelete_products":
					$this->undelete_products_callback($_POST['products']);
					break;
				case "remove_product_from_category":
					$this->remove_products_from_category_callback($_POST['products'],$_POST['category']);
					break;
				case "get_product_group_and_categories":
					$this->get_product_group_and_categories_callback();
					break;
					
				}
	}
	
	function unlink_product_callback($uid,$feed_id,$product_id)
	{
		global $wpdb;
		
		$newuid = $wpdb->get_var($wpdb->prepare("SELECT MAX(uid)+1 FROM pm_master_products;"));
		
		$sql = "insert into pm_master_products(ProductName,ProductDescription,SummaryDescription,BrandName,RRP,ImageURL,SmallImageURL,LargeImageURL,uid) ";
			$sql .=  "SELECT ProductName,ProductDescription,SummaryDescription,BrandName,RRP,ImageURL,SmallImageURL,LargeImageURL," . $newuid . " as uid from pm_products where feed_id=" . $feed_id . " and ProductID='" . $product_id ."'";
		
						
		$wpdb->query($sql);
		$sql =  "UPDATE pm_product_ids set uid=" . $newuid . " where feed_id=" . $feed_id . " and ProductID='" . $product_id ."'";
		$wpdb->query($sql);
		
		$sql =  "UPDATE pm_products set uid=" . $newuid . " where feed_id=" . $feed_id . " and ProductID='" . $product_id ."'";
		$wpdb->query($sql);
		
		
		die();
	}
	
	function get_product_group_and_categories_callback()
	{
	echo('<optgroup label="Categories">
			' .  PriceMatcherLoader::get_categories_ddl() 
			  .  '</optgroup><optgroup label="Merchant Categories">'
			  .  PriceMatcherLoader::get_merchant_categories_ddl() 							
		.'</optgroup>');
	die();
	}

	function link_products_callback($products)
	{
	
		global $wpdb;		
		$i = 0;
		$newID = 0;
		$s = "";
		
		$s = $products.length;
		foreach( $products as $product)
			{			
			$i += 1;			
			$s .= " " . $i . " ";
			$parts = explode("_", $product);
			if( $parts )
				{		
				//$feed_id = $parts[1]; // format is P_PRODUCT_ID
				$product_id = $parts[1];
				
				// keep the first
				if( $i == 1)
					{
					$newID = $product_id;
					}
				else
					{
					// TODO MERGE THE DATA 
					
					$sql = "update pm_product_ids set uid=" . $newID . " where uid=" . $product_id;
					$wpdb->query($sql);
					
					
					$sql = "delete from pm_master_products where uid=" . $product_id;
					$wpdb->query($sql);
					
					
					}
				}
				
			
		}
		echo("The products have been linked");
		die();
	}
	
	function add_products_to_category_callback($products,$category)
	{
	
		global $wpdb;
		foreach( $products as $product)
			{			
			$parts = explode("_", $product);
			if( $parts )
				{		
				//$feed_id = $parts[1]; // format is P_PRODUCT_ID
				$product_id = $parts[1];
				$sql = "INSERT INTO pm_products_terms_lnk(uid,term_id) VALUES(" . $product_id . "," . str_replace("'","''",$category) . ")";
				}
				
			$wpdb->query($sql);
		}
		//echo($sql);
		die();
	}
	
	function remove_products_from_category_callback($products,$category)
	{
	
		global $wpdb;
		foreach( $products as $product)
			{			
			$parts = explode("_", $product);
			if( $parts )
				{		
				$product_id = $parts[1];
				$sql = "DELETE FROM pm_products_terms_lnk WHERE uid=" . $product_id. " AND term_id=" . str_replace("'","''",$category);
				}
				
			$wpdb->query($sql);
		}
		//echo($sql);
		die();
	}
	
	function refresh_categories_callback()
	{
	
		$walker = new Product_Category_Walker();
		$categories = wp_list_categories(array('hide_empty' => 0, 'taxonomy' => 'odst_products', 'echo' => 0, 'walker' => $walker));
		
		echo($categories);
		die();
		
	}
	
	function add_products_to_product_group_callback($products,$product_group_id)
	{
	
		global $wpdb;
		
		foreach( $products as $product)
			{
			$parts = explode('_', $product);
			if( $parts )
				{
				$feed_id = $parts[1]; // format is P_2_PRODUCT_ID
				$product_id = substr($product,strrpos($product, "_",2)+1);
				$sql = "INSERT INTO pm_custom_product_group_products(productID,feed_id,product_group_id) VALUES('" . str_replace("'","''",$product_id) . "'," . str_replace("'","''",$feed_id) . "," . $product_group_id . ")";
				$wpdb->query($sql);
				}
			}
		//echo($sql);
		die();
	}
	
	function remove_products_from_product_group_callback($products,$product_group_id)
	{
	
		global $wpdb;
		
		foreach( $products as $product)
			{
			$parts = explode('_', $product);
			if( $parts )
				{
				$feed_id = $parts[1]; // format is P_2_PRODUCT_ID
				$product_id = substr($product,strrpos($product, "_",2)+1);
				$sql = "DELETE FROM pm_custom_product_group_products WHERE productID='" . str_replace("'","''",$product_id) . "' AND feed_id=" . str_replace("'","''",$feed_id) . " AND product_group_id=" . $product_group_id ;
				$wpdb->query($sql);
				}
			}
		//echo($sql);
		die();
	}
	
	function delete_products_callback($products)
	{
	
		global $wpdb;
		
		foreach( $products as $product)
			{
			$parts = explode('_', $product);
			if( $parts )
				{
				$feed_id = $parts[1]; // format is P_2_PRODUCT_ID
				$product_id = substr($product,strrpos($product, "_",2)+1);
				$sql = "UPDATE pm_products SET deleted=true WHERE productID='" . str_replace("'","''",$product_id) . "' AND feed_id=" . str_replace("'","''",$feed_id);
				$wpdb->query($sql);
				}
			}
		die();
	}
	
	function undelete_products_callback($products)
	{
	
		global $wpdb;
		
		foreach( $products as $product)
			{
			$parts = explode('_', $product);
			if( $parts )
				{
				$feed_id = $parts[1]; // format is P_2_PRODUCT_ID
				$product_id = substr($product,strrpos($product, "_",2)+1);
				$sql = "UPDATE pm_products SET deleted=false WHERE productID='" . str_replace("'","''",$product_id) . "' AND feed_id=" . str_replace("'","''",$feed_id);
				$wpdb->query($sql);
				}
			}
		die();
	}
	
	
	function create_product_group_callback($product_group)
	{
		global $wpdb;
		$sql = "INSERT INTO pm_custom_product_groups(name) VALUES('" . $product_group . "')";
		$wpdb->query($sql);
		
		$sql = "select id from pm_custom_product_groups where name='" . $product_group . "'";
		$results    = $wpdb->get_results($sql);
				
		echo(json_encode($results));

		die();		
	}
	
	function search_product_callback($name,$brand,$price_from,$price_to,$category,$product_group, $merchant, $merchant_category, $unmapped_only, $deleted)
	{
		
		global $wpdb;
		$sql = "SELECT MP.feed_id, MP.ProductID, p.ProductName, p.BrandName, MP.ProductPrice, p.ImageURL, f.name as MerchantName, p.ProductDescription, p.uid FROM pm_master_products p  ";
		$sql .= " inner join pm_product_ids ID on ID.uid= p.uid inner join pm_products MP on MP.feed_id=ID.feed_id and MP.ProductID=ID.ProductID inner join pm_feeds f on f.id=MP.feed_id ";
		
						
		if( $category != '' )
			{
			$unmapped_only = 'false';
			}
						
			
		if( $category != '' )
			{
			$sql .= " INNER JOIN pm_products_terms_lnk t on t.uid=p.uid ";
			}
		else
			{ // if searching by category then can only show mapped products
			if( $unmapped_only == 'true' ) 
				{
				$sql .= " LEFT OUTER JOIN pm_products_terms_lnk t on t.uid=p.uid ";			
				}				
			}
		
			
		$sql .= " WHERE 1=1 ";
		
		if( $name != '' )
			{
				$sql .= " AND p.ProductName like('%" . $name . "%')";
			}
		
		if( $brand != '' )
			{
				$sql .= " AND ( p.BrandName like('%" . $brand . "%') or MP.BrandName like('%" . $brand . "%') )";
			}
		
		if( is_numeric($price_from) )
			{
				$sql .= " AND MP.ProductPrice >= " . $price_from ;
			}
		
		if( is_numeric($price_to) )
			{
				$sql .= " AND MP.ProductPrice <= " . $price_to ;
			}
		
		
		if( $category != '' )
			{
				$sql .= " AND t.term_id=" . $category;
			}
		else
			{
			if( $unmapped_only == 'true' ) 
				{
				$sql .= " AND t.term_id is null";
				}
			}
		
		if( $deleted == 'true' ) {
			$sql .= " AND p.deleted = true ";		
		}
		else{
			$sql .= " AND p.deleted = false ";
		}
						
		
		if( $merchant != '' )
			{
				$sql .= " AND f.name='" . $merchant . "'";
			}
					
		if( $merchant_category != '' )
			{
				$sql .= " AND p.uid in (select PID.uid from pm_product_ids PID inner join pm_products P2 ON P2.feed_id=PID.feed_id and P2.ProductID = PID.ProductID where P2.Category='" . $merchant_category . "')";
			}
		
		$products    = $wpdb->get_results($sql);
					   		
		echo(json_encode($products));
		
		die(); // this is required to return a proper result
		
	}
	
	function get_product_callback($product_id)
	{	   
		global $wpdb;
		$sql = 'SELECT uid, ProductName, ImageURL, BrandName, ProductDescription FROM pm_master_products WHERE uid=' . $product_id ;
		

		$products    = $wpdb->get_results($sql);
		
		$uid  = $products[0]->uid;
		$product_name = $products[0]->ProductName;
		$description = $products[0]->ProductDescription;
		$brand = $products[0]->BrandName;
		$image = $products[0]->ImageURL;

		
		$sql = 'SELECT P.feed_id, P.ProductID, f.name as MerchantName, ProductPrice, AffiliateURL, ImageURL, ProductDescription, ProductName, BrandName FROM pm_products P inner join pm_product_ids ID on ID.uid=P.uid
				inner join pm_feeds f on f.id=P.feed_id
				WHERE ID.uid=' . $product_id ;
								
		$products   = $wpdb->get_results($sql, ARRAY_A);
				
		$arr = array('uid' => $product_id, 'image' => $image, 'product_name' => $product_name, 'BrandName' => $brand, 'feed_id' => $feed_id, 'url' => $url, 'description' => $description, 'products' => $products);
		
		// get linked products
			
		echo(json_encode($arr));
		
		die(); // this is required to return a proper result
		
	}
	
	function update_odst_product_callback($product_id) {

	global $wpdb; // this is how you get access to the database

	$description = $_POST['description'] ;
	$name = $_POST['product_name'] ;
	$brand = $_POST['brand_name'] ;
	$image = $_POST['image'] ;
	

	$sql = 'UPDATE pm_master_products set ';
	$sql .= sprintf("ProductDescription='%s',ProductName='%s',BrandName='%s', ImageURL='%s'", $description, $name, $brand, $image);
	$sql .= ' WHERE uid=' . $product_id ;
	
	
	$wpdb->query($sql);
	
	// update the product 
	
	if( true ) {
			 echo 'true';
		}	
	else{
			 echo 'false';
		}		   			 
	die(); // this is required to return a proper result
	}


	
 function main_settings() 
	{		
		$options = get_option('pm_options');
		$output = '<h3>Default Style</h3>';

		$output .= '<input type="text" class="color-picker" name="options[background_colour]" value="'.$options['background_colour'].'" />Background Colour';
		$output .= '<br />';
		$output .= '<input type="text" class="color-picker" name="options[border_colour]" value="'.$options['border_colour'].'" />Border Colour';
		$output .= '<br />';
		$output .= '<input type="text" class="color-picker" name="options[product_name_bg_colour]" value="'.$options['product_name_bg_colour'].'" />Product Name Background Colour';
		$output .= '<br />';
		$output .= '<input type="text" class="color-picker" name="options[product_name_colour]" value="'.$options['product_name_colour'].'" />Product Name Colour';
		$output .= '<br />';
		$output .= '<input type="text" class="color-picker" name="options[price_colour]" value="'.$options['price_colour'].'" />Price Colour';
		$output .= '<br />';
		$output .= '<input type="text" class="color-picker" name="options[even_row_colour]" value="'.$options['even_row_colour'].'" />Even Row Colour';
		$output .= '<br />';
		$output .= '<input type="text" class="color-picker" name="options[odd_row_colour]" value="'.$options['odd_row_colour'].'" />Odd Row Colour';
		$output .= '<br />';

		print $output;
	
	}

 function odst_short_code( $atts ) {
 
		extract( shortcode_atts( array(
			'type' => '',
			'display' => '',
			'product_group' => '',
			'product_name' => '',
			'merchant' => '',
			'category' => '',
			'productid' => '0',
			'max' => '10',
			'price_from' => '',
			'price_to' => '',
			'style' => 'default',
			'width' => '',
			'cheapestonly' => ''
		), $atts ) );
				
		$content = $this->get_post_content($type,$display,$style,$width,$product_name,$category,$merchant,$price_from,$price_to,$productid,$max,$cheapestonly,plugins_url('',dirname(__FILE__)));
		
		return $content;

	}	

	 function format_price($price) { 

	// return with no change if string is shorter than $limit 



	if( number_format($price,0) == number_format($price,2) )

		{

			return $price;

		}

		

		return number_format($price,2);

	 

	 }
	 
	function count_products()
	{
	 global $wpdb;

	 $count = $wpdb->get_var("select count(*) from pm_products");

	 return $count;
	}
	

	function get_first_match($text, $words)

{

        /*** loop of the array of words ***/

        foreach ($words as $word)

        {

                /*** quote the text for regex ***/

                $word = preg_quote($word);

                /*** highlight the words ***/

                //$text = preg_replace("/\b($word)\b/i", '<span class="highlight_word">\1</span>', $text);

				if ( preg_match("/\b($word)\b/i", $text, $matches, PREG_OFFSET_CAPTURE) > 0 )

				{

				return $word;

				break;

				}

        }

        /*** return the text ***/

        return "";

}



	function get_region_from_context($content)

	{

		// find which region in the post content and return region

		$regions = get_option('odst_easyjet_regions');

		$match = $this->get_first_match($content, $regions);			

		

		if ( $match == "" )

		{

			return $regions[array_rand($regions)];

		}

		

		return $match;

				

	}

	function format_style($style)

	{

	if( $style == '')

		{

			return '';

		}

	return ' style="' . $style . '"';

	}

	

	function format_width($width)

	{

		if ($width == '' ) { return $width; }

		

		$width = strtolower($width);

		if( strpos($width,"px") || strpos($width,"%") ) { return $width ; }

		

		return $width . "px";		

	

	}

	

	function apply_style($stylesheet,$element)
	{
	$options = get_option('pm_options');	 
	$style = '';

			switch ( $stylesheet )	{
				case 'default':		
					if( $options[$element] != '' ){
						switch ( $element ){
							case 'background_colour':						
							$style='background-color:' . $options[$element] .';';
							break;
							
							case 'border_colour':
							$style='border-color:' . $options[$element] .';';
							break;
							
							case 'product_name_bg_colour':
							$style='background-color:' . $options[$element] .';';
							break;
							
							case 'product_name_colour':
							$style='color:' . $options[$element] .';';
							break;
							
							case 'price_colour':
							$style='color:' . $options[$element] .';';
							break;
											
							case 'even_row_colour':
							$style='background-color:' . $options[$element] .';';
							break;
						
							case 'odd_row_colour':
							$style='background-color:' . $options[$element] .';';
							break;
							}
						break;
					}
				}			
			return $style;
	}


	function get_post_content($type,$display,$style,$width,$product_name,$category,$merchant,$price_from,$price_to,$pid,$limit,$cheapestonly,$plugin)
	{		
	$style = "default";	
	
	$parts = explode("_", $pid);
	
	if( $parts )
		{		
		$productid = $parts[1]; // format is P_2_PRODUCT_ID
		}

		
	switch ($type) {
        case 'product':
			{
			if( $cheapestonly == "" ) { $cheapestonly = "false"; }
			$products = $this->search_products_by_id($productid,$cheapestonly);	
			
			$hotel = '<div ';				
					if( $width != '')
						{
						$hotel .= ' style="width:' . $this->format_width($width) . '"';
						}						

					$hotel .= ' class="odst_hotel_table odst_hotels odst_reset odst_content_unit_table';

					if( $style != 'default' and $style != "")
					{
					$hotel .= ' ' . strtolower($style);
					}
				
					$hotel .= '"><!--div class="odst_hol_logo"></div-->';					

					$i = 1;

					if(count($products) > 0) {
						foreach ($products as $product) {		

						$hotel = $hotel . '<div class="row short ';

						if ( $i%2 == false ) { $hotel = $hotel. ' even'; }

						$hotel = $hotel . '"';
						
						if ( $i%2 == false ) {	$hotel .= $this->format_style($this->apply_style($style,'odd_row_colour')); }

								else { $hotel .= $this->format_style($this->apply_style($style,'even_row_colour')); } 
							
						$hotel .= '>';

						//$hotel .= '<div class="photo"><a target="_blank" rel="nofollow" href="' . $product->AffiliateURL . '"><img class="photo" src="' . $plugin . '/timthumb.php?src=' . $product->ImageURL . '&w=80"/></a></div>';

						$hotel .= '<div class="name"><a ' . $this->format_style($this->apply_style($style,'product_name_colour') . $this->apply_style($style,'product_name_bg_colour')) . ' class="name" target="_blank" rel="nofollow" href="' . $product->AffiliateURL . '">' . $product->ProductName . '</a>';			
						$hotel .= '</div>';

						$hotel .= '<div class="location" ' . $this->format_style($this->apply_style($style,'location_colour')) . '>' . $product->MerchantName . '</div>';	

					
						$hotel .= '<div class="price"><a ' . $this->format_style($this->apply_style($style,'price_colour')) . ' target="_blank" rel="nofollow" href="' . $product->AffiliateURL . '">&pound;' . $this->format_price($product->ProductPrice) . '</a>';
						$hotel .= '</div>';
						$hotel .= '</div>';
										
						$i+=1;
						}
					}
					
					$hotel = $hotel . '</div>';
					return $hotel;
					
			break;
			}
		case 'products':{
		 
			$limit = intval($limit);

			if ($limit==0) 
				{
				$limit=10;
				}
			
			if( $cheapestonly == "" ) 
				{
				if( $display == "carousel" ) 
					{
					$cheapestonly = "true";
					}
				else
					{
					$cheapestonly = "false";
					}
				}
			
			if( $category <> "" && $merchant <> "" )
				{
				$products = $this->search_products_by_merchant_category($merchant,$category,$price_from,$price_to,$cheapestonly,$limit,1);	
				}
			elseif( $category <> "" && $merchant == "" )
				{
				$products = $this->search_products_by_category($category,$price_from,$price_to,$cheapestonly,$limit,1);	
				}
			
				
			if ( $display == 'directory' ){
					$hotel = '<div ';				
					if( $width != '')
						{
						$hotel .= ' style="width:' . $this->format_width($width) . '"';
						}						

					$hotel .= ' class="odst_hotel_table odst_hotels odst_reset odst_content_unit_table';

					if( $style != 'default' and $style != "")
					{
					$hotel .= ' ' . strtolower($style);
					}
				
					$hotel .= '"><!--div class="odst_hol_logo"></div-->';					

					$i = 1;
					$lastproduct = "";
					if(count($products) > 0) {
						foreach ($products as $product) {		
						if( ($cheapestonly == "true" &&  $product->uid != $lastproduct) || ($cheapestonly == "false") )
							{
							$lastproduct = $product->uid;
							$hotel = $hotel . '<div class="row ';

							if ( $i%2 == false ) { $hotel = $hotel. ' even'; }

							$hotel = $hotel . '"';
							
							if ( $i%2 == false ) {	$hotel .= $this->format_style($this->apply_style($style,'odd_row_colour')); }

									else { $hotel .= $this->format_style($this->apply_style($style,'even_row_colour')); } 
								
							$hotel .= '>';

							$hotel .= '<div class="photo"><a target="_blank" rel="nofollow" href="' . $product->AffiliateURL . '"><img class="photo" src="' . $plugin . '/timthumb.php?src=' . $product->ImageURL . '&w=80"/></a></div>';

							$hotel .= '<div class="name"><a ' . $this->format_style($this->apply_style($style,'product_name_colour') . $this->apply_style($style,'product_name_bg_colour')) . ' class="name" target="_blank" rel="nofollow" href="' . $product->AffiliateURL . '">' . $product->ProductName . '</a>';			
							$hotel .= '</div>';

							$hotel .= '<div class="location" ' . $this->format_style($this->apply_style($style,'location_colour')) . '>' . odst_truncate($product->ProductDescription,70) . '</div>';	

						
							$hotel .= '<div class="price"><a ' . $this->format_style($this->apply_style($style,'price_colour')) . ' target="_blank" rel="nofollow" href="' . $product->AffiliateURL . '">&pound;' . $this->format_price($product->ProductPrice) . '</a>';
							$hotel .= '<div class="clear"></div><div class="merchant">' . $product->MerchantName . '</div></div>';
							$hotel .= '</div>';
											
							$i+=1;
							}
						}
					}
					
					$hotel = $hotel . '</div>';

					return $hotel;				
				}
			elseif ( $display == "grid"){

				if( $width != '')
						{
						$widthstyle = 'width:' . $this->format_width($width) . ';';
						}
						
				$hotel = '<div ' . $this->format_style($widthstyle . $this->apply_style($style,'background_colour') . $this->apply_style($style,'border_colour'));
				
				$hotel .= ' class="container odst_hol_logo odst_reset ';

				if( $style != 'default' and $style != "")
					{
					$hotel .= ' ' . strtolower($style);
					}

				$hotel .= '"><div class="odst_scontainer content_units">';
						
				$hotel .= '<div class="grid" name="' . $country . '_' . $region . '_' . $resort . '">';

				$hotel .= '<ul class="slidingparts">';
				$lastproduct = "";
					if(count($products) > 0) {
						foreach ($products as $product) {
						if( ($cheapestonly == "true" &&  $product->uid != $lastproduct) || ($cheapestonly == "false") )
							{
							$lastproduct = $product->uid;
							$hotel .= '<li>';

							$hotel .='<table class="thumb_content">

				<tbody><tr>									

							<td class="thumb_heading">

							<a ' . $this->format_style($this->apply_style($style,'product_name_colour') . $this->apply_style($style,'product_name_bg_colour')) . ' target="_blank" rel="nofollow" class="name" href="' . $product->AffiliateURL . '">' . $product->ProductName . '</a>

							</td>
							</tr>							
								
								
							<tr>

							<td><a target="_blank" rel="nofollow" href="' . $product->AffiliateURL . '"><img class="thumb_image" src="' . $plugin . '/timthumb.php?src=' . $product->ImageURL . '&w=120"/></a>

							</td>

							</tr>
							<tr>

							<td class="merchant"><a target="_blank" rel="nofollow" href="' . $product->AffiliateURL . '">' . $product->MerchantName . '</a>

							</td>

							</tr>

									<tr><td class="thumb_price"' . $this->format_style($this->apply_style($style,'price_colour')) . '>

							&pound;' . $this->format_price($product->ProductPrice) .'

						</td></tr>								
						</tbody></table>';																		
							 }	
							 }
						 }
					$hotel .= '</ul></div></div><div class="odst_hol_logo_padding"></div></div>';

					return $hotel;
									
				}
			else{

				if( $width != '')
						{
						$widthstyle = 'width:' . $this->format_width($width) . ';';
						}
						
				$hotel = '<div ' . $this->format_style($widthstyle . $this->apply_style($style,'background_colour') . $this->apply_style($style,'border_colour'));
				
				$hotel .= ' class="container odst_hol_logo odst_reset ';

				if( $style != 'default' and $style != "")
					{
					$hotel .= ' ' . strtolower($style);
					}

				$hotel .= '"><div class="odst_scontainer content_units">';
						
				$hotel .= '<div class="slider" name="' . $country . '_' . $region . '_' . $resort . '">';

				$hotel .= '<ul class="slidingparts">';
				$lastproduct = "";
					if(count($products) > 0) {
						foreach ($products as $product) {
						if( ($cheapestonly == "true" &&  $product->uid != $lastproduct) || ($cheapestonly == "false") )
							{
							$lastproduct = $product->uid;
							$hotel .= '<li>';

							$hotel .='<table class="thumb_content">

				<tbody><tr>									

							<td class="thumb_heading">

							<a ' . $this->format_style($this->apply_style($style,'product_name_colour') . $this->apply_style($style,'product_name_bg_colour')) . ' target="_blank" rel="nofollow" class="name" href="' . $product->AffiliateURL . '">' . $product->ProductName . '</a>

							</td>
							</tr>							
								
								
							<tr>

							<td><a target="_blank" rel="nofollow" href="' . $product->AffiliateURL . '"><img class="thumb_image" src="' . $plugin . '/timthumb.php?src=' . $product->ImageURL . '&w=120"/></a>

							</td>

							</tr>
							<tr>

							<td class="merchant"><a target="_blank" rel="nofollow" href="' . $product->AffiliateURL . '">' . $product->MerchantName . '</a>

							</td>

							</tr>

									<tr><td class="thumb_price"' . $this->format_style($this->apply_style($style,'price_colour')) . '>

							&pound;' . $this->format_price($product->ProductPrice) .'

						</td></tr>								
						</tbody></table>';																		
							 }	
							 }
						 }
					$hotel .= '</ul></div></div><div class="odst_hol_logo_padding"></div></div>';

					return $hotel;
									
				}			
			
				break;			
			}
		
			case "price":{

					return $this->format_price(PriceMatcherLoader::get_product_price($productid,$feedid));
					
					break;
				}

				
    }
		
	}

	

	function get_widget_content($display,$width,$product_group,$category,$limit,$cheapest_only,$plugin)
	{	
		$limit = intval($limit);
		$style = "default";
		
		if ($limit==0) $limit=5;
					
		if( $product_group <> "" )
				{
				$products = $this->search_products_by_product_group($product_group,$cheapest_only,$limit,1);	
				}
			else
				{
				$products = $this->search_products_by_category($category,$cheapest_only,$limit,1);	
				}
									
		if( $display == 'directory' ) {
		
			if( $width != '')
				{
				$widthstyle = 'width:' . $this->format_width($width) . ';';
				}
				
			$hotel = '<div ' . $this->format_style($widthstyle . $this->apply_style($style,'border_colour') . $this->apply_style($style,'background_colour'));		
			$hotel .= ' class="odst_hotels vertical odst_reset ';

			if( $style != 'default' and $style != "")
					{
					$hotel .= ' ' . strtolower($style);
					}				
			$hotel .= '">';

			$hotel .= '<!--div class="odst_hol_logo"></div-->';
				
			if(count($products) > 0) {
						foreach ($products as $product) {
						$hotel .= '<div class="name"><a ' . $this->format_style($this->apply_style($style,'product_name_colour') . $this->apply_style($style,'product_name_bg_colour')) . ' class="name" target="_blank" rel="nofollow" href="' .$product->AfiliateURL . '">' . $product->ProductName . '</a></div>';
						$hotel .= '<div class="photo"><a target="_blank" rel="nofollow" href="' . $product->AffiliateURL . '"><img class="thumb_image" src="' . $plugin . '/timthumb.php?src=' . $product->ImageURL . '&w=80"/></a></div>';																				
						$hotel .= '<div class="price" ' . $this->format_style($this->apply_style($style,'price_colour')) . '>from &pound;' . $this->format_price($product->ProductPrice) . '</div>';
						} 
					}			
			$hotel = $hotel . '</div>';					
			return $hotel;				
			}
			else {		
			$hotel = '<div ';			
			if( $width != '')
				{
				$hotel .= ' style="width:' . $this->format_width($width) . '"';
				}							
			$hotel .= ' class="odst_reset ';
				if( $style != 'default' and $style != "")
					{
					$hotel .= ' ' . strtolower($style);
					}
				$hotel .= '"><div class="odst_scontainer vertical odst_hol_logo" ' . $this->format_style($this->apply_style($style,'background_colour') . $this->apply_style($style,'border_colour')) . '>';
				$hotel .= '<div class="slider vertical">';			
			$hotel .= '<ul  class="slidingparts">';
			if(count($products) > 0) {
						foreach ($products as $product) {
			$hotel .= '<li>';
						$hotel .='<table width="130" class="thumb_content">
						<tbody><tr>									
						<td class="thumb_heading">
						<a ' . $this->format_style($this->apply_style($style,'product_name_colour') . $this->apply_style($style,'product_name_bg_colour')) . ' target="_blank" rel="nofollow" class="name" href="' .  $product->AfiliateURL . '">' . $product->ProductName . '</a>
						</td>
						</tr>					
						<tr>
						<td><a target="_blank" rel="nofollow" href="' . $product->AffiliateURL . '"><img class="thumb_image" src="' . $plugin . '/timthumb.php?src=' . $product->ImageURL . '&w=80"/></a>
						</td>
						</tr>
								<tr><td  class="merchant" ' . $this->format_style($this->apply_style($style,'merchant_colour')) . '>' . $product->MerchantName .'
					</td></tr>
						</tr>
								<tr><td  class="thumb_price" ' . $this->format_style($this->apply_style($style,'price_colour')) . '>from &pound;' . $this->format_price($product->ProductPrice) .'
					</td></tr>								
					</tbody></table></li>';
				} }
		
			$hotel .= '</ul></div></div></div>';					
			return $hotel;
			}
	}
		
	function search_products($name,$limit='',$page=1)
	{
		global $wpdb;
		$sql = "SELECT p.id, p.ProductName, p.ProductDescription, p.ProductPrice, p.feed_id, p.ProductID, p.ImageURL, p.AffiliateURL
					FROM pm_products p
					WHERE p.ProductName LIKE '%".$name."%' OR p.ProductID LIKE '%".$name."%'";			

		$products = $wpdb->get_results($sql);
		
		return $products;

	}
	
	function search_products_by_product_group($product_group,$cheapest_only,$limit='',$page=1)
	{
		// if cheapest only then group by product name, showing the cheapest only
		
		global $wpdb;
		$sql = "SELECT p.id, IFNULL(cd.ProductName,p.ProductName) as ProductName, f.name as MerchantName, IFNULL(cd.description,p.ProductDescription) as ProductDescription, p.ProductPrice, p.feed_id, p.ProductID, p.ImageURL, p.AffiliateURL
				FROM pm_products p
					INNER JOIN pm_custom_product_group_products cpgp ON cpgp.ProductID = p.ProductID AND cpgp.feed_id = p.feed_id
					LEFT OUTER JOIN pm_custom_descriptions cd on cd.ProductID=p.ProductID AND cd.feed_id=p.feed_id
					INNER JOIN pm_feeds f on f.id=p.feed_id
					WHERE cpgp.product_group_id=" . $product_group;	      				

		if( $cheapest_only == 'true' )
			{
				$sql = "SELECT p.id, IFNULL(cd.ProductName,p.ProductName) as ProductName, f.name as MerchantName, IFNULL(cd.description,p.ProductDescription) as ProductDescription, p.ProductPrice, p.feed_id, p.ProductID, p.ImageURL, p.AffiliateURL
						FROM pm_products p
						INNER JOIN pm_feeds f ON f.id = p.feed_id
						LEFT OUTER JOIN pm_custom_descriptions cd on cd.ProductID=p.ProductID AND cd.feed_id=p.feed_id
						WHERE p.id
						IN (

						SELECT min( p2.id )
						FROM pm_products p2
						INNER JOIN (

						SELECT IFNULL(cd.ProductName,p3.ProductName) as ProductName, Min( p3.ProductPrice ) AS MinPrice
						FROM pm_products p3
						LEFT OUTER JOIN pm_custom_descriptions cd on cd.ProductID=p3.ProductID AND cd.feed_id=p3.feed_id
						INNER JOIN pm_custom_product_group_products cpgp ON cpgp.ProductID = p3.ProductID
						AND cpgp.feed_id = p3.feed_id
						WHERE cpgp.product_group_id = " . $product_group . "
						GROUP BY p3.ProductName
						) AS X ON X.ProductName = p2.ProductName
						AND X.MinPrice = p2.ProductPrice
						GROUP BY p2.ProductName
						)";	
			}
			
		$products = $wpdb->get_results($sql);
		
		return $products;
	}
	
	function search_products_by_product_name($product_name,$cheapest_only,$limit='',$page=1)
	{
		// if cheapest only then group by product name, showing the cheapest only
		
		global $wpdb;
		$sql = "SELECT p.id, IFNULL(cd.ProductName,p.ProductName) as ProductName, f.name as MerchantName, IFNULL(cd.description,p.ProductDescription) as ProductDescription, p.ProductPrice, p.feed_id, p.ProductID, p.ImageURL, p.AffiliateURL
				FROM pm_products p
					LEFT OUTER JOIN pm_custom_descriptions cd on cd.ProductID=p.ProductID AND cd.feed_id=p.feed_id
					INNER JOIN pm_feeds f on f.id=p.feed_id
					WHERE p.ProductName='" . $product_name . "' OR cd.ProductName = '" . $product_name . "'";

		if( $cheapest_only == 'true' )
			{
				$sql = "SELECT p.id, IFNULL(cd.ProductName,p.ProductName) as ProductName, f.name as MerchantName, IFNULL(cd.description,p.ProductDescription) as ProductDescription, p.ProductPrice, p.feed_id, p.ProductID, p.ImageURL, p.AffiliateURL
						FROM pm_products p
						INNER JOIN pm_feeds f ON f.id = p.feed_id
						LEFT OUTER JOIN pm_custom_descriptions cd on cd.ProductID=p.ProductID AND cd.feed_id=p.feed_id
						WHERE p.id
						IN (

						SELECT min( p2.id )
						FROM pm_products p2
						INNER JOIN (

						SELECT IFNULL(cd.ProductName,p3.ProductName) as ProductName, Min( p3.ProductPrice ) AS MinPrice
						FROM pm_products p3
						LEFT OUTER JOIN pm_custom_descriptions cd on cd.ProductID=p3.ProductID AND cd.feed_id=p3.feed_id
						WHERE  p3.ProductName='" . $product_name . "' OR cd.ProductName = '" . $product_name . "'
						GROUP BY p3.ProductName
						) AS X ON X.ProductName = p2.ProductName
						AND X.MinPrice = p2.ProductPrice
						GROUP BY p2.ProductName
						
						
						)";	
			}
			
		$products = $wpdb->get_results($sql);
		
		return $products;
	}


	function search_products_by_id($productid,$cheapestonly)
	{
		
		global $wpdb;
		$sql = "Select M.*,P.ProductPrice, P.AffiliateURL,f.name as MerchantName From 
		pm_master_products M
			inner join pm_product_ids I on I.uid=M.uid
			inner join pm_products P on P.feed_id=I.feed_id and P.ProductId=I.ProductID
			inner join pm_feeds f on f.id=I.feed_id
			where M.uid =" . $productid . "
			ORDER BY P.ProductPrice ASC ";
			if( $cheapestonly == 'true' )
				{
				$sql .= " LIMIT 0,1";
				}
									
		$products = $wpdb->get_results($sql);
		
		return $products;
	}

	function search_products_by_merchant_category($merchant,$category,$price_from,$price_to,$cheapestonly,$limit='',$page=1)
	{
		global $wpdb;

		$sql = "select X.*,P.ProductPrice,P.AffiliateURL,f.name as MerchantName From (
			SELECT PM.uid, min( ProductPrice ) AS minPrice, PM.ImageURL, PM.ProductName, PM.ProductDescription, PM.BrandName
			FROM pm_master_products PM
			INNER JOIN pm_product_ids I ON I.uid = PM.uid
			INNER JOIN pm_products P ON P.uid = I.uid
			INNER JOIN pm_feeds f on f.id=P.feed_id 			
			WHERE P.Category ='" . $category . "'  AND PM.deleted=0
			AND f.name = '" . $merchant . "'" ;
			
			if( $price_from != "" AND is_numeric($price_from) )
				{
				$sql .= " AND P.ProductPrice >= " . $price_from;
				}
				
			if( $price_to != "" AND is_numeric($price_to) )
				{
				$sql .= " AND P.ProductPrice <= " . $price_to;
				}
				
			$sql .= " GROUP BY PM.uid
			LIMIT 0," . $limit . "
			) as X
			inner join pm_product_ids I on I.uid=X.uid
			inner join pm_feeds f on f.id=I.feed_id
			inner join pm_products P on P.uid=I.uid 
			WHERE 1=1 ";
								
			if( $price_from != "" AND is_numeric($price_from) )
				{
				$sql .= " AND P.ProductPrice >= " . $price_from;
				}
				
			if( $price_to != "" AND is_numeric($price_to) )
				{
				$sql .= " AND P.ProductPrice <= " . $price_to;
				}
				
			$sql .= " ORDER By minPrice ASC, X.uid";
			
		$products = $wpdb->get_results($sql);
		
		return $products;
	}
	
	function search_products_by_category($category,$price_from,$price_to,$cheapestonly,$limit='',$page=1)
	{
		if ( $limit == "") { $limit=25; }
		
		global $wpdb;
		$sql = "select X.*,P.ProductPrice,P.AffiliateURL,f.name as MerchantName From (
			SELECT PM.uid, min( ProductPrice ) AS minPrice, PM.ImageURL, PM.ProductName, PM.ProductDescription, PM.BrandName
			FROM pm_master_products PM
			INNER JOIN pm_product_ids I ON I.uid = PM.uid
			INNER JOIN pm_products P ON P.uid = I.uid			
			INNER JOIN pm_products_terms_lnk t ON t.uid = PM.uid
			WHERE t.term_id =" . $category . " AND PM.deleted=0 ";
			
			if( $price_from != "" AND is_numeric($price_from) )
				{
				$sql .= " AND P.ProductPrice >= " . $price_from;
				}
				
			if( $price_to != "" AND is_numeric($price_to) )
				{
				$sql .= " AND P.ProductPrice <= " . $price_to;
				}
				
			$sql .= " GROUP BY PM.uid
			LIMIT 0," . $limit . "
			) as X
			inner join pm_product_ids I on I.uid=X.uid
			inner join pm_feeds f on f.id=I.feed_id
			inner join pm_products P on P.uid=I.uid 
			WHERE 1=1 ";
								
			if( $price_from != "" AND is_numeric($price_from) )
				{
				$sql .= " AND P.ProductPrice >= " . $price_from;
				}
				
			if( $price_to != "" AND is_numeric($price_to) )
				{
				$sql .= " AND P.ProductPrice <= " . $price_to;
				}
				
			$sql .= " ORDER By minPrice ASC, X.uid";
		$products = $wpdb->get_results($sql);
		
		return $products;
	}

	
	function get_hotel($propertyid)

	{

	    $request = new WP_Http;

		$url = $this->api_base . 'source=' . urlencode($this->source) . '&type=property&format=xml&propertyid=' . $propertyid . '&limit=1';

		$result = $request->request( $url );

		$contents = $result['body'];

		

		if (!$myxml=simplexml_load_string($contents))

		{

            return "Error reading the XML file";

        }

		

		return $myxml;

	}

	
	// META BOX
	
	function add_meta_boxes()
    {
	    wp_enqueue_script( 'odst_tabs', plugins_url( '/js/odst_tabs.js', dirname(__FILE__) ), array( 'jquery-ui-tabs' ) );

        add_meta_box( 
             'odst_contentunit_tools'
            ,__('ODST Content Unit Tools', 'odst_contentunit_tools')
            ,array(&$this, 'render_meta_box_content' )
            ,'post' 
            ,'side'
            ,'high'
        ); 

		 add_meta_box( 
             'odst_contentunit_tools'
            ,__('ODST Content Unit Tools', 'odst_contentunit_tools')
            ,array(&$this, 'render_meta_box_content' )
            ,'page' 
            ,'side'
            ,'high'
        ); 	
    }

	function render_meta_box_content() 
    {
	
		if( $this->count_products() == 0 )
			{
			echo('No products found, add product feeds first!');
			}

		else
			{
        echo '<div id="odst_content_units_meta"><div id="odst-tabs" class="categorydiv metabox odst-tabs">

				<ul class="category-tabs"> 
						<li class="tabs"><a href="#contentunits_mb" tabindex="3">Content Units</a></li> 
				</ul> 			

			<div class="tabs-panel odst_country_region" id="contentunits_mb">
				<label>Display:</label>
				<input id="wpODSTContentTools_format" type="hidden" name="wpODSTContentTools[format]"/>				
				<select name="wpODSTContentTools[display]" id="wpODSTContentTools_display">
							<option selected="selected" value="directory">Directory</option>
							<option value="grid">Grid</option>
							<option value="carousel">Carousel</option>
						</select><div class="clear"></div>				
				<label>Width:</label>
				<input id="wpODSTContentTools_width" type="text" style="" name="wpODSTContentTools[contentWidth]"/>
					
				<div class="clear"></div>				
				<label>Category:</label>				
				<select name="wpODSTContentTools[product_group]" id="wpODSTContentTools_product_group">
							<optgroup label="Categories">
																' .  PriceMatcherLoader::get_categories_ddl() 
																  .  '</optgroup><optgroup label="Merchant Categories">'
																  .  PriceMatcherLoader::get_merchant_categories_ddl(false) 							
															.'</optgroup></select>				
				<div class="clear"></div>				
				<label>Max Products:</label>
				<input id="wpODSTContentTools_maxproducts" type="text" value="10" style="" name="wpODSTContentTools[maxproducts]"/>
				<div class="clear"></div>				
				<label>Cheapest only:</label>
				<input id="wpODSTContentTools_cheapest" type="checkbox" value="yes" style="" name="wpODSTContentTools[cheapest]"/>
				
				<div class="clear"></div>				
				<label>Price filter:</label>
				from<input id="wpODSTContentTools_pricefrom" type="text" class="short" name="wpODSTContentTools[pricefrom]"/>
				to<input id="wpODSTContentTools_priceto" type="text" class="short" name="wpODSTContentTools[priceto]"/>
				
				<div class="clear"></div>				
					
				<div class="actions">
				<input type="button"  class="button" onclick="return wpODSTModuleContentUnitScriptsObj.insertContentUnit(jQuery(\'#odst_content_units_meta #contentunits_mb\'),\'\');" value="Insert content unit"/>
				</div>	
			</div>		
			
		</div></div>';
		}
    }
	
	function adminHead () {
		//if ($GLOBALS['editing']) {

		wp_enqueue_script('media-upload');
		wp_enqueue_script('thickbox');
		
			wp_enqueue_script('wpODSTContentToolsAdmin', plugins_url( 'js/odst_admin.js', dirname(__FILE__) ), array('jquery'), '1.0.0');
	
			wp_localize_script( 'wpODSTContentToolsAdmin', 'odst_content_tools_settings', array(
																	   'tim_thumb' => plugins_url( '/timthumb.php?src=', dirname(__FILE__) ),
																		'plugins_url' => plugins_url( '/', dirname(__FILE__) )
																	 ));
																	 
			wp_enqueue_script('wpODSTModuleContentUnitScripts', plugins_url( 'js/module_content_unit.js', dirname(__FILE__) ), array('jquery'), '1.0.0');

		
	   // }

	}

	function get_widget_contents($content = "", $display = "", $width = "", $product_group = "", $category = "", $max_products = "", $cheapest_only = "false")
	{	
		
		$content =  $this->get_widget_content($display,$width,$product_group,$category,$max_products,$cheapest_only,plugins_url('',dirname(__FILE__)));
		return $content;
	}
	
	
function odst_register_widgets()
	{			
	register_widget( 'ODST_Content_Unit' );	
	}
	

}



class ODST_Content_Unit extends WP_Widget {

function ODST_Content_Unit() {
	parent::WP_Widget(false, $name='ODST Product Feed Content Unit');
}

function widget($args, $instance) {
	extract( $args );

	$title = $instance['title'];
	echo $before_widget;

	if ( $title ) {
		echo $before_title . $title . $after_title; }
		$category = '';
		$product_group = '';
		
		$parts = explode("_",$instance['product_group']);
		if( $parts[0] = "C" )
			{
			$category = $parts[1];
			}
		else
			{
			$product_group = $parts[1];
			}
								
	$content = apply_filters('odst_widget_content','',$instance['display'],$instance['width'],$product_group,$category,$instance['max'],$instance['cheapest']);
		echo $content;
echo $after_widget;

}


function update($new_instance, $old_instance) {
	return $new_instance;
}


function form($instance) {

?><div id="contentunits" class="odst_country_region" >
				<label for="<?php echo $this->get_field_id("title"); ?>">
				<?php _e( 'Title' ); ?>:</label>
				<input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />			
				<label>Display:</label>
				<select id="<?php echo $this->get_field_id("display"); ?>" name="<?php echo $this->get_field_name("display"); ?>" >
							<option <?php selected( $instance["display"], "directory" ); ?> value="directory">Directory</option>
							<option <?php selected( $instance["display"], "grid" ); ?> value="grid">Grid</option>
							<option <?php selected( $instance["display"], "carousel" ); ?> value="carousel">Carousel</option>					
						</select>				
				<label>Width:</label>
				<input id="<?php echo $this->get_field_id("width"); ?>" value="<?php echo $instance["width"]; ?>" type="text" style="" name="<?php echo $this->get_field_name("width"); ?>"/>
						
				<label>Category/Group:</label>				
				<?
				$category = '';
				$merchant_category = '';
				
				if( isset($instance['merchant_category']))
				{
					$parts = explode("_",$instance['merchant_category']);
					if( $parts[0] = "C" )
						{
						$category = $parts[1];
						}
					else
						{
						$merchant_category = $parts[1];
						}
					}
					
				?>
				<select name="<?php echo $this->get_field_name("merchant_category"); ?>" id="<?php echo $this->get_field_id("merchant_category"); ?>">
							<optgroup label="Categories">
							<?php echo PriceMatcherLoader::get_categories_ddl('C_',$category);?> 
							</optgroup><optgroup label="Merchant Categories">
							<?php echo PriceMatcherLoader::get_merchant_categories_ddl('P_',$merchant_category);?>							
						.'</optgroup></select>								
				<label>Max Products:</label>				
				<input class="widefat" id="<?php echo $this->get_field_id("max"); ?>" name="<?php echo $this->get_field_name("max"); ?>" type="text" value="<?php echo esc_attr($instance["max"]); ?>" />
				<label>Cheapest only:</label>
				<input id="<?php echo $this->get_field_id("cheapest"); ?>" type="checkbox" value="yes" style="" <?php checked($instance["cheapest"], 'yes'); ?> name="wpODSTContentTools[cheapest]"/>			
		</div><?php
}
}
?>