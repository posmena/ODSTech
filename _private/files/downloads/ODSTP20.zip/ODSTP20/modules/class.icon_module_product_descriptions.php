<?php

class icon_module_product_descriptions
{
	function __construct()
	{
		add_action('admin_menu', array(&$this, 'add_menu'));
	}
	
	function activate()
	{
		global $wpdb;
		
		if($wpdb->get_var("show tables like 'pm_custom_descriptions'") != 'pm_custom_descriptions') {
			$sql = "CREATE TABLE IF NOT EXISTS `pm_custom_descriptions` (
					  `feed_id` int(11) NOT NULL,
					  `ProductID` varchar(50) NOT NULL,
					  `description` text NOT NULL,					  
					  `ProductName` varchar(255) NOT NULL,					  
					  `BrandName` varchar(255) NOT NULL,					  
					  `ImageURL` varchar(500) NOT NULL,					  
					  PRIMARY KEY `feed_id` (`feed_id`,`ProductID`)
					);";
			require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
			dbDelta($sql);
		}
	}
	
	function main_settings()
	{
	}
	
	function add_menu()
	{
		//add_submenu_page('pm-pro-home', __('Custom Descriptions','pm-top-level'), __('Custom Descriptions','pm-top-level'),
			//			'manage_options', 'pm-custom-descriptions', array(&$this, 'custom_descriptions'));
	}
	
	function custom_descriptions()
	{
		global $wpdb;
		
		$options = get_option('pm_options');
		
		$header = '<div class="wrap">';
		$header .= '<h2>Custom Descriptions</h2>';
		$header .= '<p><em>Here you can give custom descriptions to products.</em></p>';
		
		if ($_POST['save_description']) {
			$description = str_replace("Original Description:", '', $_POST['description']);
			$feed_id     = $_POST['feed_id'];
			$product_id  = $_POST['product_id'];
			
			
			if ($_POST['new_custom_description']) {
				$sql = 'INSERT INTO pm_custom_descriptions ';
				$sql .= sprintf("SET description='%s', feed_id=%d, ProductID='%s'", $description, $feed_id, $product_id);
			} else {
				$sql = 'UPDATE pm_custom_descriptions ';
				$sql .= sprintf("SET description='%s' WHERE feed_id=%d AND ProductID='%s'", $description, $feed_id, $product_id);
			}
			
			
			if ($wpdb->query($sql)) {
				$header .= "Product Description Updated<br /><br />";
			}
			
		}

		if ((int)$_GET['delete']) {
			$sql         = 'SELECT feed_id, ProductID, ProductName, ProductDescription FROM pm_products WHERE id='.$_GET['delete'];
			
			$products    = $wpdb->get_results($sql);
			$feed_id     = $products[0]->feed_id;
			$product_id  = $products[0]->ProductID;
			
			$sql = sprintf("DELETE FROM pm_custom_descriptions WHERE feed_id=%d AND ProductID='%s'", $feed_id, $product_id);
			$wpdb->query($sql);
		}
		
		
		if ((int)$_GET['product_id']) {
			$sql         = 'SELECT feed_id, ProductID, ProductName, ProductDescription FROM pm_products WHERE id='.$_GET['product_id'];
			
			$products    = $wpdb->get_results($sql);
			$feed_id     = $products[0]->feed_id;
			$product_id  = $products[0]->ProductID;
			$product_name = $products[0]->ProductName;
			$description = "Original Description: \r\n".$products[0]->ProductDescription;
			$url = $feed_id."/".$product_id."/".pathauto_cleanstring($product_name).".html";

			$sql        = sprintf("SELECT description FROM pm_custom_descriptions WHERE feed_id=%d AND ProductID='%s'", $feed_id, $product_id);
			$custom		= $wpdb->get_results($sql);
			$exists		= false;
			if (count($custom) > 0)
			{
				$exists = true;
			}
			
			$header .= '<a href="?page=pm-custom-descriptions">Back to list</a><br />';
			
			$header .= '<form method="post" action="?page=pm-custom-descriptions&product_id='.$_GET['product_id'].'">';
			$header .= '<input type="hidden" name="product_id" value="'.$product_id.'" />';
			$header .= '<input type="hidden" name="feed_id" value="'.$feed_id.'" />';
			$output .= 'Product: <a href="'.get_bloginfo('url').'/'.$options['icon_productdisplay_mainpage'].'/'.$url.'">'.$product_name.'</a><br />';
			$output .= '<textarea name="description" style="width: 500px; height: 300px;">';
			if ($exists === false) {
				$header .= '<input type="hidden" name="new_custom_description" value="yes" />';
				$output .= html_entity_decode($description);
			} else {
				$output .= html_entity_decode($custom[0]->description);
			}
			$output .= '</textarea><br />';
			$output .= '<input type="submit" value="Save" name="save_description" />';
			$output .= '</form>';
			
		} else {
			$sql = "SELECT ap.id, ap.AffiliateURL, ap.feed_id, ap.ProductID, ap.ProductName, ap.ImageURL, COALESCE(cd.description, ap.ProductDescription) as ProductDescription, ap.ProductPrice, CHAR_LENGTH(COALESCE(cd.description, ap.ProductDescription)) as desc_length
					FROM pm_products ap
					INNER JOIN pm_custom_descriptions cd ON (cd.feed_id = ap.feed_id AND cd.ProductID = ap.ProductID)";
			$products = $wpdb->get_results($sql);
			if (count($products) > 0) {
				
				$output .= '<table><tr><th width="50px">&nbsp</th><th align="left" width="500px">Product Name</th><th width="50">Length</th></tr>';
				foreach ($products as $product) {
					$url = $product->feed_id."/".$product->ProductID."/".pathauto_cleanstring($product->ProductName).".html";
					$output .= '<tr><td><a href="?page=pm-custom-descriptions&product_id='.$product->id.'">[edit]</a></td><td><a href="'.get_bloginfo('url').'/'.$options['icon_productdisplay_mainpage'].'/'.$url.'">'.$product->ProductName.'</a></td><td>'.$product->desc_length.'</td><td><a href="?page=pm-custom-descriptions&delete='.$product->id.'">[x]</a></td></tr>';
				}
				$output .= '</table><br />';
			}
			$output .= 'The products below all have a short description and should be improved<br /><br />';
			$sql = "SELECT ap.id, ap.AffiliateURL, ap.feed_id, ap.ProductID, ap.ProductName, ap.ImageURL, COALESCE(cd.description, ap.ProductDescription) as ProductDescription, ap.ProductPrice, CHAR_LENGTH(COALESCE(cd.description, ap.ProductDescription)) as desc_length
				FROM pm_products ap
				LEFT JOIN pm_custom_descriptions cd ON (cd.feed_id = ap.feed_id AND cd.ProductID = ap.ProductID)
				WHERE CHAR_LENGTH(COALESCE(cd.description, ap.ProductDescription)) < 100 ORDER BY COALESCE(cd.description, ap.ProductDescription);";
			$products = $wpdb->get_results($sql);
			if (count($products) > 0) {
				$output .= '<table><tr><th width="50px">&nbsp</th><th align="left" width="500px">Product Name</th><th width="50">Length</th></tr>';
				foreach ($products as $product) {
					$url = $product->feed_id."/".$product->ProductID."/".pathauto_cleanstring($product->ProductName).".html";
					$output .= '<tr><td><a href="?page=pm-custom-descriptions&product_id='.$product->id.'">[edit]</a></td><td><a href="'.get_bloginfo('url').'/'.$options['icon_productdisplay_mainpage'].'/'.$url.'">'.$product->ProductName.'</a></td><td>'.$product->desc_length.'</td><td><a href="?page=pm-custom-descriptions&delete='.$product->id.'">[x]</a></td></tr>';
				}
				$output .= '</table>';
			}
		}

		print $header;
		print $output.'</div>';
	}
	
}