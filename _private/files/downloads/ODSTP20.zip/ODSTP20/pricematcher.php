<?php
/*
Plugin Name: ODST-P20
Plugin URI: http://odst.co.uk
Description: Add product feed content units to your website
Version: 1.1.4
Author: ODST
Author URI: htp://www.odst.co.uk
*/

include 'functions.php';
include 'product_walker.php';

class PriceMatcherLoader
{
	private $modules;
	
	function __construct()
	{
		$filename = str_replace('\\', '/',__FILE__);
		$filename = preg_replace('/^.*wp-content[\\\\\/]plugins[\\\\\/]/', '', $filename);
	
		$classname = "PriceMatcherLoader";
		add_action('admin_menu', array(&$this, 'pricematcher_menu'));
		add_action('admin_head', array(&$this,'map_products_action_javascript'));
	
		define(WP_INCLUDE_DIR, preg_replace('/wp-content$/', 'wp-admin/includes', WP_CONTENT_DIR));
		require_once(WP_INCLUDE_DIR . '/plugin.php');
		
		add_action('admin_notices', array(&$this,'my_admin_notice'));
		

		if(false !== $this->CheckForModules())
		{
			//add the admin action
			add_action('activate_'.$filename, array(&$this,'activation'));
			add_filter('the_content', array(&$this, 'price_lookup'),-200);
		}
	}

	function CheckForModules()
	{
		$classes  = scandir(PriceMatcherLoader::getIncludePath('modules'));
		$required = array('class.icon_module_feedmanager.php');
		foreach ($required as $must) {
			if (false === in_array($must, $classes))
			{
				print 'P20 requires the icon_module_feedmanager class.';
				return false;
			}
		}
		foreach ($classes as $key => $file) {
			if (false !== strpos($file, 'icon_module')) {
				$parts = explode('.', $file);
				if (true === class_exists($parts[1])) {
					$p                  = new $parts[1];
					$modules[$parts[1]] = $p;
				}
			}
		}
		$this->modules = $modules;
	}
	
	
	function get_product_price($productid,$feedid)
	{
			global $wpdb;
			
			$sql = "SELECT p.ProductPrice FROM pm_products p WHERE feed_id=".$feedid." AND ProductID='".$productid."'";
			$result = $wpdb->get_var($sql);
			return $result;
	}

	function price_lookup($content='')
	{
		global $post, $wp_query, $wpdb;
		$occurances = preg_match_all("/price_matcher:[a-zA-Z0-9\-\_ ]+:+[a-zA-Z0-9\-\_ ]+/", $content, $price_codes);
		if (0 < $occurances) {
			foreach ($price_codes[0] as $price_code) {
				$parts = explode(':', $price_code);
				$sql = "SELECT p.ProductPrice FROM pm_products p WHERE feed_id=".$parts[1]." AND ProductID='".$parts[2]."'";
				$result = $wpdb->get_results($sql);
				$content = str_replace('['.$price_code.']', $result[0]->ProductPrice, $content);
			}	
		}
		
		return $content;
	}
	
	function getIncludePath($subdir='classes')
	{
		$path = ABSPATH . 'wp-content/plugins/ODSTP20/'.$subdir.'/';
		return $path;
	}
	
	function pricematcher_menu()
	{
		// Add a new top-level menu:
		add_menu_page(__('Settings','pm-top-level'), __('ODST P20','pm-top-level'),
						'manage_options', 'pm-pro-home', array(&$this, 'pm_options') );

		// Add submenus to the custom top-level menu:
		//add_submenu_page('pm-pro-home', __('Search Products','pm-top-level'), __('Search Products','pm-top-level'),
		//				'manage_options', 'pm-search-products', array(&$this, 'search_products'));
		
		
		add_submenu_page('pm-pro-home', __('Map Products','pm-top-level'), __('Map Products','pm-top-level'),
						'manage_options', 'pm-m-products', array(&$this, 'map_products'));
				
	}
	
	function activation()
	{
		global $wpdb, $wp_rewrite;
		

		$options = get_option('pm_options');

		if(!is_array($options))
		{
			//set default options
			$options=array(
				'icon_global_wg_id' => '',
				'icon_global_aw_id' => ''
				);
		}
		
		update_option('pm_options', $options);
		
		if (count($this->modules) > 0) {
			foreach ($this->modules as $module)
			{
				$module->activate();
			}
		}

		return true;
	}
	
	function check_odst_login($user,$pass)
	{
	$url = "http://odst.co.uk/api/index.php?user=$user&pass=$pass&source=p20";
	$result = icon_feed_processor::curl_get_file_contents($url);

	return $result == "ok";
	}
	
	function pm_options()
	{
		global $wpdb, $wp_rewrite;
		$options = get_option('pm_options');

		if (isset($_POST['info_update']))
		{
			$pm_options = $_POST['options'];
			foreach($pm_options as $option_key => $option)
			{
				$options[$option_key] = $option;
			}
			update_option('pm_options', $options);
			$wp_rewrite->flush_rules();

			echo "<div class='updated fade'><p><strong>P20 settings saved.</strong></p></div>";
			
			if( !$this->check_odst_login($pm_options['odst_username'],$pm_options['odst_password'] ) )
				{
				echo "<div class='error fade'><p><strong>Incorrect username or password. <a target='_blank' href='http://odst.co.uk/forgottenpassword.html'>Forgotten your password?</a></strong></p></div>";
				}
		}
		
		$cats = get_categories(array('hide_empty' => 0));

		echo '<div class="wrap">';
		
		echo '<h2>ODST P20</h2>';
		
		echo '<form method="post" action="?page=pm-pro-home">';
		wp_nonce_field('pm-update-settings');
	
		echo "<h3>ODST Settings</h3>";
		echo '<p>Enter your ODST login details below, or <a href="http://odst.co.uk/signup.html" target="_blank" class="button">sign up for an account here</a></p><br>';

	
		echo '<input type="text" name="options[odst_username]"
											 id="odst_username"
												 value="'.$options['odst_username'].'" />' . 'Username ( email)';
					echo '<br />';
					
		echo '<input type="password" name="options[odst_password]"
											 id="odst_password"
												 value="'.$options['odst_password'].'" />' . 'Password';
	
		echo "<h3>Affiliate Settings</h3>";
	
		$networks = PriceMatcherLoader::getNetworks();
		
		if (count($networks) > 0) {
			foreach ($networks as $nw) {
				$fields = $nw->getFields();
				echo '<fieldset><legend>' . $nw->getName() . '</legend>';
				foreach ($fields as $id => $field) {
					echo '<input type="' . $field['type'] . '" name="options[icon_global_' . $nw->getPrefix() . '_' . $field['id'] .']"
											 id="icon_global_' . $nw->getPrefix() .'_' . $field['id'] . '"
												 value="'.$options['icon_global_' . $nw->getPrefix() . '_' . $field['id']].'" />' . $field['name'];
					echo '<br />';
				}
				echo '</fieldset>';
			}
		}

		/*
		echo '<select name="options[icon_global_shop_cat]"><option value=0>Please Choose</option>';

		foreach($cats as $cat)
		{
			$selected = '';
			if($cat->term_id == $options['icon_global_shop_cat'])
			{
				$selected = ' selected="selected"';
			}
			$option = '<option value="'.$cat->term_id.'"'.$selected.'>'.$cat->name.'</option>';
			echo $option;
		}
		echo '</select> Please select which category you wish to use for your products<br />';
		*/
		
		if (count($this->modules) > 0) {
			foreach ($this->modules as $module) {
				if (function_exists($module->main_settings())) {
					$module->main_settings();
				}
			}
		}

		echo '<p class="submit">';
		echo '<input type="submit" name="info_update" value="Save Changes"></p>';
		echo '</form>';
		echo '</div>';
	}

	function getDbNetworks()
	{
		global $wpdb;
		$sql = "SELECT f.id, n.id as network_id, n.name, n.last_update, n.class_name, count(p.network_id)as programs, (SELECT count(f.id) FROM pm_feeds f WHERE f.network_id=n.id) as in_use
					FROM pm_networks n
					LEFT JOIN pm_programs p ON p.network_id=n.id
					LEFT OUTER JOIN pm_feeds f ON (f.merchant_ref=p.merchant_ref AND f.network_id=p.network_id)
					WHERE f.id IS NULL
					GROUP BY n.id
					ORDER BY n.name";
		$feed_summary = $wpdb->get_results($sql);
		foreach ($feed_summary as $feed) {
			$feeds[$feed->class_name] = $feed;
		}
		return $feeds;
	}

	function getNetworks()
	{
		$classes = scandir(PriceMatcherLoader::getIncludePath());
	
		foreach ($classes as $key => $file) {
			if (false !== strpos($file, 'icon') && $file !== 'class.icon_network.php' && $file !== 'class.icon_feed_processor.php' && $file !== 'class.icon_network_base.php'&& $file !== 'class.icon_sitemap.php') {
				$parts = explode('.', $file);
				if (true === class_exists($parts[1])) {
					$nw = new $parts[1];
					$network_list[$key] = $nw;
				}
			}
		}
		return $network_list;
	}
	
	function updateDbNetworks()
	{
		global $wpdb;
		$networks = PriceMatcherLoader::getNetworks();
		foreach ($networks as $network) {
			$query = 'INSERT INTO pm_networks (id, name, last_update, class_name)
						VALUES (\'\' , \'' . $network->getName() . '\' , 0, \'' . get_class($network) .'\');';
			$wpdb->query($query);
	 		
		}
	}

	function get_custom_product_groups_html()
	{
	   global $wpdb;
	   $sql      = 'SELECT cp.id, cp.name FROM pm_custom_product_groups cp';
	   $product_groups = $wpdb->get_results($sql);

		if(count($product_groups) > 0) {
				foreach ($product_groups as $product_group) {		
				//$product_group->id
				$pg_ddl .= '<li><a href="#" onclick="odst_map_products_search(\'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', ' . $product_group->id . ',\'' . $product_group->name . '\', false, false, false);return false;">'. $product_group->name . '</a></li>';
				}
				
			return $pg_ddl;
			}
	}
	
	function get_merchant_categories_ddl($haveblank = "true")
	{
	//<optgroup label="Categories">
	global $wpdb;
	
	$sql = "SELECT p.Category AS name, f.name AS Merchant, p.feed_id
			FROM pm_products p
			INNER JOIN pm_feeds f ON p.feed_id = f.id
			GROUP BY f.name, p.feed_id, p.Category
			ORDER BY f.name, p.Category";
	
	$categories = $wpdb->get_results($sql);
	$currentMerchant = '';
	$html ='';
	
	if( count($categories) )		
		{
			if( $haveblank == "true")
				{
				$html .= '<option></option>';
				}
			foreach( $categories as $category )
			{
				if ( $currentMerchant != $category->Merchant )
					{
					if( $currentMerchant != '' )
						{
						$html .=  '</optgroup>';
						}
					$html .=  '<optgroup label="' . $category->Merchant . '" value="'. $category->feed_id . '">';
					$currentMerchant = $category->Merchant;					
					}
					
				$html .= '<option value="' . $category->name . '">' . $category->name . '</option>';
					
			}
			$html .= '</optgroup>';
		}
		
		return $html	;
	}
	
	function get_categories_ddl($prefix = "",$selected ="")
	{
	   $options = get_option('pm_options');
	   $wp_cats = get_categories(array('hide_empty' => 0, 'taxonomy' => 'odst_products'));
	   
	   foreach($wp_cats as $wp_category)
			{
				$cat_html .= '<option value="' . $prefix .$wp_category->term_id.'">'. $wp_category->name.'</option>';				
			}
		return $cat_html;
	}


	function get_custom_product_groups_ddl($prefix="",$selected ="")
	{
	   global $wpdb;
	   $sql      = 'SELECT cp.id, cp.name FROM pm_custom_product_groups cp';
	   $product_groups = $wpdb->get_results($sql);

		if(count($product_groups) > 0) {
				foreach ($product_groups as $product_group) {		
				$pg_ddl = $pg_ddl . '<option';
				if ($selected ==  $product_group->id ) { $pg_ddl = $pg_ddl . ' selected="true" ';}
				$pg_ddl = $pg_ddl . ' value="' . $prefix . $product_group->id . '">' . $product_group->name . '</option>';
				}

			return $pg_ddl;
			}
	}
	

	
	function map_products()
	{
		global $wpdb;
		
		$header = '<h2>Map Products</h2>';	
				
		$header .= wp_nonce_field('pm-search_products');
	
		$walker = new Product_Category_Walker();
		$categories = wp_list_categories(array('hide_empty' => 0, 'taxonomy' => 'odst_products', 'echo' => 0, 'walker' => $walker));
		
		$groups = $this->get_custom_product_groups_html();
	
		$output = '<div class="pm_container" style="width:100%px">
					<div class="left_container" style="border: solid 1px;width:200px;float:left;">
					
						<div class="odst_categories" style="padding:5px;border: solid 1px;width:200px;min-height:700px;overflow:scroll">	
						<div style="float:right">
						<a href="edit-tags.php?taxonomy=odst_products" target="_blank">edit</a>
						&nbsp;|&nbsp;<a href="#" onclick="refresh_categories();return false;">refresh</a>
						</div>
						<div id="odst_categories">
							' . $categories . '							
							</div>
						</div>
						<!--div class="odst_groups" style="padding:5px;border: solid 1px;width:200px;height:250px;overflow:scroll">
							Groups
							<ul id="product_groups">
							' . $groups . '</ul>
							<input type="text" id="new_product_group"/>
							<input type="button" class="button" onclick="create_product_group(jQuery(\'#new_product_group\').val(),jQuery(\'#product_groups\'));return false;" value="Add New Group"/>
								
						</div-->						
				   </div>
				   
					<div id="map_product_container" style="border: solid 1px;margin-left:212px">
						<div class="product_search" style="border: solid 1px; min-width: 938px;height:130px;padding:10px 10px 20px 20px">
							
							<div id="search_form">
								<label for="search_product_name">Product Name</label><input type="text" id="search_product_name">
								<label for="search_product_category">Merchant Category</label>
								<select name="search_product[product_category]" id="search_product_category">															
															' .  PriceMatcherLoader::get_merchant_categories_ddl() 
														.'</select>	
								
								<label for="search_brand_name">Brand Name</label><input type="text" id="search_brand_name">
								<label for="search_product_price_from">Price from</label><input style="width:50px" type="text" id="search_product_price_from"> to <input type="text" style="width:50px" id="search_product_price_to">
								
								<div class="search_form">
								<label title="Only show products that haven\'t been added to any categories" for="unmapped_chk">Show UnCategorised Products Only</label><input type="checkbox" id="unmapped_chk" value="yes"/>
								<label title="Show deleted products" for="hidden_chk">Show deleted products</label><input type="checkbox" id="deleted_chk" value="yes"/>
								<br>
								<input type="button" style="margin:5px 0 5px 0" class="button" onclick="map_products_search_submit(jQuery(\'#map_product_container #search_form \'));" value="Search"/>
								
									
									<div class="actions" style="padding-top:10px">
										<div style="float:left">
											
											<select name="add_product[product_category]" id="add_product_to_cat_group">
											' .  PriceMatcherLoader::get_categories_ddl() 											
										.'</select>		
										<input type="button" class="button" onclick="add_products_category_or_group(jQuery(\'#add_product_to_cat_group\'),jQuery(\'#product_results ul\'))" value="Add selected products to Category"/>
										<input type="button" class="button" onclick="remove_products_category_or_group(jQuery(\'#add_product_to_cat_group\'),jQuery(\'#product_results ul\'))" value="Remove selected products from Category"/>
										<input type="button" class="button" onclick="link_products(jQuery(\'#product_results ul\'))" value="Link selected products"/>
										
										</div>
									  <div style="float:right">
										
										
										<input type="button" style="margin:5px 15px 5px 0" class="button" onclick="hide_all();" value="Hide Selected"/>								
										<input type="button" style="margin:5px 0 5px 0" class="button" onclick="delete_products(jQuery(\'#product_results ul\'));" value="Delete Selected"/>								
										<input type="button" style="margin:5px 0 5px 0" class="button" onclick="undelete_products(jQuery(\'#product_results ul\'));" value="Undelete Selected"/>								
									  </div>
									</div>
									
								</div>							
							</div>		   
						</div>
						<div id="product_results" style="border: solid 1px;min-height:500px;min-width:650px;overflow:scroll;padding:10px 10px 20px 30px;">						
						<div id="checkall">
							Select / Unselect All <input type="checkbox" onclick="check_uncheck_all(this);"/>										
						</div>
							<ul></ul>
						</div>
											
					</div>		
				</div>
		';
		
		print $header.$output;
	}

	
	
	function search_products()
	{
		global $wpdb;
		if ($_POST['q']) {
			$q = $_POST['q'];
		}
		
	
		
		
		if ($_POST['select_product']) {
			
			if( $_POST['custom_product_group_id'] && $_POST['add_to_product_group'] )
				{
			
				foreach ($_POST['select_product'] as $product_id => $checked) {
				
				$query = 'INSERT INTO pm_custom_product_group_products (productID, product_group_id, feed_id)
							VALUES (\'' . $product_id . '\' , \'' . $_POST['custom_product_group_id'] . '\',\'' . $checked . '\');';
				
				$wpdb->query($query);
				}
			}
			
			echo('Products have been added to Product Group');
		
		}

		$header = '<h2>Search Products</h2>';
		$header .= '<form method="post" action="?page=pm-search-products">';
		$header .= wp_nonce_field('pm-search_products');
		$header .= '<input type="text" value="'.$q.'" name="q" />';
		$header .= '<input type="submit" value="Search!" />';
		
		
		if (true === isset($q)) {
			$sql = "SELECT p.id, p.ProductName, p.ProductPrice, p.feed_id, p.ProductID, p.ImageURL, p.AffiliateURL
					FROM pm_products p
					WHERE p.ProductName LIKE '%".$q."%' OR p.ProductID LIKE '%".$q."%'";
			$products = $wpdb->get_results($sql);
			if (count($products > 0)) {
				$sql = 'SELECT cp.id, cp.name FROM pm_custom_product_groups cp';
				$custom_products = $wpdb->get_results($sql);
				if (count($custom_products) > 0) {
					$header .= 'Add selected products to group: <select name="custom_product_group_id">';
					foreach ($custom_products as $custom_product) {
						$header .= '<option value="'.$custom_product->id.'">'.$custom_product->name.'</option>';
					}
					$header .= '</select><input type="submit" value="Add to Product Group" name="add_to_product_group" />';
				}
				
				$output .= '<table cellpadding="2" cellspacing="2"><thead><tr>';
				if(true === array_key_exists('icon_module_product_descriptions', $this->modules)) {
					$output .= '<th width="50">&nbsp;</th>';
				}
				$output .= '<th align="left">Product Name</th>
								<th align="left">Price</th>
								<th align="left">Price Code</th>
								</tr>';
				foreach ($products as $product) {
					$output .= '<tr>';
					if(true === array_key_exists('icon_module_product_descriptions', $this->modules)) {
						$output .= '<td><a href="?page=pm-custom-descriptions&product_id='.$product->id.'">[edit]</a></td>';
					}
					$output .= '<td><a href="'.$product->AffiliateURL.'">'.$product->ProductName.'</a></td>
									<td>'.$product->ProductPrice.'</td>
									<td>[price_matcher:'.$product->feed_id.':'.$product->ProductID.']</td>
									<td><input type="checkbox" name="select_product['.$product->ProductID.']" value="'.$product->feed_id.'" /></td>
									</tr>';
				}
				$output .= '</table>';
			}
			
			$output .='</form>';
		}
		
		print $header.$output;
	}

	
	
	function get_mapped_cats()
	{
		global $wpdb;
		$sql = "SELECT ac.id, ac.name, atc.term_id, ac.feed_id, ap.name as program_name
		FROM pm_categories ac
		INNER JOIN pm_feeds af ON af.id=ac.feed_id
		INNER JOIN pm_programs ap ON (ap.network_id=af.network_id AND ap.merchant_ref=af.merchant_ref)
		INNER JOIN pm_terms2categories atc ON atc.category_id = ac.id
		INNER JOIN ".$wpdb->prefix."terms wpt ON wpt.term_id=atc.term_id WHERE ac.name!='' ORDER BY ac.feed_id, ac.name";

		$categorised = $wpdb->get_results($sql, OBJECT);

		return $categorised;
	}
	
	function get_unmapped_cats()
	{
		global $wpdb;
		
		$sql = "SELECT ac.id, ac.name, COALESCE(atc.term_id,wpt.term_id) as term_id, ac.feed_id, ap.name as program_name
			FROM pm_categories ac
			INNER JOIN pm_feeds af ON af.id=ac.feed_id
			INNER JOIN pm_programs ap ON (ap.network_id=af.network_id AND ap.merchant_ref=af.merchant_ref)
			LEFT JOIN pm_terms2categories atc ON atc.category_id = ac.id
			LEFT JOIN wp_terms wpt ON wpt.term_id=atc.term_id
			WHERE (wpt.term_id IS NULL OR atc.term_id IS NULL) AND ac.name!='' ORDER BY ac.feed_id, ac.name";
		$need2cat = $wpdb->get_results($sql, OBJECT);

		return $need2cat;
	}
	
	function is_unmapped_cats()
	{
		if(count(PriceMatcherLoader::get_unmapped_cats()) > 0)
		{
			print '<div class="updated fade"><p><strong>You have unmapped categories, go <a href="?page=pm-map-products">here</a> to map them</strong></p></div>';
		}
	}
	
	function my_admin_notice(){
   
	$latestVersion = icon_feed_processor::curl_get_file_contents("http://odst.co.uk/downloads/odstP20.txt");
	
	$data = get_plugin_data( __FILE__ );
	if($data["Version"] != $latestVersion)	
		{
		
		 echo '<div class="update-nag">
			   There is a new version of the ODST P20 plugin available.  Please <a href="http://www.odst.co.uk/downloads/ODSTP20.zip">download and update</a>
			</div>';		
		}
		
}

	function map_products_action_javascript()
	{
	?>
	<script type="text/javascript" >
		
	function hide_all()
	{
		jQuery("div#product_results ul li input[type='checkbox']:checked").each( function() {
			jQuery(this).closest("li").hide();
			jQuery(this).removeAttr('checked');
			});
	}
	
	function check_all()
	{
		jQuery("div#product_results ul li input[type='checkbox']").each( function() {
			jQuery(this).attr('checked','checked');
			});
		jQuery("#chk_unchk_all").val("Uncheck All");
	}
	
	function uncheck_all()
	{
		jQuery("div#product_results ul li input[type='checkbox']").each( function() {
			jQuery(this).removeAttr('checked');
			});	
			
	//	jQuery("#chk_unchk_all").val("Check All");
	}
	
	function check_uncheck_all(e)	
	{
	e = jQuery(e);
	
	if( e.is(':checked') )
		{
		check_all();		
		}
	else
		{
		uncheck_all();		
		}
	}
	
	function refresh_categories()
	{
			var data = {
			action: 'my_action',
			my_action: "refresh_categories"				
		};
			
				
		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(json) {				
					// if show unmapped only checkbox checked then hide selected
					jQuery("#odst_categories").html(json);
					jQuery("#add_product_to_cat_group").empty();
					// set the dropdown box to have the same categories
					jQuery("#odst_categories ul li").each(
					function(){  
					el = jQuery(this);
					
					jQuery("#add_product_to_cat_group").append(
						jQuery('<option></option>').val(el.attr("rel")).html(el.find("a").text()));

					} );
		});
	
	
	
	}
	
	function add_products_category_or_group(category_group, products_div)
	{
		// get selected products ids and feedID
		// test if adding ro group or category
		var product_group_id = '';
		var category_id = '';
		var msg;
		
		if( jQuery("option:selected",category_group).parent().attr('label') == "Product Groups")
				{
				product_group_id = category_group.val();					
				action = 'add_product_to_product_group';
				msg = "Products added to Product Group!";
				}
			else
				{
				category_id = category_group.val();					
				action = 'add_product_to_category';			
				msg = "Products added to Category!";
				}
		
		products = new Array();
		var i = 0;
		jQuery("input:checked",jQuery(products_div)).each(function() {
					products[i] = jQuery(this).closest("li").attr("id");
					i+=1;
			});
					
			
			var data = {
			action: 'my_action',
			my_action: action,			
			product_group: product_group_id,
			category: category_id,			
			products: products,
			
		};
			
				
		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(json) {				
					alert(msg);
					// if show unmapped only checkbox checked then hide selected
					if( jQuery("#unmapped_chk").attr('checked') == 'checked' )
						{
						hide_all();
						}
					uncheck_all();
		});
	
	
	}
	
	function delete_products(products_div)
	{
		// get selected products ids and feedID
		// test if adding ro group or category
		var product_group_id = '';
		var category_id = '';
		var msg;
		
		action = 'delete_products';			
				
		msg = "Products have been deleted!";
				
		products = new Array();
		var i = 0;
		jQuery("input:checked",jQuery(products_div)).each(function() {
					products[i] = jQuery(this).closest("li").attr("id");
					i+=1;
			});
			
			
			var data = {
			action: 'my_action',
			my_action: action,			
			products: products,
			
		};
			
				
		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(json) {				
					alert(msg);
					hide_all();
		});
	
	
	}
	
		function undelete_products(products_div)
	{
		// get selected products ids and feedID
		// test if adding ro group or category
		var product_group_id = '';
		var category_id = '';
		var msg;
		
		action = 'undelete_products';			
				
		msg = "Products have been undeleted!";
				
		products = new Array();
		var i = 0;
		jQuery("input:checked",jQuery(products_div)).each(function() {
					products[i] = jQuery(this).closest("li").attr("id");
					i+=1;
			});
			
			
			var data = {
			action: 'my_action',
			my_action: action,			
			products: products,
			
		};
			
				
		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(json) {				
					alert(msg);
					hide_all();
		});
	
	
	}
	
	function link_products(products_div)
	{
	products = new Array();
		var i = 0;
		jQuery("input:checked",jQuery(products_div)).each(function() {	
					products[i] = jQuery(this).closest("li").attr("id");
					i+=1;
			});
			
			
			var data = {
			action: 'my_action',
			my_action: 'link_products',				
			products: products,
			
		};
			
				
		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(msg) {				
					alert(msg);	
					odst_map_products_search('', '', '', '', '', '', '', '' ,'' , '', '', false, false, true);
	
		});
	}
	
	function remove_products_category_or_group(category_group, products_div)
	{
		// get selected products ids and feedID
		// test if adding ro group or category
		var product_group_id = '';
		var category_id = '';
		var msg;
		
		if( jQuery("option:selected",category_group).parent().attr('label') == "Product Groups")
				{
				product_group_id = category_group.val();					
				action = 'remove_product_from_product_group';
				msg = "Products removed from Product Group!";
				}
			else
				{
				category_id = category_group.val();					
				action = 'remove_product_from_category';			
				msg = "Products removed from Category!";
				}
		
		products = new Array();
		var i = 0;
		jQuery("input:checked",jQuery(products_div)).each(function() {
					products[i] = jQuery(this).closest("li").attr("id");
					i+=1;
			});
			
			
			var data = {
			action: 'my_action',
			my_action: action,			
			product_group: product_group_id,
			category: category_id,			
			products: products,
			
		};
			
				
		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(json) {				
					alert(msg);	
					odst_map_products_search('', '', '', '', '', '', '', '' ,'' , '', '', false, false, true);
	
		});
	
	
	}
	
	
	function create_product_group(name,product_groups)
	{
	var data = {
			action: 'my_action',
			my_action: 'create_product_group',			
			product_group: name
		};
				
		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(json) {			
					product_groups.append('<li><a href="#" onclick="odst_map_products_search(\'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', ' + json.id + ',\'' + name + '\', false, false, false);return false;">' + name + '</a></li>');																
					get_product_group_and_categories("#add_product_to_cat_group");	
		},"json");
	}
	
	function dump(arr,level) {
	var dumped_text = "";
	if(!level) level = 0;
	
	//The padding given at the beginning of the line.
	var level_padding = "";
	for(var j=0;j<level+1;j++) level_padding += "    ";
	
	if(typeof(arr) == 'object') { //Array/Hashes/Objects 
		for(var item in arr) {
			var value = arr[item];
			
			if(typeof(value) == 'object') { //If it is an array,
				dumped_text += level_padding + "'" + item + "' ...\n";
				dumped_text += dump(value,level+1);
			} else {
				dumped_text += level_padding + "'" + item + "' => \"" + value + "\"\n";
			}
		}
	} else { //Stings/Chars/Numbers etc.
		dumped_text = "===>"+arr+"<===("+typeof(arr)+")";
	}
	return dumped_text;
}

		function map_products_search_submit(search_div)
		{
		var product_name = search_div.find("#search_product_name").val();
		var merchant = "";
		var merchant_category = search_div.find("#search_product_category").val();
		var unmapped_only =  (search_div.find("#unmapped_chk").attr('checked') == 'checked');
		var deleted =  (search_div.find("#deleted_chk").attr('checked') == 'checked');
		var merchant_category_name = "";
		var brand_name = search_div.find("#search_brand_name").val();
		var price_from = search_div.find("#search_product_price_from").val();
		var price_to = search_div.find("#search_product_price_to").val();
		
		uncheck_all();
				
		if ( merchant_category != '' ) 
			{
			merchant = jQuery("option:selected",search_div.find("#search_product_category")).parent().attr('label');			
			merchant_category_name = jQuery("option:selected",search_div.find("#search_product_category")).html();			
			}
		
		odst_map_products_search(product_name, brand_name, price_from, price_to, merchant, merchant_category, merchant_category_name, '' ,'' , '', '', unmapped_only, deleted, false);
		}
		
		function odst_rename_product_group(product_group_id,name)
		{
			var data = {
			action: 'my_action',
			my_action: 'odst_rename_product_group',
			product_name: product_name,
			product_group_id: product_group_id
			}
			
			jQuery.post(ajaxurl, data, function(json) {	
				// Update with the new name
				
			},"json");
			
		}
		
		function odst_delete_product_group(product_group_id)
		{
			var data = {
			action: 'my_action',
			my_action: 'delete_product_group',
			product_group_id: product_group_id
			}
			
			jQuery.post(ajaxurl, data, function(json) {	
				// remove the list item
				
			},"json");
			
		}
		
		var lastSearch  = null;
		
		function odst_map_products_search(product_name, brand_name, price_from, price_to, merchant, merchant_category,  merchant_category_name, odst_category,  category_name, odst_product_group, product_group_name, unmapped_only, deleted, doLastSearch){

		
			var data;
		    if( doLastSearch == undefined )
				{
				doLastSearch = false;
				}
				
			if( doLastSearch == false )
				{
		data = {
			action: 'my_action',
			my_action: 'search_product',
			product_name: product_name,
			brand_name: brand_name,
			price_from: price_from,
			price_to: price_to,
			category: odst_category,
			product_group: odst_product_group,
			merchant: merchant,
			merchant_category: merchant_category,
			unmapped_only: unmapped_only,			
			deleted: deleted
		};					
					
			lastSearch = data;
			}
			else
			{
			data = lastSearch;
			}
		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		
		// update form to reflect search 
		if( odst_category != "") 
			{
			jQuery("#add_product_to_cat_group").val(odst_category);
			}
			
		jQuery.post(ajaxurl, data, function(json) {	
	
				var products_ul = jQuery("#product_results ul");
				var products_h4 = jQuery("#product_results h4#results");
				products_ul.empty();				
				if( json.length == 0)					
					{					 
					 products_h4.html('No products found');
					}
						 jQuery(json).each(function() {		
						 var name = '';
						 var description = '';
						 var image = '';
						 var brand = '';
						 var desc = '';
						 
						
							name = this.ProductName;
						
							description = this.ProductDescription;
							desc = description.substring(0,400);
						 
							image = this.ImageURL;
							
							brand = this.BrandName;
							
														
//						 products_ul.append('<li id="P_' + this.uid + '"><span class="product_name">' + this.ProductName + '</span><input type="checkbox" value="checked"/><div class="actions"><a href="" onclick="show_odst_product(\'' + this.ProductID + '\',\'' + this.feed_id + '\',\'li#P_' + this.feed_id + '_' + this.ProductID + ' span.product_name\');return false;">edit</a></div></li>');
						
						
						var li = products_ul.find('li#P_' + this.uid);
						
						
						if( li.length == 0 ) 
							{
							li = jQuery('<li id="P_' + this.uid + '"><div class="select"><input type="checkbox" value="checked"></div><span class="product_name">' + name + '</span><div class="image"><img class="product_image" title="' + desc + '" src="' + odst_content_tools_settings.tim_thumb + encodeURI(image) + '&w=80"/></div><div class="brand"><span class="product_brand">' + brand + '</span></div><div class="merchant">' + this.MerchantName + '</div><div class="price">&pound;<span>' + this.ProductPrice + '<span></div><div class="actions"><a href="" onclick="show_odst_product(\'' + this.uid + '\',\'li#P_' + this.uid + '\');return false;">edit</a>&nbsp;&nbsp;<a href="#" onclick="showShortCode(\'' + this.uid + '\',\'li#P_' + this.uid + '\');return false;">shortcode</a></div><div class="lnk"><div class="lnkproducts"></div></div></li>');
							products_ul.append(li);				
							}
						else
							{
							// update price if cheaper and show 'multiple' icon
							var pspan = li.find('div.price span');
							var price = parseFloat(pspan.html());
							if ( price > parseFloat(this.ProductPrice) )
								{
								pspan.html(this.ProductPrice);
								li.find('div.merchant').html(this.MerchantName);
								}								
							}
						
						var lnkd = li.find('div.lnk');						
						
						title = lnkd.find('div.lnkproducts').html();
						
						if( title != "" )
							{							
							lnkd.addClass('on');
							}						
						
						lnkd.find('div.lnkproducts').html(title + this.MerchantName + '&nbsp;&pound;' + this.ProductPrice + '<br>');
						lnkd.attr('title',lnkd.find('div.lnkproducts').html());
						lnkd.tooltip();
						
						
						 if( product_name != "" )
							{
								products_h4.html("Seach results for '" + product_name + "'");
							}
						
							if( category_name != "" )
							{
								products_h4.html("Seach results for Category '" + category_name + "'");
							}
						
							if( merchant_category_name != "" )
							{
								products_h4.html("Seach results for Merchant Category '" + merchant_category_name + "'");
							}
							
							if( product_group_name != "" )
							{
								products_h4.html("Seach results for Group '" + product_group_name + "'");
							}
												
				});
				
		
						
		},"json").error(function(dt) { //alert(dt.responseText); 
										});
	}
	</script>
	<?php
	}
	
}


/** start plugin **/
function __autoload($class_name) 
{
	if (false !== strpos($class_name, 'icon')) {
		$subdir = 'classes';
		if (false !== strpos($class_name, 'icon_module')) {
			$subdir = 'modules';
		}
		$include_file = PriceMatcherLoader::getIncludePath($subdir) . 'class.' . $class_name . '.php';
		if (file_exists($include_file) === true)
		{
	    	include $include_file;
		} else {
			echo 'There was an error importing the ' . $include_file . ' class.';	
		}
	}
}
	
$afp = new PriceMatcherLoader();