/**
 * Handle: wpODSTModuleContentUnitScripts
 * Version: 0.0.1
 * Deps: jquery
 * Enqueue: true
 */
 
var wpODSTModuleContentUnitScripts = function () {}
 
wpODSTModuleContentUnitScripts.prototype = {
  $tabs	: null,
    options           : {},
	init : function()
	{
    },
	insertContentUnit : function(f) {
	var prod_group;
	if( jQuery(f).find("#wpODSTContentTools_format").val() == "contextual" )	{
		prod_group = "contextual";			
		}
		else{
			prod_group = jQuery(f).find("#wpODSTContentTools_product_group").val();					
			if( jQuery("option:selected",jQuery(f).find("#wpODSTContentTools_product_group")).parent().attr('label') == "Categories")
				{				
				select_option = 'category="' + prod_group + '"';
				}
			else
				{
				select_option = 'category="' + prod_group + '" merchant="' + jQuery("option:selected",jQuery(f).find("#wpODSTContentTools_product_group")).parent().attr('label') + '"';
				}
		}
		l = jQuery(f).find("#wpODSTContentTools_maxproducts").val();
	
		c = 'false';		if ( jQuery(f).find("#wpODSTContentTools_cheapest").attr('checked') )			{			c = 'true';			}						send_to_editor('[odst_content_unit type="products" cheapestonly="' + c + '" display="' + jQuery(f).find("#wpODSTContentTools_display").val() +  '" price_from="' + jQuery(f).find("#wpODSTContentTools_pricefrom").val() + '" price_to="' + jQuery(f).find("#wpODSTContentTools_priceto").val() + '" width="' + jQuery(f).find("#wpODSTContentTools_width").val() + '" ' + select_option +  ' max="' + l + '"]');	
	},
	addImage : function(i)
	{
    send_to_editor('<img src="' + i + '"/>');
    },
	addPriceCode : function(productid,feedid)
	{
    send_to_editor('[odst_content_unit type="price" productid="' + productid + '" feedid="' + feedid + '"]');
    },
	addAsProduct : function(ProductName,ImageURL,ProductDescription,ProductURL,MerchantName, ProductID, feed_id)
	{
	send_to_editor('<span class="product_name">' + ProductName + '</span>');
	send_to_editor('<div class="image"><img src="' + ImageURL + '"/></div>');
	send_to_editor('<div class="description">' + ProductDescription + '</div>');
	send_to_editor('<div class="merchant">' + MerchantName + '</div>');
	send_to_editor('<div class="price">[odst_content_unit type="price" productid="' + ProductID + '" feed_id="' + feed_id + '"]</div>');	
    },
	addAsPost : function(f,ProductName,ImageURL,ProductDescription,ProductURL,MerchantName, ProductID, feed_id)
	{
	if( confirm('This will overwrite existing your content and title, continue?') ) {
		jQuery(f).find('#title').val(name);
		jQuery(f).find('#content').val('');
		send_to_editor('<span class="product_name">' + ProductName + '</span>');
		send_to_editor('<div class="image"><img src="' + ImageURL + '"/></div>');
		send_to_editor('<div class="description">' + ProductDescription + '</div>');
		send_to_editor('<div class="merchant">' + MerchantName + '</div>');
		send_to_editor('<div class="price">[odst_content_unit type="price" productid="' + ProductID + '" feed_id="' + feed_id + '"]</div>');	
		}
    }
}
 
var wpODSTModuleContentUnitScriptsObj = new wpODSTModuleContentUnitScripts();

			jQuery(document).ready(function() {
				wpODSTModuleContentUnitScriptsObj.init();
			});

			
			