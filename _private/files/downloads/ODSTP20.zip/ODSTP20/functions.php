<?php

// {{{ pathauto_cleanstring
function pathauto_cleanstring($string)
{
	$url = $string;
	$url = preg_replace('~[^\\pL0-9_]+~u', '-', $url); // substitutes anything but letters, numbers and '_' with separator
	$url = trim($url, "-");
	$url = iconv("utf-8", "us-ascii//TRANSLIT", $url); // TRANSLIT does the whole job
	$url = strtolower($url);
	$url = str_replace('_', '-', $url);
	$url = preg_replace('~[^-a-z0-9_]+~', '', $url); // keep only letters, numbers, '_' and separator
	return $url;
}
// }}}


/*** FRONT END ***/

function getProductsBySearch($query)
{
	global $wpdb;
	$sql = "SELECT ap.feed_id, ap.ProductID, ap.ProductName, ap.ProductPrice, ap.ImageURL, ap.SmallImageURL, ap.AffiliateURL
			FROM pm_products ap
			WHERE ap.ProductName LIKE '%".$query."%';";
	$prods = $wpdb->get_results($sql, OBJECT);
	return $prods;
}

function getProductsForCarousel($limit = 10)
{
	global $wpdb;
	$sql = "SELECT ap.feed_id, ap.ProductID, ap.ProductName, ap.ProductPrice, ap.ImageURL, ap.SmallImageURL, ap.AffiliateURL
			FROM pm_products ap
			WHERE ap.ProductName LIKE '%lingerie%' LIMIT 0,".$limit.";";
	$prods = $wpdb->get_results($sql, OBJECT);
	return $prods;
}

function odst_truncate($string, $limit, $break=" ", $pad="...") { 
// return with no change if string is shorter than $limit 

if(strlen($string) <= $limit) return $string; 

// is $break present between $limit and the end of the string?
 if(false !== ($breakpoint = strpos($string, $break, $limit))) { 
		if($breakpoint < strlen($string) - 1) { 
				$string = substr($string, 0, $breakpoint) . $pad; } 				
				} return $string; 
 }




?>